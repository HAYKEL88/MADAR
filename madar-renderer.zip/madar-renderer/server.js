// server.js
// where your node app starts

// init project
var express = require("express");
var app = express();
var exporter = require("highcharts-export-server");
var round = require("lodash/round");
var numberFormat = require("number-format-x");
require("es6-promise").polyfill();
require("isomorphic-fetch");

const nF = value => numberFormat(value, 0, 3, " ");
const url = "https://prex.madar-patrimoine.2m-advisory.fr/public/index.php/rapports";

app.use(express.static("views"));

app.get("/ca_activites.png", function(request, response) {
  //Export settings
  fetch(url + "/activites")
    .then(res => res.json())
    .then(function(res) {
      const total = res.data.reduce((m, a) => m + parseInt(a.loyer_total, 10), 0);
      const data = res.data.map(d => ({
        name: d.activite,
        y: parseInt(parseInt(d.loyer_total, 10) * 100 / total, 10),
      }));

      var exportSettings = {
        type: "png",
        tmpdir: "views/",
        options: {
          chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: "pie",
          },
          title: {
            text: "",
          },
          plotOptions: {
            pie: {
              allowPointSelect: true,
              cursor: "pointer",
              dataLabels: {
                enabled: false,
              },
              dataLabels: {
                enabled: true,
                format: "<b>{point.name}</b>: {point.y} %",
                style: {
                  color: "black",
                },
              },
              showInLegend: false,
            },
          },
          series: [
            {
              name: "Activités",
              colorByPoint: true,
              data,
            },
          ],
        },
      };

      //Set up a pool of PhantomJS workers
      exporter.initPool();

      //Perform an export
      /*
        Export settings corresponds to the available CLI arguments described
        above.
    */
      exporter.export(exportSettings, function(err, res) {
        if (err) console.error(err);

        //Kill the pool when we're done with it
        exporter.killPool();

        //    var data = getIcon(req.params.w);
        var img = new Buffer(res.data, "base64");

        response.writeHead(200, {
          "Content-Type": "image/png",
          "Content-Length": img.length,
        });
        return response.end(img);

        //return response.send(res.data);
        //response.redirect("/chart.pdf");
      });
    });
});

app.get("/ca_arrondissements.png", function(request, response) {
  //Export settings
  fetch(url + "/arrondissements")
    .then(res => res.json())
    .then(function(res) {
      const total = res.data
        .filter(d => d.Arrondismment !== "Total")
        .reduce((m, a) => m + parseInt(a.loyer_total, 10), 0);
      const data = res.data.filter(d => d.Arrondismment !== "Total").map(d => {
        console.log(d.Arrondismment);
        return {
          name: d.Arrondismment,
          y: parseInt(parseInt(d.loyer_total, 10) * 100 / total, 10),
        };
      });

      var exportSettings = {
        type: "png",
        tmpdir: "views/",
        options: {
          chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: "pie",
          },
          title: {
            text: "",
          },
          plotOptions: {
            pie: {
              allowPointSelect: true,
              cursor: "pointer",
              dataLabels: {
                enabled: false,
              },
              dataLabels: {
                enabled: true,
                format: "<b>{point.name}</b>: {point.y} %",
                style: {
                  color: "black",
                },
              },
              showInLegend: false,
            },
          },
          series: [
            {
              name: "Arrondissements",
              colorByPoint: true,
              data,
            },
          ],
        },
      };

      //Set up a pool of PhantomJS workers
      exporter.initPool();

      //Perform an export
      /*
        Export settings corresponds to the available CLI arguments described
        above.
    */
      exporter.export(exportSettings, function(err, res) {
        if (err) console.error(err);

        //Kill the pool when we're done with it
        exporter.killPool();

        //    var data = getIcon(req.params.w);
        var img = new Buffer(res.data, "base64");

        response.writeHead(200, {
          "Content-Type": "image/png",
          "Content-Length": img.length,
        });
        return response.end(img);

        //return response.send(res.data);
        //response.redirect("/chart.pdf");
      });
    });
});

app.get("/dscr_forum_1.png", function(request, response) {
    console.log('ici');
  //Export settings
  fetch(url + "/totaldscr/1")
    .then(res => res.json())
    .then(function(res) {
      const series = [
        {
          name: "Dscr Actuel",
          data: res.data.map(d => d.dscr_actuel),
        },
        {
          name: "Dscr Facial",
          data: res.data.map(d => d.dscr_facial_acte),
        },
        {
          name: "Dscr potentiel",
          data: res.data.map(d => d.dscr_potentiel),
        },
      ];

      var exportSettings = {
        type: "png",
        tmpdir: "views/",
        options: {
          chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: "line",
          },
          title: {
            text: "",
          },
          yAxis: {
            labels: {
              formatter: obj => `${obj.value} %`,
            },
            title: {
              text: "Valeur DSCR %",
            },
          },
          plotOptions: {
            series: {
              label: {
                connectorAllowed: false,
              },
              pointStart: res.data[0].annee_emprunt,
            },
          },
          series,
          responsive: {
            rules: [
              {
                condition: {
                  maxWidth: 500,
                },
                chartOptions: {
                  legend: {
                    layout: "horizontal",
                    align: "center",
                    verticalAlign: "bottom",
                  },
                },
              },
            ],
          },
        },
      };

      //Set up a pool of PhantomJS workers
      exporter.initPool();

      //Perform an export
      /*
        Export settings corresponds to the available CLI arguments described
        above.
    */
      exporter.export(exportSettings, function(err, res) {
        if (err) console.error(err);

        //Kill the pool when we're done with it
        exporter.killPool();

        //    var data = getIcon(req.params.w);
        var img = new Buffer(res.data, "base64");

        response.writeHead(200, {
          "Content-Type": "image/png",
          "Content-Length": img.length,
        });
        return response.end(img);

        //return response.send(res.data);
        //response.redirect("/chart.pdf");
      });
    });
});

app.get("/dscr_forum_2.png", function(request, response) {
  //Export settings
  fetch(url + "/totaldscr/2")
    .then(res => res.json())
    .then(function(res) {
      const series = [
        {
          name: "Dscr Actuel",
          data: res.data.map(d => d.dscr_actuel),
        },
        {
          name: "Dscr Facial",
          data: res.data.map(d => d.dscr_facial_acte),
        },
        {
          name: "Dscr potentiel",
          data: res.data.map(d => d.dscr_potentiel),
        },
      ];

      var exportSettings = {
        type: "png",
        tmpdir: "views/",
        options: {
          chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: "line",
          },
          title: {
            text: "",
          },
          yAxis: {
            labels: {
              formatter: obj => `${obj.value} %`,
            },
            title: {
              text: "Valeur DSCR %",
            },
          },
          plotOptions: {
            series: {
              label: {
                connectorAllowed: false,
              },
              pointStart: res.data[0].annee_emprunt,
            },
          },
          series,
          responsive: {
            rules: [
              {
                condition: {
                  maxWidth: 500,
                },
                chartOptions: {
                  legend: {
                    layout: "horizontal",
                    align: "center",
                    verticalAlign: "bottom",
                  },
                },
              },
            ],
          },
        },
      };

      //Set up a pool of PhantomJS workers
      exporter.initPool();

      //Perform an export
      /*
        Export settings corresponds to the available CLI arguments described
        above.
    */
      exporter.export(exportSettings, function(err, res) {
        if (err) console.error(err);

        //Kill the pool when we're done with it
        exporter.killPool();

        //    var data = getIcon(req.params.w);
        var img = new Buffer(res.data, "base64");

        response.writeHead(200, {
          "Content-Type": "image/png",
          "Content-Length": img.length,
        });
        return response.end(img);

        //return response.send(res.data);
        //response.redirect("/chart.pdf");
      });
    });
});



app.get("/ca_regions.png", function(request, response) {
  //Export settings
  fetch(url + "/regions")
    .then(res => res.json())
    .then(function(res) {
      const { Paris, Banlieue, Province } = res.data;
      const total = parseInt(Paris, 10) + parseInt(Banlieue, 10) + parseInt(Province, 10);
      const data = [
        {
          name: "Paris",
          y: parseInt(parseInt(Paris, 10) * 100 / total, 10),
        },
        {
          name: "Banlieue",
          y: parseInt(parseInt(Banlieue, 10) * 100 / total, 10),
        },
        {
          name: "Province",
          y: parseInt(parseInt(Province, 10) * 100 / total, 10),
        },
      ];

      var exportSettings = {
        type: "png",
        tmpdir: "views/",
        options: {
          chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: "pie",
          },
          title: {
            text: "",
          },
          plotOptions: {
            pie: {
              allowPointSelect: true,
              cursor: "pointer",
              dataLabels: {
                enabled: false,
              },
              dataLabels: {
                enabled: true,
                format: "<b>{point.name}</b>: {point.y} %",
                style: {
                  color: "black",
                },
              },
              showInLegend: false,
            },
          },
          series: [
            {
              name: "Régions",
              colorByPoint: true,
              data,
            },
          ],
        },
      };

      //Set up a pool of PhantomJS workers
      exporter.initPool();

      //Perform an export
      /*
        Export settings corresponds to the available CLI arguments described
        above.
    */
      exporter.export(exportSettings, function(err, res) {
        if (err) console.error(err);

        //Kill the pool when we're done with it
        exporter.killPool();

        //    var data = getIcon(req.params.w);
        var img = new Buffer(res.data, "base64");

        response.writeHead(200, {
          "Content-Type": "image/png",
          "Content-Length": img.length,
        });
        return response.end(img);

        //return response.send(res.data);
        //response.redirect("/chart.pdf");
      });
    });
});

app.get("/crd_banque.png", function(request, response) {
  //Export settings
  const query = request.query.idbanque ? `?idbanque=${idbanque}` : '';
  fetch(url + "/crd" + query)
    .then(res => res.json())
    .then(function(res) {
      const categories = Object.keys(res.data).filter(k => k !== "Total_CRD");
      const seriesDatas = Object.keys(res.data)
        .filter(k => k !== "Total_CRD")
        .map(k => round(res.data[k] * 100 / res.data.Total_CRD, 2));
      //  console.log("Total_CRD", series);
      //response.send("ok");

      var exportSettings = {
        type: "png",
        tmpdir: "views/",
        options: {
          chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: "bar",
          },
          title: {
            text: "% sur total CRD",
          },
          plotOptions: {
            bar: {
              dataLabels: {
                enabled: true,
              },
              showInLegend: false,
              dataLabels: {
                enabled: true,
                format: "{point.y} %",
                style: {
                  color: "black",
                },
              },
            },
          },
          xAxis: {
            categories,
            allowDecimals: false,
          },
          yAxis: {
            title: "Pourcentage du CRD",
            allowDecimals: false,
          },
          series: [{ name: "test", data: seriesDatas }],
        },
      };

      //Set up a pool of PhantomJS workers
      exporter.initPool();

      //Perform an export
      /*
        Export settings corresponds to the available CLI arguments described
        above.
    */
      exporter.export(exportSettings, function(err, res) {
        if (err) console.error(err);

        //Kill the pool when we're done with it
        exporter.killPool();

        //    var data = getIcon(req.params.w);
        var img = new Buffer(res.data, "base64");

        response.writeHead(200, {
          "Content-Type": "image/png",
          "Content-Length": img.length,
        });
        return response.end(img);

        //return response.send(res.data);
        //response.redirect("/chart.pdf");
      });
    });
});

app.get("/synthese_generale_echeancier.png", function(request, response) {
  //Export settings
  fetch(url + "/total")
    .then(res => res.json())
    .then(function(res) {
      const categories = Object.keys(res.data.echeancier[0]);
      const seriesDatas = Object.keys(res.data.echeancier[0]).map(k =>
        parseInt(res.data.echeancier[0][k].echeance, 10),
      );

      var exportSettings = {
        type: "png",
        tmpdir: "views/",
        options: {
          chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: "bar",
            width: 800,
            height: 350,
          },
          title: {
            text: "Échéancier de remboursement (capital + intérêts)",
          },
          plotOptions: {
            bar: {
              dataLabels: {
                enabled: true,
              },
              showInLegend: false,
              dataLabels: {
                enabled: true,
                format: "{point.y:,.0f} €",
                style: {
                  color: "black",
                },
              },
            },
          },
          xAxis: {
            categories,
            allowDecimals: false,
          },
          yAxis: {
            title: "",
            allowDecimals: false,
          },
          // yAxis: {
          //   categories,
          //   crosshair: true,
          // },
          // plotOptions: {
          //   pie: {
          //     allowPointSelect: true,
          //     cursor: "pointer",
          //     dataLabels: {
          //       enabled: false,
          //     },
          //     dataLabels: {
          //       enabled: true,
          //       format: "<b>{point.name}</b>: {point.y} %",
          //       style: {
          //         color: "black",
          //       },
          //     },
          //     showInLegend: false,
          //   },
          // },
          series: [{ name: "test", data: seriesDatas }],
        },
      };

      //Set up a pool of PhantomJS workers
      exporter.initPool();

      //Perform an export
      /*
        Export settings corresponds to the available CLI arguments described
        above.
    */
      exporter.export(exportSettings, function(err, res) {
        if (err) console.error(err);

        //Kill the pool when we're done with it
        exporter.killPool();

        //    var data = getIcon(req.params.w);
        var img = new Buffer(res.data, "base64");

        response.writeHead(200, {
          "Content-Type": "image/png",
          "Content-Length": img.length,
        });
        return response.end(img);

        //return response.send(res.data);
        //response.redirect("/chart.pdf");
      });
    });
});

app.get("/synthese_generale_crd.png", function(request, response) {
  //Export settings
  fetch(url + "/total")
    .then(res => res.json())
    .then(function(res) {
      const categories = Object.keys(res.data.echeancier[0]);
      const seriesDatas = Object.keys(res.data.echeancier[0]).map(k =>
        parseInt(res.data.echeancier[0][k].capital_restant, 10),
      );

      var exportSettings = {
        type: "png",
        tmpdir: "views/",
        options: {
          chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: "bar",
            width: 800,
            height: 350,
          },
          title: {
            text: "Capital dû restant / an",
          },
          plotOptions: {
            bar: {
              dataLabels: {
                enabled: true,
              },
              showInLegend: false,
              dataLabels: {
                enabled: true,
                format: "{point.y:,.0f} €",
                style: {
                  color: "black",
                },
              },
            },
          },
          xAxis: {
            categories,
            allowDecimals: false,
          },
          yAxis: {
            title: "",
            allowDecimals: false,
          },
          // yAxis: {
          //   categories,
          //   crosshair: true,
          // },
          // plotOptions: {
          //   pie: {
          //     allowPointSelect: true,
          //     cursor: "pointer",
          //     dataLabels: {
          //       enabled: false,
          //     },
          //     dataLabels: {
          //       enabled: true,
          //       format: "<b>{point.name}</b>: {point.y} %",
          //       style: {
          //         color: "black",
          //       },
          //     },
          //     showInLegend: false,
          //   },
          // },
          series: [{ name: "test", data: seriesDatas }],
        },
      };

      //Set up a pool of PhantomJS workers
      exporter.initPool();

      //Perform an export
      /*
        Export settings corresponds to the available CLI arguments described
        above.
    */
      exporter.export(exportSettings, function(err, res) {
        if (err) console.error(err);

        //Kill the pool when we're done with it
        exporter.killPool();

        //    var data = getIcon(req.params.w);
        var img = new Buffer(res.data, "base64");

        response.writeHead(200, {
          "Content-Type": "image/png",
          "Content-Length": img.length,
        });
        return response.end(img);

        //return response.send(res.data);
        //response.redirect("/chart.pdf");
      });
    });
});

app.get("/repartition_geographique.png", function(request, response) {
  fetch(url + "/total")
    .then(res => res.json())
    .then(function(res) {
      const { surface_paris, surface_banlieue, surface_province } = res.data;
      const surface_totale = surface_banlieue + surface_province + surface_paris;
      const surface_paris_prct = round(surface_paris * 100 / surface_totale, 2);
      const surface_banlieue_prct = round(surface_banlieue * 100 / surface_totale, 2);
      const surface_province_prct = round(surface_province * 100 / surface_totale, 2);

      const data = [
        {
          name: "Paris",
          y: surface_paris_prct,
        },
        {
          name: "Banlieue",
          y: surface_banlieue_prct,
        },
        {
          name: "Province",
          y: surface_province_prct,
        },
      ];

      console.log("data", data);

      var exportSettings = {
        type: "png",
        tmpdir: "views/",
        options: {
          chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: "pie",
            width: 500,
            height: 280,
          },
          title: {
            text: "",
          },
          plotOptions: {
            pie: {
              allowPointSelect: true,
              cursor: "pointer",
              dataLabels: {
                enabled: false,
              },
              dataLabels: {
                enabled: true,
                format: "<b>{point.name}</b> : {point.y} %",
                style: {
                  color: "black",
                },
              },
              showInLegend: false,
            },
          },
          series: [
            {
              name: "Répartition géographique",
              colorByPoint: true,
              data,
            },
          ],
        },
      };

      //Set up a pool of PhantomJS workers
      exporter.initPool();

      //Perform an export
      /*
        Export settings corresponds to the available CLI arguments described
        above.
    */
      exporter.export(exportSettings, function(err, res) {
        if (err) console.error(err);

        //Kill the pool when we're done with it
        exporter.killPool();

        //    var data = getIcon(req.params.w);
        var img = new Buffer(res.data, "base64");

        response.writeHead(200, {
          "Content-Type": "image/png",
          "Content-Length": img.length,
        });
        return response.end(img);

        //return response.send(res.data);
        //response.redirect("/chart.pdf");
      });
    });
});

app.get("/repartition_loyer.png", function(request, response) {
  fetch(url + "/total")
    .then(res => res.json())
    .then(function(res) {
      const { loyer_vacant, loyer_actuel, complement_loyer } = res.data;
      const total = loyer_vacant + loyer_actuel + complement_loyer;
      console.log("total", res.data);
      const loyer_vacant_prct = round(loyer_vacant * 100 / total, 2);
      const loyer_actuel_prct = round(loyer_actuel * 100 / total, 2);
      const complement_loyer_prct = round(complement_loyer * 100 / total, 2);

      const data = [
        {
          name: "Loyer actuel",
          y: loyer_actuel_prct,
          value: loyer_actuel,
        },
        {
          name: "Loyer vacant",
          y: loyer_vacant_prct,
          value: loyer_vacant,
        },
        {
          name: "Complement loyer",
          y: complement_loyer_prct,
          value: complement_loyer,
        },
      ];

      var exportSettings = {
        type: "png",
        tmpdir: "views/",
        options: {
          chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: "pie",
            width: 500,
            height: 280,
          },
          title: {
            text: "",
          },
          plotOptions: {
            pie: {
              allowPointSelect: true,
              cursor: "pointer",
              dataLabels: {
                enabled: false,
              },
              dataLabels: {
                enabled: true,
                format: "<b>{point.name}</b> : {point.y} % (point.value)",
                style: {
                  color: "black",
                },
              },
              showInLegend: false,
            },
          },
          series: [
            {
              name: "Répartition loyers",
              colorByPoint: true,
              data,
            },
          ],
        },
      };

      //Set up a pool of PhantomJS workers
      exporter.initPool();

      //Perform an export
      /*
        Export settings corresponds to the available CLI arguments described
        above.
    */
      exporter.export(exportSettings, function(err, res) {
        if (err) console.error(err);

        //Kill the pool when we're done with it
        exporter.killPool();

        //    var data = getIcon(req.params.w);
        var img = new Buffer(res.data, "base64");

        response.writeHead(200, {
          "Content-Type": "image/png",
          "Content-Length": img.length,
        });
        return response.end(img);

        //return response.send(res.data);
        //response.redirect("/chart.pdf");
      });
    });
});
// listen for requests :)
var listener = app.listen(8084, function() {
  console.log("Your app is listening on port " + listener.address().port);
});
