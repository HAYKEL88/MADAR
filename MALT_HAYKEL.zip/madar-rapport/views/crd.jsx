const React = require("react");
import NumberFormat from "react-number-format";
var round = require("lodash/round");

// const queries = document.location.search.replace("?", "").split("&");
// const sansDonneesFinancement = queries[0] && queries[0].split("=")[1] === "1";
// const sansCouverture = queries[1] && queries[1].split("=")[1] === "1";
class Local extends React.Component {
  render() {
    const { idbanque } = this.props;
    const query = idbanque ? `?idbanque=${idbanque}` : '';
    const { crd } = this.props;
    return (
      <html lang="en" style={{ zoom: "0.55" }}>
        <head>
          <meta charSet="UTF-8" />
          <title>CA Activités</title>
          <link rel="stylesheet" href={`${this.props.cssUrl}rapport.css`} />
        </head>
        <body style={{ padding: "1em", fontSize: "1.4em" }}>
          <div className="row">
            <div className="col-xs-22 titre-adresse">Capital Restant Dûuuuuuuuu</div>
            <div className="col-xs-2">
              <img src={`${this.props.urlAssets}madar.png`} alt="logo madar" height="auto" width="100%" />
            </div>
          </div>
          <div className="row">
            <div className="col-xs-24">
              <table className="tableDscr">
                <thead>
                  <tr>
                    <th className="thDscr">Banque</th>
                    <th className="thDscr">CRD</th>
                    <th className="thDscr">% sur total CRD</th>
                  </tr>
                </thead>
                <tbody>
                  {Object.keys(crd)
                    .filter(k => k !== "Total_CRD")
                    .map(k => (
                      <tr>
                        <td className="tdDscr">{k}</td>
                        <td className="tdDscr">{crd[k]}</td>
                        <td className="tdDscr">{round(crd[k] * 100 / crd.Total_CRD, 2)} %</td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
            <div className="col-xs-24 txtC">
              {/* url chargée en temps réel*/}
              <img src={"http://localhost:8084/crd_banque.png" + query} />
            </div>
          </div>
        </body>
      </html>
    );
  }
}

module.exports = Local;
