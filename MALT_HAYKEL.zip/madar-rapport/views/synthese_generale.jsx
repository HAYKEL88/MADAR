const React = require("react");
import NumberFormat from "react-number-format";
var round = require("lodash/round");
const nF = value => (
  <NumberFormat
    value={parseInt(value, 10)}
    displayType={"text"}
    thousandSeparator=" "
    suffix={" €"}
  />
);

// const queries = document.location.search.replace("?", "").split("&");
// const sansDonneesFinancement = queries[0] && queries[0].split("=")[1] === "1";
// const sansCouverture = queries[1] && queries[1].split("=")[1] === "1";
class Local extends React.Component {
  render() {
    const { datas, idsociete } = this.props;
    const [dscr_actuel, dscr_facial, dscr_potentiel, ltv, ltc] = [
      26,
      72,
      250,
      145,
      36
    ];
    
    let societe = 'PARDES & FORUM';
    if (idsociete) {
        societe = idsociete === '1' ? 'PARDES' : 'FORUM';  
    }
    //idsociete === 1 ? 'PARDES' : 'FORUM";
    console.log(idsociete);
    
    return (
      <html lang="en" style={{ zoom: "0.55" }}>
        <head>
          <meta charSet="UTF-8" />
          <title>CA Activités</title>
          <link rel="stylesheet" href={`${this.props.cssUrl}rapport.css`} />
        </head>
        <body style={{ padding: "1em", fontSize: "1.3em" }}>
          <div className="row">
            <div className="col-xs-22">
              <div className="row">
                <div className="col-xs-24 titre-adresse">
                  SYNTHESE GENERALE {societe}
                </div>
              </div>
            </div>
            <div className="col-xs-2" style={{ position: "relative" }}>
              <div style={{ position: "absolute" }}>
                <img src={`${this.props.urlAssets}madar.png`} alt="logo madar" height="auto" width="60%" />
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-xs-12">
              <div className="row">
                <div className="col-xs-1 titre-ligne titre-lLoca">
                  <div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;LOCAUX</div>
                </div>
                <div className="col-xs-23">
                  <div className="row">
                    <div className="col-xs-18 col-xs-offset-1 mT">
                      <div className="row bb">
                        <div className="col-xs-16">
                          <strong>Nombre de Locaux</strong>
                        </div>
                        <div className="col-xs-8 txtR">
                          {datas.nombre_locaux}
                        </div>
                      </div>
                      <div className="row bb">
                        <div className="col-xs-16">
                          <strong>Surface totale</strong>
                        </div>
                        <div className="col-xs-8 txtR">
                          {nF(datas.surface_totale)}
                        </div>
                      </div>
                      <div className="row bb">
                        <div className="col-xs-12">
                          <strong>Prix de revient</strong>
                        </div>
                        <div className="col-xs-12 txtR">
                          {nF(datas.prix_revient)}
                        </div>
                      </div>
                      <div className="row bb">
                        <div className="col-xs-16">
                          <strong>Taux de capitalisation</strong>
                        </div>
                        <div className="col-xs-8 txtR">
                          {datas.taux_capitalisation} %
                        </div>
                      </div>
                      <div className="row bb">
                        <div className="col-xs-12">
                          <strong>Valeur vénale</strong>
                        </div>
                        <div className="col-xs-12 txtR">
                          {nF(datas.valeur_venal)}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-xs-24 txtC mT">
                    <img src="http://localhost:8080/ebdcf383-63a6-4bc4-8dea-bf93e9f7c17b/repartition_geographique.png" />
                  </div>
                </div>
              </div>
            </div>
            <div className="col-xs-12">
              <div className="row">
                <div className="col-xs-1 titre-ligne titre-lLoca">
                  <div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;LOCATIF</div>
                </div>
                <div className="col-xs-23">
                  <div className="row">
                    <div className="col-xs-18 col-xs-offset-1 mT">
                      <div className="row bb">
                        <div className="col-xs-16">
                          <strong>Loyer actuel</strong>
                        </div>
                        <div className="col-xs-8 txtR">
                          {nF(datas.loyer_actuel)}
                        </div>
                      </div>
                      <div className="row bb">
                        <div className="col-xs-16">
                          <strong>Complément de loyer</strong>
                        </div>
                        <div className="col-xs-8 txtR">
                          {nF(datas.complement_loyer)}
                        </div>
                      </div>
                      <div className="row bb">
                        <div className="col-xs-12">
                          <strong>Loyer sur vacant</strong>
                        </div>
                        <div className="col-xs-12 txtR">
                          {nF(datas.loyer_vacant)}
                        </div>
                      </div>
                      <div className="row bb">
                        <div className="col-xs-16">
                          <strong>Revenu facial</strong>
                        </div>
                        <div className="col-xs-8 txtR">
                          {nF(datas.revenu_facial)}
                        </div>
                      </div>
                      <div className="row bb">
                        <div className="col-xs-12">
                          <strong>Valeur locative</strong>
                        </div>
                        <div className="col-xs-12 txtR">
                          {nF(datas.valeur_locative)}
                        </div>
                      </div>
                      <div className="row bb">
                        <div className="col-xs-16">
                          <strong>Frais de gestion</strong>
                        </div>
                        <div className="col-xs-8 txtR">
                          {nF(datas.frais_gestion)}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-xs-24 mT">
                      <img src="http://localhost:8080/ebdcf383-63a6-4bc4-8dea-bf93e9f7c17b/repartition_loyer.png" />
                    </div>
                    <div className="col-xs-18 col-xs-offset-3 mT">
                      <div className="row">
                        <div className="col-xs-12 bt bl br bb">
                          <strong>Loyer actuel</strong>
                        </div>
                        <div className="col-xs-12 bt bl br bb txtR">
                          {nF(datas.loyer_actuel)}
                        </div>
                        <div className="col-xs-12 bl br bb">
                          <strong>Loyer sur vacant</strong>
                        </div>
                        <div className="col-xs-12 bl br bb txtR">
                          {nF(datas.loyer_vacant)}
                        </div>
                        <div className="col-xs-12 bl br bb">
                          <strong>Complement de loyer</strong>
                        </div>
                        <div className="col-xs-12 bl br bb txtR">
                          {nF(datas.complement_loyer)}
                        </div>
                        <br />
                        <div className="col-xs-12 bt bl br bb">
                          <strong>Loyer potentiel</strong>
                        </div>
                        <div className="col-xs-12 bt bl br bb txtR">
                          {nF(
                            datas.loyer_actuel +
                              datas.loyer_vacant +
                              datas.complement_loyer
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-xs-8 col-xs-offset-2" style={{ paddingTop: '12em' }}>
              <div className="row bb">
                <div className="col-xs-16">
                  <strong>Nombre de Locaux</strong>
                </div>
                <div className="col-xs-8 txtR">{datas.nombre_locaux}</div>
              </div>
              <div className="row bb">
                <div className="col-xs-16">
                  <strong>Surface totale</strong>
                </div>
                <div className="col-xs-8 txtR">{nF(datas.surface_totale)}</div>
              </div>
              <div className="row bb">
                <div className="col-xs-12">
                  <strong>Prix de revient</strong>
                </div>
                <div className="col-xs-12 txtR">{nF(datas.prix_revient)}</div>
              </div>
            </div>
            <div
              className="col-xs-8 col-xs-offset-2 txtC"
              id="graphique"
              style={{ position: "relative", height: "350px" }}
            >
              <div
                style={{
                  position: "absolute",
                  bottom: 0,
                  left: 40,
                  width: 10,
                  height: 10,
                  backgroundColor: "cyan"
                }}
              />
              <div style={{ position: "absolute", left: 52, bottom: -5 }}>
                Actuel
              </div>
              <div
                style={{
                  position: "absolute",
                  bottom: 0,
                  left: 95,
                  width: 10,
                  height: 10,
                  backgroundColor: "blue"
                }}
              />
              <div style={{ position: "absolute", left: 107, bottom: -5 }}>
                Facial
              </div>
              <div
                style={{
                  position: "absolute",
                  bottom: 0,
                  left: 150,
                  width: 10,
                  height: 10,
                  backgroundColor: "orange"
                }}
              />
              <div style={{ position: "absolute", left: 163, bottom: -5 }}>
                Potentiel
              </div>
              <div
                style={{
                  position: "absolute",
                  bottom: 0,
                  left: 250,
                  width: 10,
                  height: 10,
                  backgroundColor: "blue"
                }}
              />
              <div style={{ position: "absolute", left: 265, bottom: -5 }}>
                LTV
              </div>
              <div
                style={{
                  position: "absolute",
                  bottom: 0,
                  left: 295,
                  width: 10,
                  height: 10,
                  border: "solid 1px black",
                  backgroundColor: "orange"
                }}
              />
              <div style={{ position: "absolute", left: 310, bottom: -5 }}>
                LTC
              </div>
              <div
                id="actuel_bar"
                style={{
                  position: "absolute",
                  width: "30px",
                  bottom: 15,
                  left: 70,
                  height: parseInt(dscr_actuel, 10),
                  backgroundColor: "cyan"
                }}
              />
              {dscr_actuel !== "0" && (
                <div
                  style={{
                    position: "absolute",
                    bottom: parseInt(dscr_actuel, 10) + 15,
                    left: 70,
                    fontSize: "9px"
                  }}
                >
                  {parseInt(dscr_actuel, 10)} %
                </div>
              )}
              <div
                id="facial_bar"
                style={{
                  position: "absolute",
                  width: "30px",
                  bottom: 15,
                  left: 105,
                  height: parseInt(dscr_facial, 10),
                  backgroundColor: "blue"
                }}
              />
              {dscr_facial !== "0" && (
                <div
                  style={{
                    position: "absolute",
                    bottom: parseInt(dscr_facial, 10) + 15,
                    left: 105,
                    fontSize: "9px"
                  }}
                >
                  {parseInt(dscr_facial, 10)} %
                </div>
              )}
              <div
                id="potentiel_bar"
                style={{
                  position: "absolute",
                  width: "30px",
                  bottom: 15,
                  left: 140,
                  height: parseInt(dscr_potentiel, 10),
                  backgroundColor: "orange"
                }}
              />
              {dscr_potentiel !== "0" && (
                <div
                  style={{
                    position: "absolute",
                    bottom: parseInt(dscr_potentiel, 10) + 15,
                    left: 140,
                    fontSize: "9px"
                  }}
                >
                  {parseInt(dscr_potentiel, 10)} %
                </div>
              )}
              <div
                id="LTV_bar"
                style={{
                  position: "absolute",
                  width: "30px",
                  bottom: 15,
                  left: 255,
                  height: parseInt(ltv, 10),
                  backgroundColor: "blue"
                }}
              />
              {ltv !== "0" && (
                <div
                  style={{
                    position: "absolute",
                    bottom: parseInt(ltv, 10) + 15,
                    left: 255,
                    fontSize: "9px"
                  }}
                >
                  {parseInt(ltv, 10)} %
                </div>
              )}
              <div
                id="LTC_bar"
                style={{
                  position: "absolute",
                  width: "30px",
                  bottom: 15,
                  left: 290,
                  height: parseInt(ltc, 10),
                  backgroundColor: "orange"
                }}
              />
              {ltv !== "0" && (
                <div
                  style={{
                    position: "absolute",
                    bottom: parseInt(ltc, 10) + 15,
                    left: 295,
                    fontSize: "9px"
                  }}
                >
                  {parseInt(ltc, 10)} %
                </div>
              )}
              <div
                id="titre_dscr"
                style={{
                  position: "absolute",
                  top: 20,
                  left: 45,
                  fontSize: 16,
                  width: 150
                }}
              >
                DSCR
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-xs-24 txtC">
              <img src="http://localhost:8080/ebdcf383-63a6-4bc4-8dea-bf93e9f7c17b/synthese_generale_echeancier.png" />
            </div>
          </div>
          <div className="row">
            <div className="col-xs-24 txtC">
              <img src="http://localhost:8080/ebdcf383-63a6-4bc4-8dea-bf93e9f7c17b/synthese_generale_crd.png" />
            </div>
          </div>
        </body>
      </html>
    );
  }
}

module.exports = Local;
