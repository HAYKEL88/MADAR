import React, { Component } from "react";
import PropTypes from "prop-types";
import { withRouter } from "react-router-dom";
import Grid from "@material-ui/core/Grid";

import Local from "./Local";
import Centered from "../../layout/Centered";
import RechercheForm from "../../common/RechercheForm";
import ListItemsMobile from "../../common/ListItemsMobile";
import SwipeableViews from "react-swipeable-views";

class Locaux extends Component {
  static propTypes = {
    history: PropTypes.object.isRequired
  };

  constructor(props) {
    super(props);
    this.state = {
      index: this.findSwipeableViewsIndex(props)
    };
    window.scrollTo(0, 0);
  }

  componentWillReceiveProps = nextProps => {
    const {
      match: {
        params: { localId }
      },
      location: { search }
    } = this.props;
    if (
      search !== nextProps.location.search ||
      localId !== nextProps.match.params.localId
    ) {
      this.setState({ index: this.findSwipeableViewsIndex(nextProps) });
    }
  };

  findSwipeableViewsIndex = props => {
    if (props.location.search === "" && props.match.params.localId) {
      return 2;
    }
    if (props.location.search !== "" && !props.match.params.localId) {
      return 1;
    }
    if (props.location.search === "" && !props.match.params.localId) {
      return 0;
    }
  };

  render() {
    const {
      match: {
        params: { localId }
      },
      user
    } = this.props;
    if (!user || !user.login) return <h1>Acces denied</h1>;

    const { index } = this.state;

    return (
      <Centered alignItems="center" justify="center">
        <Grid item xs={12}>
          <SwipeableViews index={index} animateHeight>
            <RechercheForm
              idField="idlocal"
              idFieldName="Id du local"
              moduleRoute="locaux_mobile"
            />
            <ListItemsMobile
              idField="idlocal"
              buildPrimaryText={a => `${a.idlocal} - ${a.adresse}`}
              buildSecondaryText={a =>
                `${a.code_postal} ${a.ville} - ${a.surface_totale_actif} m²`
              }
              moduleRoute="locaux_mobile"
              queryPathname="/locaux/"
            />
            <div style={{ padding: "0 8px" }}>
              <Local localId={localId} />
            </div>
          </SwipeableViews>
        </Grid>
      </Centered>
    );
  }
}

export default withRouter(Locaux);
