import React from "react";
import Grid from "@material-ui/core/Grid";
import PropTypes from "prop-types";
import { withStyles } from "@material-ui/core/styles";
import AppBar from "@material-ui/core/AppBar";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import Typography from "@material-ui/core/Typography";
import Centered from "../../layout/Centered";
import Synthese from "./Synthese";
import Remboursement from "./Remboursement";
import Crd from "./Crd";
// https://you-fleet.fr/patrimonial/public/rapports/crd

function TabContainer(props) {
  return (
    <Typography component="div" style={{ padding: 8 * 3, minHeight: 300 }}>
      {props.children}
    </Typography>
  );
}

TabContainer.propTypes = {
  children: PropTypes.node.isRequired,
};

const styles = theme => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper,
    width: "80%",
  },
});

class Rapports extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      index: 0,
    };
  }

  handleChange = (event, index) => {
    this.setState({ index });
  };

  render() {
    const { index } = this.state;
    const rendererHost = "/pdfs";
    return (
      <Centered alignItems="flex-start" justify="center">
        <Grid item xs={6}>
          <div className={this.props.classes.root}>
            <AppBar position="static">
              <Tabs value={index} onChange={this.handleChange} centered>
                <Tab label="Synthèse" />
                <Tab label="CRD par banque" />
                <Tab label="Profil de remboursement" />
              </Tabs>
            </AppBar>
            {index === 0 && (
              <TabContainer>
                <Synthese rendererHost={rendererHost} />
              </TabContainer>
            )}
            {index === 1 && (
              <TabContainer>
                <Crd rendererHost={rendererHost} />
              </TabContainer>
            )}
            {index === 2 && (
              <TabContainer>
                <Remboursement rendererHost={rendererHost} />
              </TabContainer>
            )}
          </div>
        </Grid>
      </Centered>
    );
  }
}

export default withStyles(styles)(Rapports);
