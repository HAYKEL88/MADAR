import React from "react";
import { withStyles } from "@material-ui/core/styles";
import { Link } from "react-router-dom";
import moment from "moment";
import Grid from "@material-ui/core/Grid";
import Badge from "@material-ui/core/Badge";
import MenuList from "@material-ui/core/MenuList";
import MenuItem from "@material-ui/core/MenuItem";
import CircularProgress from "@material-ui/core/CircularProgress";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import IconButton from "@material-ui/core/IconButton";
import HistoryIcon from '@material-ui/icons/History';
import DeleteIcon from "@material-ui/icons/Delete";
import NotificationIcon from "@material-ui/icons/Notifications";
import Drawer from "@material-ui/core/Drawer";
import Typography from "@material-ui/core/Typography";
import withGlobals from "./withGlobals";
import GroupBy from "lodash/groupBy";
import ConfirmWrapper from "../common/ConfirmWrapper";
import Logo from "./logo.jpg";

const styles = theme => ({
  title: {
    marginTop: theme.spacing.unit * 4,
    marginBottom: theme.spacing.unit * 4
  },
  container: {
    height: "calc(100vh - 150px)",
    overflowY: "hidden"
  },
  notificationContainer: {
    overflowY: "auto"
  },
  notification: {
    padding: theme.spacing.unit * 1,
    backgroundColor: "#eaeaea",
    boxShadow: "3px 3px 3px gray",
    textAlign: "left",
    marginBottom: theme.spacing.unit * 2,
    minWidth: "600px;"
  },
  link: {
    "&:hover": {
      textDecoration: "none"
    },
    color: "black"
  },
  palier: {
    backgroundColor: "blue"
  },
  taux: {
    backgroundColor: "black"
  },
  baux: {
    backgroundColor: "green"
  },
  preavis: {
    backgroundColor: "red"
  },
  palierS: {
    borderLeft: "4px solid blue"
  },
  tauxS: {
    borderLeft: "4px solid black"
  },
  bauxS: {
    borderLeft: "4px solid green"
  },
  preavisS: {
    borderLeft: "4px solid red"
  },
  infoS: {
    borderLeft: "4px solid brown"
  },
  euribor: {
    border: "solid 2px black",
    padding: theme.spacing.unit * 1,
    marginTop: theme.spacing.unit * 2
  },
  excelLink: {
    lineHeight: "25px",
    color: "#247729"
  },
  rapportLinks: {
    listStyleType: "none",
    padding: theme.spacing.unit * 1
  },
  titreHisto: {
    textAlign: "center",
    paddingTop: theme.spacing.unit * 1
  }
});

const colors = {
  palier: "blue",
  taux: "black",
  baux: "green",
  preavis: "red",
  info: "brown"
};

/**
 * Find the most recent xlsx rapport coming from /rapports/excel
 * @param {[]} rapports 
 */
const getAsideRapportLink = rapports => {
  return rapports.filter(rapport => rapport.file.includes('.xlsx'))
    .map(rapport => { rapport.date = moment(rapport.creation_date); return rapport; })
    .sort((r1, r2) => r2.date.valueOf() - r1.date.valueOf())
    .shift();
}

const titres = {
  palier: "PALIERS",
  baux: "BAUX",
  preavis: "PRÉAVIS"
};

class ListeNotificationsMadar extends React.Component {
  state = {
    notifications: [],
    rapports: [],
    loaded: false,
    historiqueOpen: false
  };

  componentDidMount() {
    this.props.fetch({ url: "/rapports/excel" }).then(rapports => {
      this.setState({
        rapports: rapports.sort((r1, r2) => {
          if (r1.file > r2.file) return -1;
          if (r1.file < r2.file) return 1;
          return 0;
        }),
        asideRapportLink: getAsideRapportLink(rapports)
      });

      this.props.fetch({ url: "/notifications/" }).then(notifications => {
        const hardcodedNotif = notifications && notifications.length && notifications.length > 0 ? notifications : [];
        const notificationsGrouped = GroupBy(hardcodedNotif, "type");
        const types = Object.keys(notificationsGrouped)
          .filter(k => k !== "Euribor")
          .map(k => ({
            k,
            qte: notificationsGrouped[k].length
          }))
          .sort((t2, t1) => {
            if (t1.qte > t2.qte) return 1;
            if (t1.qte < t2.qte) return -1;
            return 0;
          });
        this.setState({
          loaded: true,
          notifications: hardcodedNotif,
          types,
          typeSelected: types && types.length && types.length > 0 && types[0].k
        });
      });
    });
  }

  handleDelete = idnotification => {
    const { notifications } = this.state;
    this.props
      .fetch({
        url: `/notifications/${idnotification}`,
        method: "DELETE"
      })
      .then(() =>
        this.setState({
          notifications: notifications.filter(
            n => n.idnotification !== idnotification
          )
        })
      );
  };

  buildRapportLink = rapport => {
	  if(rapport.file.includes(".pdf")){
		  return;
	  }
    const rapportsUrl = process.env.REACT_APP_DOMAIN + "/files/export/";
    const split = rapport.file
      .replace(".xlsx", "")
      .replace("_", " ")
      .replace("_", " ")
      .split(" ");

    return (
      <a
        className={this.props.classes.excelLink}
        // config url du site madar
        href={`${rapportsUrl}/${rapport.file}`}
      >
        {split[0]} {split[1]} du {moment(split[2]).format("DD/MM/YYYY")}
      </a>
    );
  };

  handleSelectType = typeSelected => this.setState({ typeSelected });

  openDrawer = () => this.setState({ historiqueOpen: true });

  closeDrawer = () => this.setState({ historiqueOpen: false });

  render() {
    const { classes, readOnly } = this.props;
    const {
      types,
      typeSelected,
      notifications,
      rapports,
      loaded,
      historiqueOpen,
      asideRapportLink
    } = this.state;

    if (!loaded) {
      return (
        <Grid
          container
          direction="column"
          alignItems="center"
          justify="center"
          spacing={0}
        >
          <Grid item className={classes.title}>
            <Typography variant="headline">Nouvelles notifications</Typography>
            <br />
            <CircularProgress size={50} />
          </Grid>
        </Grid>
      );
    }
    const majTaux = notifications
      .filter(n => n.type === "Euribor")
      .sort((n1, n2) => {
        if (n1.idnotification > n2.idnotification) return 1;
        if (n1.idnotification < n2.idnotification) return -1;
        return 0;
      });
    if (majTaux && majTaux.length > 0) {
      console.log("idnotification", majTaux[0].idnotification);
    }
    const euribor = majTaux.length > 0 ? JSON.parse(majTaux[0].message) : null;
    euribor.date_notification = moment(majTaux[0].date_notification).format("DD/MM/YYYY");
    const selectedNotifications = notifications
      .filter(n => n.type !== "Euribor")
      .filter(n => n.type === typeSelected);

    return (
      <div>
        <Drawer anchor="right" open={historiqueOpen} onClose={this.closeDrawer}>
          <Grid
            container
            justify="flex-start"
            alignItems="center"
            direction="column"
            spacing={0}
          >
            <Grid item className={classes.titreHisto}>
              <img src={Logo} alt="logo madar" width="150px" />
              <Typography variant="subheading">
                Historique des synthèses
              </Typography>
            </Grid>
            <Grid item>
              <ul className={classes.rapportLinks}>
                {rapports.map(r => <li>{this.buildRapportLink(r)}</li>)}
              </ul>
            </Grid>
          </Grid>
        </Drawer>
        <Grid
          container
          direction="column"
          alignItems="center"
          justify="center"
          spacing={0}
        >
          <Grid item className={classes.title}>
            <Typography variant="headline">Nouvelles notifications</Typography>
          </Grid>
          <Grid item>
            <Grid
              container
              alignItems="flex-start"
              justify="flex-start"
              direction="row"
              spacing={16}
            >
              <Grid item>
                <Typography variant="body1">
                  {rapports.length > 0 && [
                    <IconButton
                      onClick={this.openDrawer}
                      title="Afficher l'historique"
                    >
                      <HistoryIcon />
                    </IconButton>,
                    "  ",
                    this.buildRapportLink(asideRapportLink)
                  ]}
                </Typography>
                <MenuList>
                  {types &&
                    types.map(type => (
                      <MenuItem
                        selected={type.k === typeSelected}
                        key={type.k}
                        classes={{ selected: classes[`${type.k}S`] }}
                        onClick={() => this.handleSelectType(type.k)}
                      >
                        <ListItemText inset primary={titres[type.k]} />
                        <ListItemIcon className={classes.icon}>
                          <Badge
                            badgeContent={type.qte}
                            classes={{ colorPrimary: classes[type.k] }}
                            color="primary"
                          >
                            <NotificationIcon />
                          </Badge>
                        </ListItemIcon>
                      </MenuItem>
                    ))}
                </MenuList>
              </Grid>
              <Grid item>
                <Grid
                  container
                  alignItems="flex-start"
                  justify="stretch"
                  direction="column"
                >

                  {euribor && (
                    <Grid item style={{ minWidth: "600px" }}>
                      <Grid
                        container
                        alignItems="flex-end"
                        justify="center"
                        direction="column"
                      >
                        <Grid item>
                          <Typography variant="body">
                            Euribor 3M {euribor.date_notification}
                            <br />
                            <strong>{euribor.taux_euribor} %</strong>
                          </Typography>
                        </Grid>
                      </Grid>
                    </Grid>
                  )}
                  {selectedNotifications.length === 0 &&
                    <Grid item>
                      <Grid
                        container
                        alignItems="center"
                        justify="space-between"
                        direction="column"
                      >
                        <Grid
                          item
                          className={classes.notification}
                        >
                          <div
                            style={{
                              lineHeight: "36px",
                              fontSize: "0.8em",
                              textAlign: "center"
                            }}
                          >
                            Pas de notifications
                          </div>
                        </Grid>
                      </Grid>
                    </Grid>
                  }
                  {selectedNotifications.map(n => (
                    <Grid item>
                      <Grid
                        container
                        alignItems="center"
                        justify="space-between"
                        direction="column"
                      >
                        <Grid
                          item
                          className={classes.notification}
                          style={{
                            borderLeft: `10px solid ${colors[n.type]}`
                          }}
                        >
                          <Grid
                            container
                            direction="row"
                            alignItems="center"
                            justify="space-between"
                          >
                            <Grid
                              item
                              sm={readOnly ? 12 : 11}
                              style={{ textAlign: "right" }}
                            >
                              {n.lien ? (
                                <Link
                                  to={n.lien}
                                  style={{
                                    textDecoration: "none",
                                    color: "black"
                                  }}
                                >
                                  <div
                                    style={{
                                      lineHeight: "36px",
                                      fontSize: "0.8em",
                                      textAlign: "right"
                                    }}
                                  >
                                    {n.message}
                                  </div>
                                </Link>
                              ) : (
                                  <div
                                    style={{
                                      lineHeight: "36px",
                                      fontSize: "0.8em",
                                      textAlign: "right"
                                    }}
                                  >
                                    {n.message}
                                  </div>
                                )}
                            </Grid>
                            {!readOnly && (
                              <Grid item sm={1} style={{ textAlign: "right" }}>
                                <ConfirmWrapper
                                  onAccept={() =>
                                    this.handleDelete(n.idnotification)
                                  }
                                  message="Supprimer cette notification ?"
                                  title="Suppression d'une notification"
                                >
                                  <IconButton title="Supprimer cette notification">
                                    <DeleteIcon />
                                  </IconButton>
                                </ConfirmWrapper>
                              </Grid>
                            )}
                          </Grid>
                        </Grid>
                      </Grid>
                    </Grid>
                  ))}
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      </div>
    );
  }
}

export default withStyles(styles)(withGlobals(ListeNotificationsMadar));
