const filter = (props, state) => {
  const { datas } = props;
  const { idemprunt, idactifpatrimonial, nom_portefeuille, adresse } = state;
  const filter = idemprunt !== "" || idactifpatrimonial !== "" || nom_portefeuille !== "" || adresse !== "";

  const datasFiltred = filter
    ? datas.filter(b => {
        let show = true;

        if (idemprunt !== "" && show) show = `${b.idemprunt}` === idemprunt;
        if (idactifpatrimonial !== "" && show) show = `${b["idactifpatrimonial"]}` === idactifpatrimonial;
        if (adresse !== "" && show) show = `${b.adresse.toLowerCase()}`.indexOf(adresse.toLowerCase()) !== -1;
        if (nom_portefeuille !== "" && show)
          show = `${b.nom_portefeuille}`.toLowerCase().indexOf(nom_portefeuille.toLowerCase()) !== -1;

        return show;
      })
    : datas;

  return { datasFiltred, filter };
};

export default filter;
