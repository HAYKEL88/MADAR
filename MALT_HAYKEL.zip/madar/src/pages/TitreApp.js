import React from "react";
import Button from "@material-ui/core/Button";
import { withStyles } from "@material-ui/core/styles";
import { withRouter } from "react-router-dom";

const styles = theme => ({
  flex: {
    flex: 1
  },
  redBg: {
    color: "#FFF",
    fontSize: "1.1em"
  }
});

const TitreApp = ({ history, user, classes, location: { pathname } }) => {
  return (
    <div className={classes.flex}>
      <Button
        title="Retour à l'accueil"
        className={pathname !== "/" ? classes.redBg : null}
        onClick={() => history.push("/")}
      >
        {"Madar Patrimoine"}
      </Button>
    </div>
  );
};

export default withStyles(styles)(withRouter(TitreApp));
