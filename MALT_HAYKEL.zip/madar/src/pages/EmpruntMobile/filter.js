const filter = (datas, recherche) => {
  const { idinvestissement, idactifpatrimonial, nom_portefeuille, code_postal, ville, adresse } = recherche;

  const filter =
    idinvestissement !== "" ||
    idactifpatrimonial !== "" ||
    nom_portefeuille !== "" ||
    code_postal !== "" ||
    ville !== "" ||
    adresse !== "";
  return filter
    ? datas.filter(b => {
        let show = true;
        const a = b.portefeuille.actifs[0];

        if (idinvestissement !== "" && show) show = `${b.idinvestissement}` === idinvestissement;
        if (idactifpatrimonial !== "" && show) show = `${a.idactifpatrimonial}` === idactifpatrimonial;
        if (nom_portefeuille !== "" && show) show = `${a.nom_portefeuille}` === nom_portefeuille;
        if (code_postal !== "" && show) show = `${a.code_postal}` === code_postal;
        if (adresse !== "" && show) show = `${a.adresse.toLowerCase()}`.indexOf(adresse.toLowerCase()) !== -1;
        if (ville !== "" && show) show = `${a.ville}`.toUpperCase() === ville.toUpperCase();

        return show;
      })
    : datas;
};

export default filter;
