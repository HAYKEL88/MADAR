import React, { Component } from "react";
import { withRouter } from "react-router-dom";
import { withStyles } from "@material-ui/core/styles";
import AmortissementCouverture from "../Emprunt/AmortissementCouverture";
import withGlobals from "../withGlobals";

const styles = theme => ({
  adresse: {
    padding: theme.spacing.unit * 2,
    fontWeight: "bold",
  },
  actions: {
    display: "flex",
  },
  label: {
    textAlign: "left",
    paddingLeft: theme.spacing.unit,
  },
  value: {
    textAlign: "right",
    padding: `0 ${theme.spacing.unit}px ${theme.spacing.unit}px 0`,
    fontWeight: "bold",
  },
  separation: {
    color: "silver",
  },
  content: {
    paddingTop: 0,
    paddingBottom: 0,
  },
  header: {
    paddingBottom: 0,
    textAlign: "left",
  },
  financement: {
    marginTop: theme.spacing.unit * 2,
  },
  details: {
    marginBottom: theme.spacing.unit * 2,
  },
});

class DetailsTrancheEmpruntMobile extends Component {
  state = {
    loadingAmortissements: true,
    amortissements: [],
    couverture: [],
  };

  componentDidMount() {
    this.props
      .fetch({
        url: `/amortissements/${this.props.emprunt.idamortissement}`,
      })
      .then(res => {
        const amortissements = JSON.parse(res.amortissements);
        const couverture = res.couverture ? JSON.parse(res.couverture) : [];
        this.setState({
          loadingAmortissements: false,
          amortissements,
          couverture,
        });
      })
      .catch(e => {
        console.log("error", e);
        this.setState({
          loadingAmortissements: false,
          amortissements: [],
          couverture: [],
        });
      });
  }

  componentDidUpdate = () => {
    window.scrollTo(0, 0);
  };

  render() {
    console.log("tranches");
    const { emprunt } = this.props;
    const { amortissements, couverture, loadingAmortissements } = this.state;
    console.log(loadingAmortissements, emprunt, couverture, amortissements);
    if (loadingAmortissements || amortissements.length === 0) {
      return null;
    }
    console.log("ici...");
    return (
      <AmortissementCouverture
        layout="mobile"
        emprunt={emprunt}
        amortissements={amortissements}
        couverture={couverture}
      />
    );
  }
}

export default withStyles(styles)(withRouter(withGlobals(DetailsTrancheEmpruntMobile)));
