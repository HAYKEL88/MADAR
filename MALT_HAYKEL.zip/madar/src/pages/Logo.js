import React from "react";
import { withStyles } from "@material-ui/core/styles";
import Grid from "@material-ui/core/Grid";
import LogoImg from "./logo.jpg";

const styles = theme => ({
  container: {
    height: "calc(100vh - 150px)"
  }
});

const Logo = ({ classes }) => {
  return (
    <Grid
      container
      alignItems="center"
      justify="center"
      className={classes.container}
    >
      <Grid item>
        <img
          src={LogoImg}
          alt="logo du groupe Madar"
          style={{ width: "80%" }}
        />
      </Grid>
    </Grid>
  );
};

export default withStyles(styles)(Logo);
