const filter = (props, state) => {
  const { datas } = props;
  const {
    societe,
    idbail,
    idactifpatrimonial,
    codePostal,
    ville,
    adresse,
    surfaceTotale,
    biensNonAcquis,
  } = state;

  const datasSociete = societe ? datas.filter(b => b.idsociete === societe) : datas;
  const datasSocieteF = biensNonAcquis
    ? datasSociete.filter(b => {
        return b.date_acquisition === null;
      })
    : datasSociete;

  const filter =
    idbail !== "" ||
    idactifpatrimonial !== "" ||
    codePostal !== "" ||
    ville !== "" ||
    adresse !== "" ||
    surfaceTotale !== "";
  const datasFiltred = filter
    ? datasSocieteF.filter(b => {
        let show = true;
        if (surfaceTotale !== "") {
          const [sC, value] = surfaceTotale.split(" ");
          const valueNum = parseInt(value, 10);
          if (Number.isNaN(valueNum) || (sC !== ">" && sC !== "<")) show = true;
          const val = parseInt(b.surface_totale || b.surface_totale_actif, 10);
          if (sC === ">") show = val > valueNum;
          if (sC === "<") show = val < valueNum;
        }
        if (`${b.idbail}` === idbail) {
          console.log("test", show, `${b.idbail}` === idbail, `${b.idbail}`, idbail);
        }
        if (idbail !== "" && show) show = `${b.idbail}` === idbail;
        if (idactifpatrimonial !== "" && show) show = `${b["idactifpatrimonial"]}` === idactifpatrimonial;
        if (codePostal !== "" && show) show = `${b.code_postal}` === codePostal;
        if (adresse !== "" && show) show = `${b.adresse.toLowerCase()}`.indexOf(adresse.toLowerCase()) !== -1;
        if (ville !== "" && show) show = `${b.ville}`.toUpperCase() === ville.toUpperCase();

        return show;
      })
    : datasSocieteF;

  return { datasFiltred, filter };
};

export default filter;
