import React from "react";
import PropTypes from "prop-types";
import { withStyles } from "@material-ui/core/styles";
import { withRouter } from "react-router-dom";
import Grid from "@material-ui/core/Grid";
import ListItem from "@material-ui/core/ListItem";
import List from "@material-ui/core/List";
import ListItemText from "@material-ui/core/ListItemText";
import withGlobals from "../pages/withGlobals";

const styles = theme => ({
  page: {
    padding: theme.spacing.unit * 2,
    border: "solid 1px silver"
  },
  liste: {
    padding: theme.spacing.unit
  }
});

class ListItemsMobile extends React.Component {
  static propTypes = {
    queryPathname: PropTypes.string.isRequired,
    moduleRoute: PropTypes.string.isRequired,
    lastFiltre: PropTypes.string
  };

  static defaultProps = {
    lastFiltre: ""
  };

  constructor(props) {
    super(props);
    this.state = {
      datas: this.props.datas || []
    };
  }

  componentDidMount = () => {
    if (!this.state.datas.length > 0) {
      this.loadDatas(this.props);
    }
  };

  componentWillReceiveProps = nextProps => {
    if (this.props.location.search !== nextProps.location.props) {
      this.loadDatas(nextProps);
    }
  };

  loadDatas = ({ location: { search }, queryPathname, lastFiltre }) => {
    if (!queryPathname) return;
    let lF = lastFiltre;
    if (lF) {
      lF = search ? lF : lF.replace("&", "?");
    }
    this.props.fetch({ url: `${queryPathname}${search}${lF}` }).then(datas =>
      this.setState({
        datas: this.props.dataMapper ? this.props.dataMapper(datas) : datas
      })
    );
  };

  handleClick = id => {
    const { history, moduleRoute } = this.props;
    history.push(`/${moduleRoute}/${id}`);
  };

  render() {
    const { buildPrimaryText, buildSecondaryText, idField } = this.props;
    return (
      <Grid container direction="column">
        <Grid item className={this.props.classes.liste}>
          <List>
            {this.state.datas.map(a => (
              <ListItem
                className={this.props.classes.page}
                button
                onClick={() => this.handleClick(a[idField])}
              >
                <ListItemText
                  primary={buildPrimaryText(a)}
                  secondary={buildSecondaryText(a)}
                />
              </ListItem>
            ))}
          </List>
        </Grid>
        {this.state.datas.length === 0 && (
          <Grid item>Aucun résultat pour cette recherche</Grid>
        )}
      </Grid>
    );
  }
}

export default withRouter(withStyles(styles)(withGlobals(ListItemsMobile)));
