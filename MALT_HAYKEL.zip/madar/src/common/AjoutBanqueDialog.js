import React, { Component } from "react";
import PropTypes from "prop-types";
import { withStyles } from "@material-ui/core/styles";
import Grid from "@material-ui/core/Grid";
import Button from "@material-ui/core/Button";
import TextField from "@material-ui/core/TextField";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogTitle from "@material-ui/core/DialogTitle";
import withGlobals from "../pages/withGlobals";

const styles = theme => {
  return {
    formControl: {
      marginTop: theme.spacing.unit,
      marginBottom: theme.spacing.unit,
      minWidth: "100%"
    },
    dialogTitle: {
      paddingBottom: theme.spacing.unit,
      textAlign: "center"
    }
  };
};

class AjoutBanqueDialog extends Component {
  static propTypes = {
    handleClose: PropTypes.func.isRequired,
    onBanqueAjoutee: PropTypes.func.isRequired,
    open: PropTypes.bool.isRequired
  };

  state = {
    nom_banque: "",
    errors: {}
  };

  handleClose = () => {
    this.props.handleClose();
  };

  handleChange = e => this.setState({ [e.target.name]: e.target.value });

  handleSave = e => {
    e.preventDefault();
    const { errors, ...datas } = this.state;
    this.props
      .fetch({
        url: "/banques/",
        method: "POST",
        body: {
          ...datas,
          banque_actif: true
        }
      })
      .then(res => {
        this.props.onBanqueAjoutee(res);
        this.props.handleClose();
        this.setState({
          nom_banque: ""
        });
      })
      .catch(err => console.log(err));
  };

  render() {
    const { open, classes } = this.props;
    const { nom_banque } = this.state;
    return (
      <Dialog
        open={open}
        onClose={this.handleClose}
        aria-labelledby="form-dialog-title"
        fullWidth
        maxWidth={"md"}
      >
        <form>
          <DialogTitle id="form-dialog-title" className={classes.dialogTitle}>
            Ajouter une banque
          </DialogTitle>
          <DialogContent>
            <Grid
              container
              alignItems="center"
              justify="center"
              direction="row"
              spacing={16}
            >
              <Grid item md={12}>
                <TextField
                  required
                  autoFocus
                  margin="dense"
                  id="nom_banque"
                  name="nom_banque"
                  value={nom_banque}
                  onChange={this.handleChange}
                  label="Nom de la banque"
                  type="text"
                  fullWidth
                />
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions>
            <Button onClick={this.handleClose} color="textSecondary">
              Annuler
            </Button>
            <Button onClick={this.handleSave} variant="raised" color="primary">
              Ajouter cette banque
            </Button>
          </DialogActions>
        </form>
      </Dialog>
    );
  }
}

export default withStyles(styles)(withGlobals(AjoutBanqueDialog));
