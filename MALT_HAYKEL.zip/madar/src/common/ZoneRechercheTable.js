import React from "react";
import PropTypes from "prop-types";
import { withRouter } from "react-router-dom";
import Grid from "@material-ui/core/Grid";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Switch from "@material-ui/core/Switch";
import AddIcon from "@material-ui/icons/Add";
import Button from "@material-ui/core/Button";
import SearchIcon from "@material-ui/icons/Search";
import TextField from "@material-ui/core/TextField";
import InputAdornment from "@material-ui/core/InputAdornment";
import { withStyles } from "@material-ui/core/styles";
import ListeSocietes from "./ListeSocietes";
import withGlobals from "../pages/withGlobals";

const styles = theme => ({
  container: {
    backgroundColor: "transparent",
    border: `solid 1px ${theme.palette.primary.main}`,
    marginTop: 3,
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: "312px",
  },
  button: {
    margin: theme.spacing.unit / 2,
    height: 40,
    minHeight: 40,
    width: 40,
    minWidth: 40,
  },
  buttonActif: {
    margin: theme.spacing.unit,
  },
  listeSocietes: {
    minWidth: 246,
  },
});

class ZoneRechercheTable extends React.Component {
  static propTypes = {
    classes: PropTypes.object.isRequired,
    texteSearch: PropTypes.string,
    societeSelected: PropTypes.number,
    inDialog: PropTypes.bool.isRequired,
    showIdActif: PropTypes.bool.isRequired,
    hideSocietes: PropTypes.bool.isRequired,
    showLocataireTextField: PropTypes.bool.isRequired,
    addButtonTitle: PropTypes.string.isRequired,
    onSocieteChange: PropTypes.func.isRequired,
    onSocieteAjoutee: PropTypes.func.isRequired,
    onSearchChange: PropTypes.func.isRequired,
    onAddClicked: PropTypes.func.isRequired,
    onChangeFiltreAcquisition: PropTypes.func.isRequired,
  };

  static defaultProps = {
    showLocataireTextField: false,
    societeSelected: 0,
    inDialog: false,
    hideSocietes: false,
    showIdActif: false,
    searchFields: [
      {
        label: "Id Actif",
        name: "id",
      },
      {
        label: "Id Actif",
        name: "idactifpatrimonial",
      },
      {
        label: "Code postal",
        name: "codePostal",
      },
      {
        label: "Ville",
        name: "ville",
      },
      {
        label: "Adresse",
        name: "adresse",
      },
      {
        label: "Surface",
        name: "surfaceTotale",
      },
      {
        label: "Nom du financement",
        name: "nom_portefeuille",
      },
    ],
  };

  state = {
    societes: [],
    actifsAcquis: false,
  };

  componentDidMount = () => {
    if (!this.isCancelled) {
      this.props.fetch({ url: "/societes/" }).then(societes => {
        if (this.props.onLoaded) {
          this.props.onLoaded(societes);
        }
        this.setState({ societes });
      });
    }
  };

  componentWillUnmount() {
    this.isCancelled = true;
  }

  handleClose = () => {
    this.setState({ dialogSocieteOpen: false });
  };

  handleOpen = () => {
    this.setState({ dialogSocieteOpen: true });
  };

  handleSocieteAjoutee = societe => {
    this.setState({ societes: this.state.societes.concat([societe]) });
    this.props.onSocieteAjoutee(societe);
  };

  render() {
    const {
      classes,
      onSocieteChange,
      onSearchChange,
      societeSelected,
      onAddClicked,
      addButtonTitle,
      uniquementBiensAcquis,
      uniquementLocauxSansBail,
      onChangeFiltreAcquisition,
      onChangeFiltreBail,
      location: { pathname },
      inDialog,
      showIdActif,
      showLocataireTextField,
      hideSocietes,
      searchFields,
      readOnly,
    } = this.props;
    const { societes } = this.state;

    return (
      <Grid
        container
        alignItems="center"
        direction="column"
        justify="flex-start"
        className={classes.container}
        spacing={0}
      >
        {searchFields
          .filter(s => {
            if (showIdActif) return true;
            if (!showIdActif && s.name === "idactifpatrimonial") return false;
            return true;
          })
          .map((sF, index) => (
            <Grid item key={sF.name}>
              <TextField
                label={sF.label}
                name={sF.name}
                className={classes.textField}
                onChange={onSearchChange}
                autoFocus={index === 0}
                margin="dense"
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon />
                    </InputAdornment>
                  ),
                }}
              />
            </Grid>
          ))}
        {showLocataireTextField && (
          <Grid item>
            <TextField
              label="Nom du locataire"
              name="nom_du_locataire"
              className={classes.textField}
              onChange={onSearchChange}
              margin="dense"
              InputProps={{
                endAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon />
                  </InputAdornment>
                ),
              }}
            />
          </Grid>
        )}
        {!hideSocietes && (
          <Grid item>
            <ListeSocietes
              onChange={onSocieteChange}
              societes={societes}
              societeSelected={societeSelected}
              className={classes.listeSocietes}
            />
          </Grid>
        )}
        {pathname.indexOf("actifs") !== -1 && (
          <Grid item>
            <Grid container direction="row" alignItems="center" justify="center">
              <Grid item>
                <FormControlLabel
                  control={
                    <Switch
                      checked={uniquementBiensAcquis}
                      onChange={onChangeFiltreAcquisition}
                      value="simple"
                      color="primary"
                    />
                  }
                  label="Uniquement les actifs non acquis"
                />
              </Grid>
            </Grid>
          </Grid>
        )}
        {pathname.indexOf("locaux") !== -1 && (
          <Grid item>
            <Grid container direction="row" alignItems="center" justify="center">
              <Grid item>
                <FormControlLabel
                  control={
                    <Switch
                      checked={uniquementLocauxSansBail}
                      onChange={onChangeFiltreBail}
                      value="simple"
                      color="primary"
                    />
                  }
                  label="Uniquement les locaux sans bail"
                />
              </Grid>
            </Grid>
          </Grid>
        )}
        {!inDialog &&
          !readOnly && (
            <Grid item>
              <Button
                onClick={onAddClicked}
                size="small"
                variant="raised"
                color="primary"
                aria-label="Add"
                fullWidth
                className={classes.buttonActif}
              >
                <AddIcon />
                {addButtonTitle}
              </Button>
            </Grid>
          )}
      </Grid>
    );
  }
}

export default withStyles(styles)(withRouter(withGlobals(ZoneRechercheTable)));
