import React from "react";
import { withRouter } from "react-router-dom";
import Button from "@material-ui/core/Button";

const LinkButton = withRouter(({ history, to, beforeChangeRoute = null, staticContext, ...props }) => {
  return (
    <Button
      {...props}
      onClick={() => {
        if (beforeChangeRoute) {
          beforeChangeRoute();
        }
        history.push(to);
      }}
    />
  );
});

export default LinkButton;
