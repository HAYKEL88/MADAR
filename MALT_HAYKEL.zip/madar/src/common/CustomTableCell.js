import TableCell from '@material-ui/core/TableCell';
import { withStyles } from '@material-ui/core/styles';

const CustomTableCell = withStyles(theme => ({
  head: {
    backgroundColor: theme.palette.primary.main,
    color: theme.palette.common.white,
  },
  body: {
    fontSize: 12,
  },
  paddingDense: {
    paddingRight: 8,
  },
}))(TableCell);

export default CustomTableCell;
