<?php
/**
 * Copyright (c)  2018. L’ensemble du contenu (codes, textes, photographies, infographies, icônes, etc.) du site www.you-fleet.fr est la propriété exclusive de  sas ODEA, éditeur du site you-fleet.fr enregistrés à l'agence pour la protection des programmes sous le N°IDDN.FR.001.43005.000.R.P.2016.000.20100 Tous droits de reproduction ou de représentation de ceux-ci sont réservés.
 */

use App\Controllers\_ApiController;

# Generic Controllers / DataAccess
use App\Controllers\_Controller;
use App\Controllers\_Controller_oAuth2;
use App\DataAccess\_DataAccess;

use App\DataAccess\_oAuth2_CustomStorage;
use App\Controllers\_oAuth2TokenController;

# uploads file
use App\Controllers\UploadController;

# Custom Controllers / Data Custom
use App\Models\ActifPatrimonial;
use App\Models\Amortissements;
use App\Models\Bail;
use App\Models\Banque;
use App\Models\Categorie;
use App\Models\Coeffprog;
use App\Models\DonneesEmprunt;
use App\Models\DonneesExcel;
use App\Models\GestionFin;
use App\Models\Etat;
use App\Models\Euribor;
use App\Models\Portefeuilles;
use App\Models\ImportationEgide;
use App\Models\Indice;
use App\Models\Locaux;
use App\Models\Notifications;
use App\Models\RendezVous;
use App\Models\Societe;
use App\Models\TypeBail;
use App\Models\TypeDeFinancement;
use App\Models\Activites;
use App\Models\Users;


$container = $app->getContainer();

// Register service provider with the container
//$container = new \Slim\Container;
//$container['cache'] = function () {
  // return new \Slim\HttpCache\CacheProvider();
//};

//$container['config']['cache'] =

# monolog
$container['logger'] = function ($c) {
    $settings = $c->get('settings');
    $logger = new \Monolog\Logger($settings['logger']['name']);
    $logger->pushProcessor(new \Monolog\Processor\UidProcessor());
    $logger->pushHandler(new \Monolog\Handler\StreamHandler($settings['logger']['path'], \Monolog\Logger::INFO));
    return $logger;
};




# uploads file
$container['App\Controllers\UploadController'] = function($c) {
    $setting["file"] = realpath(PATRIMONIAL_PATH_EXP);

    return new UploadController($setting["file"],$c->get('logger'));
};

// Database access_server
$container['pdo'] = function ($c) {
    $settings = $c->get('settings')['pdo'];
    if (isset($settings['dsn']['pgsql']))
    {
        $db = new PDO($settings['dsn'], $settings['username'], $settings['password']);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
        return $db;
    } else {
        # mysql PDO
        $db = new PDO($settings['dsn'], $settings['username'], $settings['password']);
        return $db;
    }
};

// oAuth
$container['oAuth'] = function ($c) {

    $storage = new App\DataAccess\_oAuth2_CustomStorage($c->get('pdo'));

    // Pass a storage object or array of storage objects to the OAuth2 server class
    $server = new OAuth2\Server($storage);

    // add grant types
	$server->addGrantType(new OAuth2\GrantType\UserCredentials($storage));
    $server->addGrantType(new OAuth2\GrantType\ClientCredentials($storage));

    return $server;
};

# APIController
$container['App\Controllers\_ApiController'] = function ($c) {
    return new _ApiController($c->get('logger'),$c->get('settings')['PoweredBy']);
};

# Generic Controller
$container['App\Controllers\_Controller'] = function ($c) {
    return new _Controller($c->get('logger'), $c->get('App\DataAccess\_DataAccess'));
};

# Generic DataAccess
$container['App\DataAccess\_DataAccess'] = function ($c) {
	$localtable = $c->get('settings')['localtable']!='' ? $c->get('settings')['localtable'] : '';
    return new _DataAccess($c->get('logger'), $c->get('pdo'), $localtable);
};

# oAuth Controller for retrieving tokens
$container['App\Controllers\_oAuth2TokenController'] = function ($c) {
    return new _oAuth2TokenController($c->get('logger'), $c->get('oAuth'));
};

// Generic Controller oAuth2
$container['App\Controllers\_Controller_oAuth2'] = function ($c) {
    return new _Controller_oAuth2($c->get('logger'), $c->get('App\DataAccess\_DataAccess'), $c->get('oAuth'));
};


# Data Table actif_patrimonial
$container['App\Models\ActifPatrimonial'] = function ($c) {
    $localtable = $c->get('settings')['localtable']!='' ? $c->get('settings')['localtable'] : '';
    return new ActifPatrimonial($c->get('logger'), $c->get('pdo'), $localtable,$c);
};

# Data Table activites
$container['App\Models\Activites'] = function ($c) {
    $localtable = $c->get('settings')['localtable']!='' ? $c->get('settings')['localtable'] : '';
    return new Activites($c->get('logger'), $c->get('pdo'), $localtable,$c);
};


# Data Table amortissement_fix_constant
$container['App\Models\Amortissements'] = function ($c) {
    $localtable = $c->get('settings')['localtable']!='' ? $c->get('settings')['localtable'] : '';
    return new Amortissements($c->get('logger'), $c->get('pdo'), $localtable,$c);
};

# Data Table bail
$container['App\Models\Bail'] = function ($c) {
    $localtable = $c->get('settings')['localtable']!='' ? $c->get('settings')['localtable'] : '';
    return new Bail($c->get('logger'), $c->get('pdo'), $localtable, $c);
};

# Data Table banque
$container['App\Models\Banque'] = function ($c) {
    $localtable = $c->get('settings')['localtable']!='' ? $c->get('settings')['localtable'] : '';
    return new Banque($c->get('logger'), $c->get('pdo'), $localtable, $c);
};

# Data Table categorie
$container['App\Models\Categorie'] = function ($c) {
    $localtable = $c->get('settings')['localtable']!='' ? $c->get('settings')['localtable'] : '';
    return new Categorie($c->get('logger'), $c->get('pdo'), $localtable, $c);
};

# Data Table categorie
$container['App\Models\Coeffprog'] = function ($c) {
    $localtable = $c->get('settings')['localtable']!='' ? $c->get('settings')['localtable'] : '';
    return new Coeffprog($c->get('logger'), $c->get('pdo'), $localtable, $c);
};
# Data Table donnees_emprunt
$container['App\Models\DonneesEmprunt'] = function ($c) {
    $localtable = $c->get('settings')['localtable']!='' ? $c->get('settings')['localtable'] : '';
    return new DonneesEmprunt($c->get('logger'), $c->get('pdo'), $localtable, $c);
};
# Data Table donnees_rapport
$container['App\Models\GestionFin'] = function ($c) {
    $localtable = $c->get('settings')['localtable']!='' ? $c->get('settings')['localtable'] : '';
    return new GestionFin($c->get('logger'), $c->get('pdo'), $localtable, $c);
};

# Data Table DonneesExcel
$container['App\Models\DonneesExcel'] = function ($c) {
    $localtable = $c->get('settings')['localtable']!='' ? $c->get('settings')['localtable'] : '';
    return new DonneesExcel($c->get('logger'), $c->get('pdo'), $localtable, $c);
};

# Data Table etat
$container['App\Models\Etat'] = function ($c) {
    $localtable = $c->get('settings')['localtable']!='' ? $c->get('settings')['localtable'] : '';
    return new Etat($c->get('logger'), $c->get('pdo'), $localtable, $c);
};
# Data Table euribor
$container['App\Models\Euribor'] = function ($c) {
    $localtable = $c->get('settings')['localtable']!='' ? $c->get('settings')['localtable'] : '';
    return new Euribor($c->get('logger'), $c->get('pdo'), $localtable, $c);
};
# Data Table gestion_fin
$container['App\Models\Portefeuilles'] = function ($c) {
    $localtable = $c->get('settings')['localtable']!='' ? $c->get('settings')['localtable'] : '';
    return new Portefeuilles($c->get('logger'), $c->get('pdo'), $localtable, $c);
};
# Data Table importation_egide
$container['App\Models\ImportationEgide'] = function ($c) {
    $localtable = $c->get('settings')['localtable']!='' ? $c->get('settings')['localtable'] : '';
    return new ImportationEgide($c->get('logger'), $c->get('pdo'), $localtable, $c);
};
# Data Table jourferies
$container['App\Models\Indice'] = function ($c) {
    $localtable = $c->get('settings')['localtable']!='' ? $c->get('settings')['localtable'] : '';
    return new Indice($c->get('logger'), $c->get('pdo'), $localtable, $c);
};

# Data Table locaux
$container['App\Models\Locaux'] = function ($c) {
    $localtable = $c->get('settings')['localtable']!='' ? $c->get('settings')['localtable'] : '';
    return new Locaux($c->get('logger'), $c->get('pdo'), $localtable, $c);
};

# Data Table notification
$container['App\Models\Notifications'] = function ($c) {
    $localtable = $c->get('settings')['localtable']!='' ? $c->get('settings')['localtable'] : '';
    return new Notifications($c->get('logger'), $c->get('pdo'), $localtable, $c);
};

# Data Table rendezvous
$container['App\Models\RendezVous'] = function ($c) {
    $localtable = $c->get('settings')['localtable']!='' ? $c->get('settings')['localtable'] : '';
    return new RendezVous($c->get('logger'), $c->get('pdo'), $localtable, $c);
};
# Data Table Societe
$container['App\Models\Societe'] = function ($c) {
    $localtable = $c->get('settings')['localtable']!='' ? $c->get('settings')['localtable'] : '';
    return new Societe($c->get('logger'), $c->get('pdo'), $localtable, $c);
};
# Data Table type_bail
$container['App\Models\TypeBail'] = function ($c) {
    $localtable = $c->get('settings')['localtable']!='' ? $c->get('settings')['localtable'] : '';
    return new TypeBail($c->get('logger'), $c->get('pdo'), $localtable, $c);
};

# Data Table type_financement
$container['App\Models\TypeDeFinancement'] = function ($c) {
    $localtable = $c->get('settings')['localtable']!='' ? $c->get('settings')['localtable'] : '';
    return new TypeDeFinancement($c->get('logger'), $c->get('pdo'), $localtable, $c);
};

# Data Table Activites
$container['App\Models\Activites'] = function ($c) {
    $localtable = $c->get('settings')['localtable']!='' ? $c->get('settings')['localtable'] : '';
    return new Activites($c->get('logger'), $c->get('pdo'), $localtable, $c);
};
# Data Table Users
$container['App\Models\Users'] = function ($c) {
    $localtable = $c->get('settings')['localtable']!='' ? $c->get('settings')['localtable'] : '';
    return new Users($c->get('logger'), $c->get('pdo'), $localtable, $c);
};





# Custom Controllers / DataAccess
# ...
# $container['App\Controllers\MyCustomController'] = function ($c) {
# return new MyCustomController($c->get('logger'), $c->get('App\DataAccess\MyCustomDataAccess'));
# };

# $container['App\Models'] = function ($c) {
# return new MyCustomDataAccess($c->get('logger'), $c->get('pdo'), '');
# };

