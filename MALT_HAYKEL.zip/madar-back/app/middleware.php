<?php
/**
 * Copyright (c)  2018. L’ensemble du contenu (codes, textes, photographies, infographies, icônes, etc.) du site www.you-fleet.fr est la propriété exclusive de  sas ODEA, éditeur du site you-fleet.fr enregistrés à l'agence pour la protection des programmes sous le N°IDDN.FR.001.43005.000.R.P.2016.000.20100 Tous droits de reproduction ou de représentation de ceux-ci sont réservés.
 */



// Application middleware
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

use Interop\Container;


$app->add(function (Request $request,Response  $response, $next) {
    $code =(int) $response->getStatusCode();


    # activation du cache
  //  $responsen = $this->cache->withEtag($response, 'abc');
  //  $responsen = $this->cache->withExpires($response, time() + 3600);
  //  $responsen = $this->cache->withLastModified($response, time() - 3600);

    $responsen = $response->withStatus(200)
        ->withHeader('X-Powered-By', $this->settings['PoweredBy'])
        ->withHeader('Content-Type', 'application/json')
        ->withHeader('Content-Type', 'application/x-www-form-urlencoded')
        ->withHeader('Access-Control-Allow-Origin', '*')
        ->withHeader('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type, Accept, Origin, Authorization')
        ->withHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS')
        ->write(json_encode($response));



	$APIRateLimit = new App\Utils\APIRateLimiter($this);
	$mustbethrottled = $APIRateLimit();

    $SERVERAccessLimit = new App\Utils\ServerAccesLimiter($this,$request);
    $verifieaccess = $SERVERAccessLimit();

	if ($mustbethrottled == false && $verifieaccess == true ) {
    $responsen = $next($request, $responsen);
	} else {
	    if( $verifieaccess == false){
            $responsen = $responsen ->withStatus(401)
                ->withHeader('Server_Access_Limit', $this->settings['server_acces_limiter']['access_token']);
        }
        if($mustbethrottled == true){
            $responsen = $responsen ->withStatus(429)
         ->withHeader('RateLimit-Limit', $this->settings['api_rate_limiter']['requests']);
        }
    }


    return $responsen;
});
