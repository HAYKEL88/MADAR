-- Table: public.xrequests

-- DROP TABLE public.xrequests;

CREATE TABLE public.xrequests
(
  id SERIAL4 NOT NULL,
  originip character varying(45) NOT NULL DEFAULT ''::character varying,
  ts timestamp without time zone NOT NULL DEFAULT now()
)
WITH (
  OIDS=FALSE
);
ALTER TABLE public.xrequests
  OWNER TO postgres;

-- Index: public.key_originip

-- DROP INDEX public.key_originip;

CREATE INDEX key_originip
  ON public.xrequests
  USING btree
  (originip COLLATE pg_catalog."default");

-- Index: public.key_ts

-- DROP INDEX public.key_ts;

CREATE INDEX key_ts
  ON public.xrequests
  USING btree
  (ts);


-- Table: public.users

-- DROP TABLE public.auth_users;
CREATE TABLE public.users_roles
(
  id_droits SERIAL4 NOT NULL ,
  superviseur boolean,
  admin boolean,
  simple_user boolean,
  visiteur boolean,
  presta boolean,
  enregistrer boolean,
  modifier boolean,
  consulter boolean,
  CONSTRAINT key_id_droits PRIMARY KEY (id_droits)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE public.users_roles
  OWNER TO postgres;


CREATE TABLE public.auth_users
(
  id SERIAL4 NOT NULL,
  prenom_user character varying(50),
  login_user character varying(200),
  nom_user character varying(50),
  telephone_user character varying(30),
  fax_user character varying(30),
  email_user character varying(200),
  gms_user character varying(30),
  id_droits integer,
  date_creation date,
  password character varying(100),
  alarme_one integer,
  cloture boolean,
  id_groupe_users integer,
  superviseur boolean,
  compagny character varying(30),
  nation character varying(30),
  enregistrer boolean,
  modifier boolean,
  consulter boolean,
  filtre json,
  api_key character varying(255),
  date_login timestamp without time zone,
  originip character varying(45),
  CONSTRAINT ky_id PRIMARY KEY (id),
  CONSTRAINT key_id_droits_user FOREIGN KEY (id_droits)
      REFERENCES public.users_roles (id_droits) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
)
WITH (
  OIDS=FALSE
);
ALTER TABLE public.auth_users
  OWNER TO postgres;

-- Index: public.fki_id_droits_user

-- DROP INDEX public.fki_id_droits_user;

CREATE INDEX key_id_droits_user
  ON public.auth_users
  USING btree
  (id_droits);

-- Index: public.id_droits

-- DROP INDEX public.id_droits;

CREATE INDEX id_droits
  ON public.auth_users
  USING btree
  (id_droits);

CREATE TABLE oauth_clients (client_id VARCHAR(80) NOT NULL, client_secret VARCHAR(80), redirect_uri VARCHAR(2000) NOT NULL, grant_types VARCHAR(80), scope VARCHAR(100), user_id VARCHAR(80), CONSTRAINT clients_client_id_pk PRIMARY KEY (client_id));
CREATE TABLE oauth_access_tokens (access_token VARCHAR(40) NOT NULL, client_id VARCHAR(80) NOT NULL, user_id VARCHAR(255), expires TIMESTAMP NOT NULL, scope VARCHAR(2000), CONSTRAINT access_token_pk PRIMARY KEY (access_token));
CREATE TABLE oauth_authorization_codes (authorization_code VARCHAR(40) NOT NULL, client_id VARCHAR(80) NOT NULL, user_id VARCHAR(255), redirect_uri VARCHAR(2000), expires TIMESTAMP NOT NULL, scope VARCHAR(2000), CONSTRAINT auth_code_pk PRIMARY KEY (authorization_code));
CREATE TABLE oauth_refresh_tokens (refresh_token VARCHAR(40) NOT NULL, client_id VARCHAR(80) NOT NULL, user_id VARCHAR(255), expires TIMESTAMP NOT NULL, scope VARCHAR(2000), CONSTRAINT refresh_token_pk PRIMARY KEY (refresh_token));
CREATE TABLE oauth_scopes (scope TEXT, is_default BOOLEAN);
CREATE TABLE oauth_jwt (client_id VARCHAR(80) NOT NULL, subject VARCHAR(80), public_key VARCHAR(2000), CONSTRAINT jwt_client_id_pk PRIMARY KEY (client_id));
