<?php
/**
 * Copyright (c)  2018. L’ensemble du contenu (codes, textes, photographies, infographies, icônes, etc.) du site www.you-fleet.fr est la propriété exclusive de  sas ODEA, éditeur du site you-fleet.fr enregistrés à l'agence pour la protection des programmes sous le N°IDDN.FR.001.43005.000.R.P.2016.000.20100 Tous droits de reproduction ou de représentation de ceux-ci sont réservés.
 */



/**
 * Created by PhpStorm.
 * User: dahan
 * Date: 08/07/2018
 * Time: 10:37
 */

namespace  App\Models {
    require __DIR__.'/../../../vendor/autoload.php';

    require_once __DIR__ . '/Tools.php';
    use Psr\Log\LoggerInterface;
    use \Psr\Http\Message\ServerRequestInterface as Request;
    use \Psr\Http\Message\ResponseInterface as Response;
    use App\Models\Tools;
    use PhpOffice\PhpSpreadsheet\Spreadsheet;
    use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
    use PDO;

    class DonneesExcel extends Tools
    {

        /**
         * @var $connexion
         */
        public $connexion;

        /**
        /**
         * @var \Psr\Log\LoggerInterface
         */
        private $logger;

        /**
         * @var \PDO
         */
        private $pdo;

        /**
         * @var $maintable
         */
        private $maintable;

        /**
         * BatchDonneesExcel constructor.
         */
        public function __construct(LoggerInterface $logger, PDO $pdo, $table,$c)
        {
            parent::__construct($c, $logger);

            # connexion to php_pgsql
            $this->connecte();

            # name of the data table
            $this->maintable = $table;

            # log this access data
            $this->logger    = $logger;

            # if you need PDO
            //$this->pdo       = $pdo;

            # renumber the sequences when config is true
            if (SETTING_NEW_SEQUENCE)
            {
            }

        }


        /**
         *  destruct a curently connexion
         * BatchDonneesExcel destruct.
         */
        public function __destruct()
        {
            pg_close($this->connexion);
        }





        /**
         * @url GET /excel
         */
        public function getListDonneesExcel(Request $request,Response $response, $arg)
        {
            $querie         =(string) null;
            $spreadsheet    = new Spreadsheet();
            $gestionfin     = (array) null;
            $sheet          = $spreadsheet->getActiveSheet();
            $sheet->setCellValue('A1', 'Societe');
            $sheet->setCellValue('B1', 'Idactifl');
            $sheet->setCellValue('C1', 'Adresse');
            $sheet->setCellValue('D1', 'Code Postal');
            $sheet->setCellValue('E1', 'Ville');
            $sheet->setCellValue('F1', 'Surface');
            $sheet->setCellValue('G1', 'Date Acquisition');
            $sheet->setCellValue('H1', 'Prix de Revient');
            $sheet->setCellValue('I1',  'Portefeuille Financier');
            $sheet->setCellValue('J1', 'Taux Variable');
            $sheet->setCellValue('K1', 'Marge Taux Variable');
            $sheet->setCellValue('L1', 'Charge Emprunt');
            $sheet->setCellValue('M1', 'Capital Rembourse_an');
            $sheet->setCellValue('N1', 'CRD');
            $sheet->setCellValue('O1', 'Duree Residuelle Credit');
            $sheet->setCellValue('P1', 'Montant CAP');
            $sheet->setCellValue('Q1', 'Strike CAP');
            $sheet->setCellValue('R1', 'Duree CAP');
            $sheet->setCellValue('S1','Montant SWAP');
            $sheet->setCellValue('T1', 'Strike SWAP');
            $sheet->setCellValue('U1', 'Duree SWAP');
            $sheet->setCellValue('V1', 'DSCR Actuel');
            $sheet->setCellValue('W1', 'DSCR Facial Acté');
            $sheet->setCellValue('X1', 'DSCR Potentiel');
            $sheet->setCellValue('Y1', 'LTV');
            $sheet->setCellValue('Z1', 'LTC');
            $sheet->setCellValue('AB1', 'Taux Capitalisation');
            $sheet->setCellValue('AC1', 'Loyer Actuel');
            $sheet->setCellValue('AD1', 'Indexation');
            $sheet->setCellValue('AE1', 'Loyer Facial Acté');
            $sheet->setCellValue('AF1', 'Loyer Vacant');
            $sheet->setCellValue('AG1', 'Loyer Potentiel');
            $sheet->setCellValue('AH1', 'Taux Reversion Potentiel');
            $sheet->setCellValue('AI1', 'Loyer Actuel CRD');
            $sheet->setCellValue('AJ1', 'Loyer Total Invest Initial');
            $sheet->setCellValue('AK1', 'Nom Expert');
            $sheet->setCellValue('AL1', 'Valeur Expertise');
            $sheet->setCellValue('AM1', 'Valeur Venale');
            $sheet->setCellValue('AN1', 'Travaux');
            $sheet->setCellValue('AO1', 'Surface Actif');
            $sheet->setCellValue('AP1', 'Surface Vacante');
            $sheet->setCellValue('AQ1', 'Commentaires');



            # query
            $query      = "SELECT *  
                              FROM gestion_fin";
            $query      = $query . "\r\n" . $querie;
            $this->logger->notice($query.': '.__FUNCTION__);

            # test de la valitdité de la requete
            $result         = pg_send_query($this->connexion, $query);
            $res1           = pg_get_result($this->connexion);
            $result_error   = pg_result_error($res1);
            if (Empty($result_error)) {
                # query locaux idlocal = id
                $result = pg_query($this->connexion, $query);
                # fetch result
                $gestionfin = pg_fetch_all($result);
                # For booleans and numeric convert
                $gestionfin = $this->FormaData($gestionfin, $result, false);
                $code = 200;
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete :" . __FUNCTION__ . " Detail de l'erreur :" . $state;
                return $this->getResponseData($code, $request, $response, ["returncode" => 500, "message" => "Erreur lors de l'execution de la requete :" . __FUNCTION__ . " Detail :" . $result_error, "code" => 500]);
            }
            foreach($gestionfin as $key=>$value){

            }


            $spreadsheet->getActiveSheet()
                ->setTitle('Simple test');

            $writer = new Xlsx($spreadsheet);
            $writer->save(PATRIMONIAL_PATH_EXPORT.'/'.'hello_world.xlsx');

        }


        /**
         * @url GET /excel/$id
         * @url GET /excel=current
         */
        public function getDonneesExcel(Request $request,Response $response, $arg)
        {
            $code = (integer) null;
            $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);
            $table = $this->maintable != '' ? $this->maintable : $this->path;
            $id = $arg['id'];
            if ($id) {
                # query locaux iddonneesrapports = id
                $q = pg_query($this->connexion, "SELECT * FROM $this->maintable WHERE iddonneesrapports ={$id}");
                # fetch result
                $res = pg_fetch_all($q);
                if ($res) {
                    # For booleans and numeric convert
                    $res =$this->FormaData($res, $q, true);
                    $code = 200;
                } else {
                    $code = 500;
                    $state = pg_last_error();
                    // some error happened
                    $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                    $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                    return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
                }
            } else {
                $code = 400;
            }
            return $this->getResponseData($code, $request, $response,$res);
        }


        /**
         * @url PUT /excel/$id
         * @url PUT /excel/$id/$data
         */
        public function UpdateDonneesExcel(Request $request,Response $response, $arg)
        {
            $code = (integer) null;
            $id = $arg['id'];
            $data = $request->getParam('data');
            $data = $this->getData($data);
            # if method PUT or POSt getValidateFields
            $error = $this->getValidateFields($this->maintable,$data);
            if($error){
                $code = 400;
                return $this->getResponseData($code, $request, $response,$error);
            }

            # format $data with escape string
            $array =$this->InsertFormaData($data,$this->connexion);
            # update $data
            $result = pg_update($this->connexion, $this->maintable , $array, ["iddonneesrapports" => "$id"], PGSQL_DML_EXEC);
            if ($result) {
                $q = pg_query($this->connexion, "SELECT * FROM $this->maintable WHERE iddonneesrapports ={$id}");
                # fetch result
                $res = pg_fetch_all($q);
                $res =$this->FormaData($res, $q,true);
                $code = 200;
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
            }

            return $this->getResponseData($code, $request, $response,$res);
        }


        /**
         * @url POST /excel
         * @url POST /excel/$data
         */
        public function AddDonneesExcel(Request $request,Response $response, $arg)
        {
            $code = (integer) null;
            $data = $request->getParam('data');
            $data = $this->getData($data);
            # if method PUT or POSt getValidateFields
            $error = $this->getValidateFields($this->maintable,$data);
            if($error){
                $code = 400;
                return $this->getResponseData($code, $request, $response,$error);
            }

            # format $data with escape string
            $array =$this->InsertFormaData($data,$this->connexion);

            # insert $data
            $array['iddonneesrapports'] = $this->NewSequence( 'investissements','iddonneesrapports',$this->connexion);
            $result = pg_insert($this->connexion, $this->maintable , $array, PGSQL_DML_EXEC);
            if ($result) {
                $id =  $array['iddonneesrapports'] ;
                # recherche de l'id
                $q = pg_query($this->connexion, "SELECT * FROM $this->maintable WHERE iddonneesrapports ={$id}");
                # fetch result
                $res = pg_fetch_all($q);
                $res =$this->FormaData($res, $q,true);
                $code = 200;
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
            }
            return $this->getResponseData($code, $request, $response,$res);
        }


        /**
         * @param $table
         * @return array
         */
        public function getValidateFields($table,$data) {
            $validfields = $this->ValidateField($table, $this->connexion);
            $res         = $this->verifyRequiredParams($data,$validfields);
            return $res;
        }


        /**
         * @url DELETE /excel/$id
         */
        public function DeleteDonneesExcel(Request $request,Response $response, $arg)
        {
            $code = (integer) null;
            $id = $arg['id'];
            # delete
            $res = pg_delete($this->connexion, $this->maintable , ["iddonneesrapports" => "$id"], PGSQL_DML_EXEC);
            if ($res) {
                # For booleans and numeric convert
                $res = ["message" => "L'Enregistrement a été éffacé", "Enregistrement supprimé ID :" => $id];
                $code = 200;
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
            }

            return $this->getResponseData($code, $request, $response,$res);

        }
    }
}
