<?php
/**
 * Copyright (c)  2018. L’ensemble du contenu (codes, textes, photographies, infographies, icônes, etc.) du site www.you-fleet.fr est la propriété exclusive de  sas ODEA, éditeur du site you-fleet.fr enregistrés à l'agence pour la protection des programmes sous le N°IDDN.FR.001.43005.000.R.P.2016.000.20100 Tous droits de reproduction ou de représentation de ceux-ci sont réservés.
 */



/**
 * Created by PhpStorm.
 * User: dahan
 * Date: 08/07/2018
 * Time: 10:37
 */

namespace  App\Models {
    require_once __DIR__ . '/Tools.php';
    use Psr\Log\LoggerInterface;
    use \Psr\Http\Message\ServerRequestInterface as Request;
    use \Psr\Http\Message\ResponseInterface as Response;
    use App\Models\Tools;
    use PDO;

    class Indice extends Tools
    {

        /**
         * @var $connexion
         */
        public $connexion;

        /**
        /**
         * @var \Psr\Log\LoggerInterface
         */
        private $logger;

        /**
         * @var \PDO
         */
        private $pdo;

        /**
         * @var $maintable
         */
        private $maintable;

        /**
         * indice constructor.
         */
        public function __construct(LoggerInterface $logger, PDO $pdo, $table,$c)
        {
            parent::__construct($c, $logger);



            # log this access data
            $this->logger    = $logger;

        }


        /**
         *  destruct a curently connexion
         * indice destruct.
         */
        public function __destruct()
        {

        }



        /**
         * @url GET /Indice
         */
        public function getListIndice(Request $request,Response $response, $arg)
        {
            $code           = (integer) null;
            $type           = (string) null;
            $array_indice   = (array) null;
            $indice         = (array) null;
            //gestion des paramêtre autre

            # tableau associatif de la query
            $type = $request->getParams();
            # tableau indicé de la query (afin d'obtenir le verbe complet de la query)
            $type = explode("&", str_replace("type=",null,$_SERVER['QUERY_STRING']));
            $dateparam = str_replace("date=",null,$type[1]);
            // On récupère le code HTML de la page suivante
            switch($type[0]){
                case "ICC"  : $url = "https://www.insee.fr/fr/statistiques/serie/ajax/001532540";break;
                case "ILAT" : $url = "https://www.insee.fr/fr/statistiques/serie/ajax/001617112";break;
                case "ILC"  : $url = "https://www.insee.fr/fr/statistiques/serie/ajax/001532540";break;
                default :
                    return false;
            }

            try {
                $json = file_get_contents($url);

                if(isset($json)){
                    $object = json_decode($json);
                    $node       = explode("\n",$object->html);
                    foreach($node as $key => $value){
                        if(strpos($value,'tbody>')){
                            break;
                        }
                        unset($node[$key]);
                    }
                    # extraction des valeurs
                    $date = null;
                    foreach($node as $key => $value){
                        if(strpos($value,'tr>') && strpos($value,'/tr>') ===false){
                            $annee =  substr($node[$key + 1],strpos($node[$key + 1],'>')+1,strlen($value));
                            $annee = substr($annee,0,strlen($annee)-5);
                            $trim = substr($node[$key + 2],strpos($node[$key + 2],'>')+1,strlen($value));
                            $trim =  substr($trim,0,strlen($trim)-5);
                            $indice = substr($node[$key + 3],strpos($node[$key + 3],'>')+1,strlen($value));
                            $indice = substr($indice,0,strlen($indice)-5);
                            $indice = str_replace(',','.',$indice);
                            $date =  substr($node[$key + 4],strpos($node[$key + 4],'>')+1,strlen($value));
                            $date = substr($date,0,10);
                            $dateindice = substr($date,6,10)."-".substr($date,3,2)."-".substr($date,0,2);;      // 23/12/2015
                            array_push($array_indice, ["type"=>$type[0],"annee"=>$annee,"date"=>$dateindice,"trimestre"=>$trim,"indice"=>floatval($indice)]);
                            //break;
                        }
                    }
                }
            } catch (HttpException $ex) {
                echo $ex;
            }

            foreach($array_indice as $key=>$array){
                $date1 = $this->DatePeriode($array["date"],"Y-m-d","fin");
                $date2 = $this->DatePeriode($dateparam,"Y-m-d","fin");
                $date1 = $this->DateVal($date1);
                $date2 = $this->DateVal($date2);
                if ($date2 >= $date1) {
                    $indice =$array;
                    break;
                }

            }

            if ($indice) {
                # For booleans and numeric convert
                $code = 200;
            } else {
                $code = 404;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                return $this->getResponseData($code, $request, $response,["returncode"=>404,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 404]);
            }
            return $this->getResponseData($code, $request, $response,$indice);
        }


    }
}
