<?php
/**
 * Copyright (c)  2018. L’ensemble du contenu (codes, textes, photographies, infographies, icônes, etc.) du site www.you-fleet.fr est la propriété exclusive de  sas ODEA, éditeur du site you-fleet.fr enregistrés à l'agence pour la protection des programmes sous le N°IDDN.FR.001.43005.000.R.P.2016.000.20100 Tous droits de reproduction ou de représentation de ceux-ci sont réservés.
 */



/**
 * Created by PhpStorm.
 * User: dahan
 * Date: 08/07/2018
 * Time: 10:37
 */

namespace  App\Models {
    require_once __DIR__ . '/Tools.php';
    use Psr\Log\LoggerInterface;
    use \Psr\Http\Message\ServerRequestInterface as Request;
    use \Psr\Http\Message\ResponseInterface as Response;
    use App\Models\Tools;
    use PDO;

    class Portefeuilles extends Tools
    {

        /**
         * @var $connexion
         */
        public $connexion;

        /**
        /**
         * @var \Psr\Log\LoggerInterface
         */
        private $logger;

        /**
         * @var \PDO
         */
        private $pdo;

        /**
         * @var $maintable
         */
        private $maintable;

        /**
         * Portefeuilles constructor.
         */
        public function __construct(LoggerInterface $logger, PDO $pdo, $table, $c)
        {
            parent::__construct($c, $logger);

            # connexion to php_pgsql
            $this->connecte();

            # name of the data table
            $this->maintable = $table;

            # log this access data
            $this->logger    = $logger;

            # if you need PDO
            //$this->pdo       = $pdo;

            # renumber the sequences when config is true
            if (SETTING_NEW_SEQUENCE)
            {

            }

        }


        /**
         *  destruct a curently connexion
         * Portefeuilles destruct.
         */
        public function __destruct()
        {
            pg_close($this->connexion);
        }




        /**
         * @url GET /portefeuilles
         */
        public function getListPortefeuilles(Request $request,Response $response, $arg)
        {
            $code = (integer) null;
            # tableau associatif de la query
            $type = $request->getParams();
            # tableau indicé de la query (afin d'obtenir le verbe complet de la query)
            $querie = explode("=", $type["type"]);

            if(isset($type["type"])){
                if($querie[0] === "nom_portefeuille" || $querie[0] ==="idinvestissement" ){
                    $query = "SELECT idinvestissement,nom_portefeuille,
                            investissements as portefeuille
                     FROM investissements
                    WHERE $querie[0]='$querie[1]' ";
                }else{
                    $query = "SELECT t.idinvestissement, t.nom_portefeuille, 
                             t.investissements as portefeuille
                      FROM investissements t,
                       json_array_elements(t.investissements->'actifs') actifs                                   
                       where  actifs->>'$querie[0]' = '{$querie[1]}'";
                }

            }else{
                $query = "SELECT idinvestissement,nom_portefeuille,
                            investissements as portefeuille
                     FROM investissements";

            }

            # fetch result
            # test de la valitdité de la requete
            $result = pg_send_query($this->connexion, $query);
            $res1 = pg_get_result($this->connexion);
            $result_error = pg_result_error($res1);
            if(Empty($result_error)) {
                # query locaux idlocal = id
                $result = pg_query($this->connexion, $query);
                # fetch result
                $res = pg_fetch_all($result);
                # For booleans and numeric convert
                $res =$this->FormaData($res, $result, false);
                $code = 200;
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
            }
            return $this->getResponseData($code, $request, $response,$res);
        }


        /**
         * @url GET /portefeuilles/$id
         * @url GET /portefeuilles=current
         */
        public function getPortefeuilles(Request $request,Response $response, $arg)
        {
            $code = (integer) null;
            $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);
            $table = $this->maintable != '' ? $this->maintable : $this->path;
            $id = $arg['id'];
            if ($id) {
                # query locaux idinvesissement = id
                $query = "SELECT  idinvestissement,	nom_portefeuille,		
                            investissements FROM $this->maintable WHERE idinvestissement ={$id}";

                # fetch result
                # test de la valitdité de la requete
                $result = pg_send_query($this->connexion, $query);
                $res1 = pg_get_result($this->connexion);
                $result_error = pg_result_error($res1);
                if(Empty($result_error)) {
                    # query locaux idlocal = id
                    $result = pg_query($this->connexion, $query);
                    # fetch result
                    $res = pg_fetch_all($result);
                    # For booleans and numeric convert
                    $res = $this->FormaData($res, $result, true);
                    $code = 200;
                } else {
                    $code = 500;
                    $state = pg_last_error();
                    // some error happened
                    $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                    $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                    return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
                }
            } else {
                $code = 400;
            }
            return $this->getResponseData($code, $request, $response,$res);
        }


        /**
         * @url PUT /portefeuilles/$id
         * @url PUT /portefeuilles/$id/$data
         */
        public function UpdatePortefeuilles(Request $request,Response $response, $arg)
        {
            $code = (integer) null;
            $id = $arg['id'];
            $data = $request->getParam('data');
            $data = $this->getData($data);
            # if method PUT or POSt getValidateFields
            $error = $this->getValidateFields($this->maintable,$data);
            if($error){
                $code = 400;
                return $this->getResponseData($code, $request, $response,$error);
            }

            # format $data with escape string
            $array =$this->InsertFormaData($data,$this->connexion);
            # update $data
            $result = pg_update($this->connexion, $this->maintable , $array, ["idinvesissement" => "$id"], PGSQL_DML_EXEC);
            if ($result) {
                $q = pg_query($this->connexion, "SELECT * FROM $this->maintable WHERE idinvesissement ={$id}");
                # fetch result
                $res = pg_fetch_all($q);
                $res =$this->FormaData($res, $q,true);
                $code = 200;
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
            }

            return $this->getResponseData($code, $request, $response,$res);
        }


        /**
         * @url POST /portefeuilles
         * @url POST /portefeuilles/$data
         */
        public function AddPortefeuilles(Request $request,Response $response, $arg)
        {
            $code = (integer) null;
            $data = $request->getParam('data');
            $data = $this->getData($data);
            # if method PUT or POSt getValidateFields
            $error = $this->getValidateFields($this->maintable,$data);
            if($error){
                $code = 400;
                return $this->getResponseData($code, $request, $response,$error);
            }

            # format $data with escape string
            $array =$this->InsertFormaData($data,$this->connexion);

            # insert $data
            $array['idinvesissement'] = $this->NewSequence( $this->maintable,'idinvesissement',$this->connexion);
            $result = pg_insert($this->connexion, $this->maintable , $array, PGSQL_DML_EXEC);
            if ($result) {
                $id = $array['idinvesissement'];
                # recherche de l'id
                $q = pg_query($this->connexion, "SELECT * FROM $this->maintable WHERE idinvesissement ={$id}");
                # fetch result
                $res = pg_fetch_all($q);
                $res =$this->FormaData($res, $q,true);
                $code = 200;
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
            }
            return $this->getResponseData($code, $request, $response,$res);
        }


        /**
         * @param $table
         * @return array
         */
        public function getValidateFields($table,$data) {
            $validfields = $this->ValidateField($table, $this->connexion);
            $res         = $this->verifyRequiredParams($data,$validfields);
            return $res;
        }


        /**
         * @url DELETE /portefeuilles/$id
         */
        public function DeletePortefeuilles(Request $request,Response $response, $arg)
        {
            $code = (integer) null;
            $id = $arg['id'];
            # delete
            $res = pg_delete($this->connexion, $this->maintable , ["idinvesissement" => "$id"], PGSQL_DML_EXEC);
            if ($res) {
                # For booleans and numeric convert
                $res = ["message" => "L'Enregistrement a été éffacé", "Enregistrement supprimé ID :" => $id];
                $code = 200;
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
            }

            return $this->getResponseData($code, $request, $response,$res);

        }
    }
}
