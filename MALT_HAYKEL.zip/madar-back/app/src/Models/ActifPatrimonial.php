<?php
/**
 * Copyright (c)  2018. L’ensemble du contenu (codes, textes, photographies, infographies, icônes, etc.) du site www.you-fleet.fr est la propriété exclusive de  sas ODEA, éditeur du site you-fleet.fr enregistrés à l'agence pour la protection des programmes sous le N°IDDN.FR.001.43005.000.R.P.2016.000.20100 Tous droits de reproduction ou de représentation de ceux-ci sont réservés.
 */



/**
 * Created by PhpStorm.
 * User: dahan
 * Date: 08/07/2018
 * Time: 10:37
 */

namespace  App\Models {
    require_once __DIR__ . '/Tools.php';
    use RuntimeException;
    use Psr\Log\LoggerInterface;
    use \Psr\Http\Message\ServerRequestInterface as Request;
    use \Psr\Http\Message\ResponseInterface as Response;
    use App\Models\Tools;
    use PDO;

    class ActifPatrimonial extends Tools
    {

        /**
         * @var $connexion
         */
        public $connexion;

        /**
        /**
         * @var \Psr\Log\LoggerInterface
         */
        private $logger;

        /**
         * @var \PDO
         */
        private $pdo;

        /**
         * @var $maintable
         */
        private $maintable;

        /**
         * $var $investissements
         */
        private $investissements;

        /**
         * Actifs constructor.
         */
        public function __construct(LoggerInterface $logger, PDO $pdo, $table,$c)
        {
            parent::__construct($c, $logger);

            # connexion to php_pgsql
            $this->connecte();

            # name of the data table
            $this->maintable = $table;

            # log this access data
            $this->logger    = $logger;

            # if you need PDO
            //$this->pdo       = $pdo;

            $this->investissements =  array();

            # renumber the sequences when config is true
            if (SETTING_NEW_SEQUENCE)
            {

            }

            pg_set_error_verbosity($this->connexion, PGSQL_ERRORS_VERBOSE);
        }


        /**
         *  destruct a curently connexion
         * Actifs destruct.
         */
        public function __destruct()
        {
            pg_close($this->connexion);
        }




        /**
         * @url GET /actifs
         */
        public function getListActifPatrimonial(Request $request,Response $response, $arg)
        {
            $code           = (integer) null;
            $result         = (bool) null;
            $result_error   =(string) null;
            $query          = (string) null;
            $querie         = (string) null;
            $table          = $this->maintable != '' ? $this->maintable : $this->path;
            # traitement de la query
            $querie         = $this->getUrlQuery($request,$this->maintable,$this->connexion);

            $query = "SELECT * FROM $this->maintable as A";
            $query = $query."\r\n".$querie;

            # test de la valitdité de la requete
            $result = pg_send_query($this->connexion, $query);
            $res1 = pg_get_result($this->connexion);
            $result_error = pg_result_error($res1);
            if(Empty($result_error)) {
                # query locaux idlocal = id
                $result = pg_query($this->connexion, $query);
                # fetch result
                $res = pg_fetch_all($result);
                # For booleans and numeric convert
                $res =$this->FormaData($res, $result, false);
                $code = 200;
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
            }
            return $this->getResponseData($code, $request, $response,$res);
        }


        /**
         * @url GET /actifs/$id
         * @url GET /actifs=current
         */
        public function getActifPatrimonial(Request $request,Response $response, $arg)
        {
            $code           = (integer) null;
            $result         = (bool) null;
            $result_error   =(string) null;
            $table = $this->maintable != '' ? $this->maintable : $this->path;
            $id = $arg['id'];
            if ($id) {
                # query actif_patrimonial idactifpatrimonial = id
                $query = "SELECT * FROM $this->maintable WHERE idactifpatrimonial ={$id}";
                # test de la valitdité de la requete
                $result = pg_send_query($this->connexion, $query);
                $res1 = pg_get_result($this->connexion);
                $result_error = pg_result_error($res1);
                if(Empty($result_error)) {
                    # query locaux idlocal = id
                    $result = pg_query($this->connexion, $query);
                    # fetch result
                    $res = pg_fetch_all($result);
                    # For booleans and numeric convert
                    $res =$this->FormaData($res, $result, true);
                    $code = 200;
                } else {
                    $code = 500;
                    $state = pg_last_error();
                    // some error happened
                    $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                    $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                    return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
                }
            } else {
                $code = 400;
            }
            return $this->getResponseData($code, $request, $response,$res);
        }

        /**
         * @url GET /emprunts/investissement/$id
         * @url GET /emprunts/investissement=current
         */
        public function getInvestissement(Request $request,Response $response, $arg)
        {
            $code = (integer) null;
            $result = (bool) null;
            $invest = (array) null;
            $actif = (array) null;
            $result_error =(string) null;
            $idactif = $arg['id'];
            if ($idactif) {
                $query  = "SELECT t.idinvestissement, t.investissements as portefeuille
                                                        FROM investissements t,
                                                        json_array_elements(t.investissements->'actifs') actifs                                   
                                                        where  (actifs->>'idactifpatrimonial')::int = {$idactif}";

                # test de la rtequete
                $result = pg_send_query($this->connexion, $query);
                $res1 = pg_get_result($this->connexion);
                $result_error = pg_result_error($res1);
                if(Empty($result_error)) {
                    # query locaux idlocal = id
                    $result = pg_query($this->connexion, $query);
                    # fetch result
                    $invest = pg_fetch_all($result);
                    $invest = $this->FormaData($invest, $result, true);

                    # composition du portefeuille
                    $portefeuil['portefeuille']['actifs'] = $invest;


                    $code = 200;
                } else {
                    $code = 500;
                    $state = pg_last_error();
                    // some error happened
                    $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                    $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                    return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
                }
            } else {
                $code = 400;
            }
            return $this->getResponseData($code, $request, $response,$portefeuil);
        }


        /**
         * @url PUT /actifs/$id
         * @url PUT /actifs/$id/$data
         */
        public function UpdateActifPatrimonial(Request $request,Response $response, $arg)
        {
            $code = (integer) null;
            $id = $arg['id'];
            $data = $request->getParam('data');
            $data = $this->getData($data);
            # if method PUT or POSt getValidateFields
            $error = $this->getValidateFields($this->maintable,$data);
            if($error){
                $code = 400;
                return $this->getResponseData($code, $request, $response,$error);
            }
            # format $data with escape string
            $array =$this->InsertFormaData($data,$this->connexion);
            if(isset($array["valeur_venal"]) && isset($array["valeur_venale"])){
                $array["valeur_venal"]=$array["valeur_venale"];
            }
            # update $data
            $result = pg_update($this->connexion, $this->maintable , $array, ["idactifpatrimonial" => "$id"], PGSQL_DML_EXEC);
            if ($result) {
                $q = pg_query($this->connexion, "SELECT * FROM $this->maintable WHERE idactifpatrimonial ={$id}");
                # fetch result
                $res = pg_fetch_all($q);
                $res =$this->FormaData($res, $q,true);
                $code = 200;
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
            }

            return $this->getResponseData($code, $request, $response,$res);
        }


        /**
         * @url POST /actifs
         * @url POST /actifs/$data
         */
        public function AddActifPatrimonial(Request $request,Response $response, $arg)
        {
            $code = (integer) null;
            $data = $request->getParam('data');
            $data = $this->getData($data);
            $message = (string) null;
            # if method PUT or POSt getValidateFields
            $error = $this->getValidateFields($this->maintable,$data);

            if($error){
                $code = 400;
                return $this->getResponseData($code, $request, $response,$error);
            }
            # format $data with escape string
            $array =$this->InsertFormaData($data,$this->connexion);
            # insert $data
                $array['idactifpatrimonial'] = $this->NewSequence( $this->maintable,'idactifpatrimonial',$this->connexion);
                $result = pg_insert($this->connexion, $this->maintable, $array, PGSQL_DML_EXEC);
            if ($result) {
                $id = $array['idactifpatrimonial'];
                # recherche de l'id
                $q = pg_query($this->connexion, "SELECT * FROM $this->maintable WHERE idactifpatrimonial ={$id}");
                # fetch result
                $res = pg_fetch_all($q);
                $res =$this->FormaData($res, $q,true);

                $code = 200;
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);

            }
            return $this->getResponseData($code, $request, $response,$res);
        }


        /**
         * @param $table
         * @return array
         */
        public function getValidateFields($table,$data) {
            $validfields = $this->ValidateField($table, $this->connexion);
            $res         = $this->verifyRequiredParams($data,$validfields);
            return $res;
        }


        /**
         * @url DELETE /actifs/$id
         */
        public function DeleteActifPatrimonial(Request $request,Response $response, $arg)
        {
            $code = (integer) null;
            $id = $arg['id'];
            $q = pg_query($this->connexion,"SELECT idinvestissement, investissements,ele->>'idactifpatrimonial' as idactifpatrimonial
                                                        FROM investissements t,
                                                        json_array_elements(investissements->'actifs') ele
                                                        where  (ele->>'idactifpatrimonial')::int = {$id}");

            $result = pg_fetch_all($q);
            if ($result) {
                $investissements = $this->FormaData($result, $q, true);
                $idinvestissement = $investissements['idinvestissement'];
            }

            # s'il n'existe pas de portefeuille
            # on peut deleted un actif
            if(!isset($idinvestissement)) {
                # delete
                $res = pg_delete($this->connexion, $this->maintable, ["idactifpatrimonial" => "$id"], PGSQL_DML_EXEC);
                if ($res) {
                    # For booleans and numeric convert
                    $res = ["message" => "L'Enregistrement a été éffacé", "Enregistrement supprimé ID :" => $id];
                    $code = 200;
                } else {
                    $code = 500;
                    $state = pg_last_error();
                    // some error happened
                    $result_error = "erreur d'execution de la requete :" . __FUNCTION__ . " Detail de l'erreur :" . $state;
                    $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1) . $result_error . ': ' . __FUNCTION__);
                    return $this->getResponseData($code, $request, $response, ["returncode" => 500, "message" => "Erreur lors de l'execution de la requete :" . __FUNCTION__ . " Detail :" . $result_error, "code" => 500]);
                }
            }
            return $this->getResponseData($code, $request, $response,$res);

        }




    }
}
