<?php
/**
 * Copyright (c)  2018. L’ensemble du contenu (codes, textes, photographies, infographies, icônes, etc.) du site www.you-fleet.fr est la propriété exclusive de  sas ODEA, éditeur du site you-fleet.fr enregistrés à l'agence pour la protection des programmes sous le N°IDDN.FR.001.43005.000.R.P.2016.000.20100 Tous droits de reproduction ou de représentation de ceux-ci sont réservés.
 */


/**
 * Created by PhpStorm.
 * User: dahan
 * Date: 08/07/2018
 * Time: 10:37
 */

namespace App\Models {
    require __DIR__.'/../../../vendor/autoload.php';
    require_once __DIR__ . '/Tools.php';

    use PDO;
    use Psr\Http\Message\ResponseInterface as Response;
    use Psr\Http\Message\ServerRequestInterface as Request;
    use Psr\Log\LoggerInterface;


    class DonneesEmprunt extends Tools
    {

        /**
         * @var $connexion
         */
        public $connexion;

        /**
         * /**
         * @var \Psr\Log\LoggerInterface
         */
        public $logger;

        /**
         * @var \PDO
         */
        private $pdo;

        /**
         * @var $maintable
         */
        private $maintable;

        /**
         * @var $tables_liees
         */
        private $tables_liees;

        /**
         * @var $investissements
         */
        private $investissements;

        /**
         * DonneesEmprunt constructor.
         */
        public function __construct(LoggerInterface $logger, PDO $pdo, $table, $c)
        {
            parent::__construct($c, $logger);

            # connexion to php_pgsql
            $this->connexion = $this->connecte();

            # name of the data table
            $this->maintable = $table;

            # log this access data
            $this->logger = $logger;


            # if you need PDO
            //$this->pdo       = $pdo;

            # table investissements
            $this->investissements = array();

            $this->tables_liees = ["actif_patrimonial", "donnees_emprunt", "banque"];

            # renumber the sequences when config is true
            // (SETTING_NEW_SEQUENCE) {
                //  $this->NewSequence($table,"idemprunt",$this->connexion);
                //  $this->NewSequence("actif_patrimonial","idactifpatrimonial",$this->connexion);
                //   $this->NewSequence("emprunt_amortissement","idamortissement",$this->connexion);
                //    $this->NewSequence("investissements","idinvestissement",$this->connexion);
            //

        }

        /**
         *  destruct a curently connexion
         * DonneesEmprunt destruct.
         */
        public function __destruct()
        {
            pg_close($this->connexion);
        }

        /**
         * @url GET /donneesemprunt
         */
        public function getListDonneesEmprunt(Request $request, Response $response, $arg)
        {
            $code = (integer)null;
            $result = (bool)null;
            $result_error = (string)null;
            $query = (string)null;
            $querie = $this->getUrlQuery($request, $this->tables_liees, $this->connexion);


            # query
            $query = "SELECT E.idemprunt,E.idbanque, B.nom_banque as banque, E.montant_financement, E.duree_financement, E.duree_annnes, 
                             E.taux, E.nombre_echeances, E.frequence, E.date_acquisition, E.date_premiere_echeance, 
                             E.date_derniere_echeance, E.type_emprunt, E.valeur_residuelle, E.type_amortissement, E.date_depart_differe, 
                             E.amortissement_anne_n, E.decalage_amortissement, E.ideuribor, E.indice_euribor, E.marge_banque, 
                             E.couverture_taux, E.montant_swap, E.taux_swap,E.taux_cap, E.date_debut_swap, E.duree_swap, E.montant_cap, 
                             E.strike_cap, E.date_debut_cap, E.prime_cap, E.montant_prime_upfront, E.montant_prime_lisse
  
                         FROM donnees_emprunt as E
                         
                         left join banque as B ON B.idbanque = E.idbanque ";
            $query = $query . "\r\n" . $querie;

            # test de la valitdité de la requete
            $result = pg_send_query($this->connexion, $query);
            $res1 = pg_get_result($this->connexion);
            $result_error = pg_result_error($res1);
            if (Empty($result_error)) {
                # query locaux idlocal = id
                $result = pg_query($this->connexion, $query);
                # fetch result
                $res = pg_fetch_all($result);
                # For booleans and numeric convert
                $res = $this->FormaData($res, $result, false);
                $code = 200;
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete :" . __FUNCTION__ . " Detail de l'erreur :" . $state;
                return $this->getResponseData($code, $request, $response, ["returncode" => 500, "message" => "Erreur lors de l'execution de la requete :" . __FUNCTION__ . " Detail :" . $result_error, "code" => 500]);
            }

            return $this->getResponseData($code, $request, $response, $res);
        }


        /**
         * @url GET /donneesemprunt/$id
         * @url GET /donneesemprunt=current
         */
        public function getDonneesEmprunt(Request $request, Response $response, $arg)
        {
            $code = (integer)null;
            $result = (bool)null;
            $result_error = (string)null;
            $id = $arg['id'];
            if ($id) {
                # query locaux idemprunt = $id
                $query = "SELECT E.idemprunt, E.idbanque, B.nom_banque as banque, E.montant_financement, E.duree_financement, E.duree_annnes, 
                                 E.taux, E.nombre_echeances, E.frequence, E.date_acquisition, E.date_premiere_echeance, 
                                 E.date_derniere_echeance, E.type_emprunt, E.valeur_residuelle, E.type_amortissement, E.date_depart_differe, 
                                 E.amortissement_anne_n, E.decalage_amortissement, E.ideuribor, E.indice_euribor, E.marge_banque, 
                                 E.couverture_taux, E.montant_swap, E.taux_swap,E.taux_cap, E.date_debut_swap, E.duree_swap, E.montant_cap, 
                                 E.strike_cap, E.date_debut_cap, E.prime_cap, E.montant_prime_upfront, E.montant_prime_lisse, 
                                 A.amortissements,A.couverture 
                          FROM donnees_emprunt as E
                          join emprunt_amortissement as A ON A.idemprunt = E.idemprunt		
                             left join banque as B ON B.idbanque = E.idbanque 
                          WHERE E.idemprunt ={$id}";

                # test de la rtequete
                $result = pg_send_query($this->connexion, $query);
                $res1 = pg_get_result($this->connexion);
                $result_error = pg_result_error($res1);
                if (Empty($result_error)) {
                    # query locaux idlocal = id
                    $result = pg_query($this->connexion, $query);
                    # fetch result
                    $res = pg_fetch_all($result);
                    # For booleans and numeric convert
                    $res = $this->FormaData($res, $result, true);
                    $code = 200;
                } else {
                    $code = 500;
                    $state = pg_last_error();
                    // some error happened
                    $result_error = "erreur d'execution de la requete :" . __FUNCTION__ . " Detail de l'erreur :" . $state;
                    return $this->getResponseData($code, $request, $response, ["returncode" => 500, "message" => "Erreur lors de l'execution de la requete :" . __FUNCTION__ . " Detail :" . $result_error, "code" => 500]);
                }
            } else {
                $code = 400;
            }
            return $this->getResponseData($code, $request, $response, $res);
        }

        /**
         * @url GET /emprunts/investissement/$id
         * @url GET /emprunts/investissement=current
         */
        public function getInvestissement(Request $request, Response $response, $arg)
        {
            $code = (integer)null;
            $result = (bool)null;
            $portefeuil = (array)null;
            $invest = (array)null;
            $result_error = (string)null;
            $idemprunt = $arg['id'];
            if ($idemprunt) {
                $query = "SELECT t.idinvestissement, t.investissements as portefeuille
                                                        FROM investissements t,
                                                        json_array_elements(t.investissements->'emprunts') emprunts                                   
                                                        where  (emprunts->>'idemprunt')::int = {$idemprunt}";

                # test de la rtequete
                $result = pg_send_query($this->connexion, $query);
                $res1 = pg_get_result($this->connexion);
                $result_error = pg_result_error($res1);
                if (Empty($result_error)) {
                    # query locaux idlocal = id
                    $result = pg_query($this->connexion, $query);
                    # fetch result
                    $invest = pg_fetch_all($result);
                    $invest = $this->FormaData($invest, $result, true);

                    # composition du portefeuille
                    $portefeuil['portefeuille']['actifs'] = $invest;


                    $code = 200;
                } else {
                    $code = 500;
                    $state = pg_last_error();
                    // some error happened
                    $result_error = "erreur d'execution de la requete :" . __FUNCTION__ . " Detail de l'erreur :" . $state;
                    return $this->getResponseData($code, $request, $response, ["returncode" => 500, "message" => "Erreur lors de l'execution de la requete :" . __FUNCTION__ . " Detail :" . $result_error, "code" => 500]);
                }
            } else {
                $code = 400;
            }
            return $this->getResponseData($code, $request, $response, $portefeuil);
        }

        /**
         * @url PUT /donneesemprunt/$id
         * @url PUT /donneesemprunt/$id/$data
         */
        public function UpdateDonneesEmprunt(Request $request, Response $response, $arg)
        {
            $code                   = (integer)null;
            $idemprunt              = intval($arg['id']);
            $jsona                  = $request->getParam("data");
            $data                   = $this->getData($jsona);
            $idinvestissement       = (int) 0;
            $idamortissement        = (int) 0;
            $tranches["actifs"]     = $data['actifs'];
            $tranches["tranches"]   = (array) array();
            $portefeuille           = (array) array();
            $euribord               = (float) null;
            $couverture             = (array) null;
            $amortissements         = (array) null;
            # selection des tableaux d'amortissements
            $query = "SELECT idinvestissement FROM donnees_emprunt where idemprunt ={$idemprunt}";
            $result = pg_query($this->connexion, $query);
            $portif = pg_fetch_object($result);
            $idinvestissement   = $portif->idinvestissement;

            # recherche du portefeuille
            $query = "SELECT idinvestissement,investissements,nom_portefeuille 
                           FROM investissements                                   
                       where idinvestissement ={$idinvestissement}";
            $result = pg_query($this->connexion, $query);
            $portefeuille = pg_fetch_all($result);
            $portefeuille = $this->getData($portefeuille[0]["investissements"]);

            if (isset($data) && !Empty($data["tranches"])) {
                foreach ($data["tranches"] as $key => $value){
                    $array = $this->InsertFormaData($value, $this->connexion);
                    if($array["montant_financement"] !== 0){
                       array_push($tranches["tranches"], $value );
                    }
                }

                # création des nouveaux tableaux d'amortissements
                foreach ($tranches["tranches"] as $key => $value) {
                    $id = $tranches["tranches"][$key]["idemprunt"];
                    # format $data with escape string
                    $array = $this->InsertFormaData($value, $this->connexion);


                    # si l'amortissement existe
                    if(isset($portefeuille["emprunts"][$key]["idamortissement"])){
                        $idamortissement = $portefeuille["emprunts"][$key]["idamortissement"];
                    }else{
                        $idamortissement = $value["idamortissement"];
                    }


                    # suppression des json avant l'insert
                    unset($array['coefprogressivites']);
                    unset($array['idamortissement']);
                    unset($array['idactifpatrimonial']);
                    unset($array['nombre_echeances_restante']);
                    unset($array['capital_restant']);
                    unset($array['duree_reelle']);
                    unset($array['montant_interets']);
                    unset($array['idemprunt']);
                    unset($array['nom_portefeuille']);
                    unset($array["duree_residuelle"]);
                    unset($array["CRD"]);
                    unset($array["crd"]);

                if ($array["couverture_taux"] !== "swap") {
                        $array["date_debut_swap"]       =null;
                        $array["taux_swap"]             =null;
                        $array["montant_swap"]          =null;
                    }
                    if ($array["couverture_taux"] !== "cap") {
                        $array["date_debut_cap"]        =null;
                        $array["marge_banque"]          =null;
                        $array["taux_cap"]              =null;
                        $array["prime_cap"]             =null;
                        $array["montant_prime_lisse"]   =null;
                        $array["montant_cap"]           =null;
                        $array["strike_cap"]            =null;
                        $array["duree_cap"]             =null;
                    }else{
                        if(!is_string($array["prime_cap"]) && is_numeric($array["prime_cap"]) ){
                            $array["montant_prime_lisse"]=$array["prime_cap"];
                        }
                        if(!is_numeric($array["montant_prime_lisse"])){
                            $array["montant_prime_lisse"]=null;
                        }
                    }



                    # suppression des key [amortissement_anne_x]
                    foreach($array  as $key2 => $value2){
                        if(substr($key2,0,19) ==='amortissement_annee' ){
                            unset($array[$key2]);
                        }
                    }

                    if(Empty($array['decalage_amortissement'])){
                        $array['decalage_amortissement']  = $array['date_premiere_echeance'];
                    }

                    # if method PUT or POSt getValidateFields
                    $error = $this->getValidateFields($this->maintable, $array);
                    if ($error || Empty($array)) {
                        $code = 400;
                        return $this->getResponseData($code, $request, $response, $error);
                    }else{
                        $result = pg_update($this->connexion, "donnees_emprunt", $array, ["idemprunt" => "$idemprunt"], PGSQL_DML_EXEC);
                    }

                    if(!$result) {
                        $code = 500;
                        $state = pg_last_error();
                        // some error happened
                        $result_error = "erreur d'execution de la requete : Update donnees_emprunt a la ligne Detail de l'erreur :" . $state;
                        return $this->getResponseData($code, $request, $response, ["returncode" => 500, "message" => "Erreur lors de l'execution de la requete :" . __FUNCTION__ . " Detail :" . $result_error, "code" => 500]);
                    }

                    if ($idemprunt > 0) {
                        # création des paramètres de l'emprunt
                        $emprunt['idemprunt'] = intval($idemprunt);



                        # préparation des données pour calculer le tableau des amortissements
                        $amort = $tranches['tranches'][$key];
                        $amort['idemprunt'] = intval($idemprunt);


                        # pas de financement on ne continue pas les opétations
                        if($array["montant_financement"] > 0) {
                            # tableau d'amortissements du prêt Fixe
                            if ($value['type_emprunt'] === 'taux_fixe') {
                                $amortissements = $this->EmpruntFixe($amort);
                            }

                            # tableau d'amortissements du prêt Variable
                            if ($value['type_emprunt'] === 'taux_variable') {
                                # tableau d'amortissement du prêt
                                $amortissements = $this->EmpruntVariable($amort);
                                # couverture cap or swap
                                if (floatval($value['montant_cap']) > 0 || floatval($value['montant_swap']) > 0) {
                                    $couverture = $this->CouverturePrets($amort, $amortissements);
                                }
                            }
                        }

                        # date derniere echeance, taux utilise, euribord
                        $array['date_derniere_echeance']    = $amortissements[count($amortissements) - 1]['date_echeance'];
                        $tranches["tranches"][$key]['date_derniere_echeance']    =  substr($array['date_derniere_echeance']  ,0,10);



                        # mis a jour du taux
                        $taux = $amortissements[count($amortissements) - 1]['taux'];

                        # mise a jour du taux euribor
                        if(isset($amortissements[count($amortissements) - 1]['Euribor']) ){
                            $euribord = $amortissements[count($amortissements) - 1]['Euribor'];
                        }


                        # mise a jour de la date de la derniere echeance & taux utilise
                        # format $tranches with escape string
                        $donnesemprunt = $this->InsertFormaData($array, $this->connexion);
                        if($donnesemprunt) {
                            $result = pg_update($this->connexion, 'donnees_emprunt', $donnesemprunt, ["idemprunt" => $idemprunt], PGSQL_DML_EXEC);
                        }
                        if (!$result) {
                            $code = 500;
                            $state = pg_last_error();
                            // some error happened
                            $result_error = "erreur d'execution de la requete : donnees_emprunt mise a jour des dates Detail de l'erreur :" . $state;
                            $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1) . $result_error . ': ' . __FUNCTION__);
                            return $this->getResponseData($code, $request, $response, ["returncode" => 500, "message" => "Erreur lors de l'execution de la requete :" . __FUNCTION__ . " Detail :" . $result_error, "code" => 500]);
                        }


                        # format $tranches with escape string
                        $emprunt = $this->InsertFormaData($emprunt, $this->connexion);
                        //$emprunt['idsociete'] = intval($value["idsociete"]);

                        # insert or update into emprunt amortissement
                        # les tranches sont soient modifiés ou inserrés si  $idamortissement est null
                        # **********************************************************************************
                        if ($idamortissement >0) {
                            $result = pg_update($this->connexion, 'emprunt_amortissement', $emprunt, ["idamortissement" => "$idamortissement"], PGSQL_DML_EXEC);
                        } else {
                            $emprunt['idamortissement'] = $this->NewSequence('emprunt_amortissement', 'idamortissement', $this->connexion);
                            $idamortissement =$emprunt['idamortissement'];

                            $tranches["tranches"][$key]["idamortissement"] = $idamortissement;
                            $result = pg_insert($this->connexion, 'emprunt_amortissement', $emprunt, PGSQL_DML_EXEC);
                        }
                        # ********************************************************************************

                        # mise a jour du tableau d'emprunt de la table emprunt_amortissement
                        if($idamortissement> 0){
                            # insertion du tableau d'amortissement
                            $result = $this->UpdateEmpruntJson($idamortissement, $amortissements,$couverture);
                        }

                        if (!$result) {
                            $code = 500;
                            $state = pg_last_error();
                            // some error happened
                            $result_error = "erreur d'execution de la requete : emprunt_amortissement tableau d'emprunt Detail de l'erreur :" . $state;
                            $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1) . $result_error . ': ' . __FUNCTION__);
                            return $this->getResponseData($code, $request, $response, ["returncode" => 500, "message" => "Erreur lors de l'execution de la requete :" . __FUNCTION__ . " Detail :" . $result_error, "code" => 500]);
                        }
                    }
                }

                if(isset($data['actifs']) && !Empty($data['actifs'])){
                    $array['actifs'] = $this->AddActifs($data['actifs']);
                    $array['actifs'] = pg_escape_literal($this->connexion, $array['actifs']);
                    # sauvegarde des actifs dans donnees_emprunt
                    $result = pg_query($this->connexion, "UPDATE donnees_emprunt SET actifs = {$array['actifs']} WHERE idemprunt= {$idemprunt}");
                }

                if(isset($tranches['tranches'][$key]['coefprogressivites'])){
                    $json = json_encode(self::utf8_encode($tranches['tranches'][$key]['coefprogressivites']));
                    $json = pg_escape_literal($json);
                    # sauvegarde des actifs dans donnees_emprunt
                    $result = pg_query($this->connexion, "UPDATE donnees_emprunt SET coefprogressivites= {$json} WHERE idemprunt= {$idemprunt}");
                }

                if($result){
                    # creation du tableau de l'investissement
                    $portefeuille = ["idinvestissement" =>$idinvestissement, "actifs" => [], "emprunts" => []];
                    $portefeuille["actifs"] = $tranches["actifs"];
                    array_push($portefeuille["emprunts"], ["idamortissement" =>$idamortissement, "idemprunt" => $idemprunt]);
                    $invest = json_encode($portefeuille,true);
                    $invest = pg_escape_literal($this->connexion,$invest);
                    $res = pg_update($this->connexion, "investissements", $portefeuille, ["idinvestissement" => $idinvestissement],PGSQL_DML_EXEC );

                    $tranches["nom_portefeuille"] = $data["nom_portefeuille"];
                    # creation ou modification du tableau de l'investissement
                    $res = $this->CreateInvestissement($idinvestissement,$idemprunt, $tranches);
                }


                if($res) {
                    # return le resultat complet (emprunt + tableau amortissement)
                    $res = $this->AddInfosEmprunt($idinvestissement);
                    $code = 200;
                } else{
                    $code = 500;
                    $state = pg_last_error();
                    // some error happened
                    $result_error = "erreur d'execution de la requete :" . __FUNCTION__ . " Detail de l'erreur :" . $state;
                    $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1) . $result_error . ': ' . __FUNCTION__);
                    return $this->getResponseData($code, $request, $response, ["returncode" => 500, "message" => "Erreur lors de l'execution de la requete :" . __FUNCTION__ . " Detail :" . $result_error, "code" => 500]);
                }


            } else if(isset($tranches["tranches"]) && empty($tranches["tranches"]) && $idemprunt>0) {
                $code = 200;
                $res  = array();
                # delete du tableau amortissement vide
                $result = pg_delete($this->connexion, 'emprunt_amortissement', ["idemprunt" => $idemprunt], PGSQL_DML_EXEC);
                # delete de l'emprunt vide
                $result = pg_delete($this->connexion, 'donnees_emprunt', ["idemprunt" => $idemprunt], PGSQL_DML_EXEC);
                # delete du portefeuille vide
                $result = pg_delete($this->connexion, 'investissements', ["idinvestissement" => $idinvestissement], PGSQL_DML_EXEC);
                // some error happened
                $this->logger->notice( "L'Emprunt ID N° ".$idemprunt." est supprimé par l'utilisateur au : ".SETTING_DAY_NOW ." par la function de la class Emprunts : " . __FUNCTION__);
                return $this->getResponseData($code, $request, $response, $res);
            } else {
                $code = 400;
                $state = pg_last_error();
                // some error happened
                return $this->getResponseData($code, $request, $response, ["returncode" => $code, "message" => "tableau vide:" . __FUNCTION__ . " Detail :le tablea de parametres est vide", "code" => $code]);
            }

            return $this->getResponseData($code, $request, $response, $res);
        }

        /**
         * @param $table
         * @return array
         */
        public function getValidateFields($table, $data)
        {
            $validfields = $this->ValidateField($table, $this->connexion);
            $res = $this->verifyRequiredParams($data, $validfields);
            return $res;
        }

        /**
         * transforme array id en array associatif actif_patrimonial
         * @param $data
         * @return string
         */
        public function AddActifs(array $data,$json = true)
        {
            $array = (string)null;
            if(count($data) == 1){
                $filter = $data[0];
                $filter = "WHERE idactifpatrimonial IN($filter)";
            }else if (count($data)>1){
                $filter = implode(",", $data);
                $filter = "WHERE idactifpatrimonial IN($filter)";
            }else{
                return null;
            }


            if ($data) {
                $query = "select idactifpatrimonial, adresse, code_postal, ville from actif_patrimonial $filter";
                $q = pg_query($this->connexion, $query);
                $actifs = pg_fetch_all($q);
                $actifs = $this->FormaData($actifs, $q, false);
                if($json) {
                    $array = json_encode(self::utf8_encode($actifs));
                }else{
                    $array = $actifs;
                }

            }
            return $array;
        }

        /**
         * calcul le tableau d'amortissement d'un credit
         * @param $data
         * @return array
         */
        public function EmpruntFixe($data)
        {
            $capital                    = (float)  $data["montant_financement"];
            $capital_fin                = (float)  $data["valeur_residuelle"];
            $capital_rembourse          = (float)  0;
            $capital_amorti             = (float) 0;
            $capital_annee              = (array) null;
            $interetsdecalages          = (array) null;
            $nbecheances                = (int)    $data["duree_financement"];
            $duree_financement          = (int)    $data["duree_financement"];
            $nbecheances_restant        = (int)    0;
            $echeancediffere            = (int)    0;
            $interets                   = (float)  0;
            $taux                       = (float)  0;
            $tableau                    = (array)  null;
            $coefprogressivites         = (array)  null;
            $datedepart                 = (string) $data["date_premiere_echeance"];
            $date_debut_echeance        = (string) $data["date_premiere_echeance"];
            $date_fin_echeance          = (string) $data["date_derniere_echeance"];
            $datediffere                = (string) $data["date_differee"];
            $decalage_amortissement     = (int) 0;
            $moisplus                   = (int)    0;
            $valeur_res                 = (float)  $data["montant_financement"];
            $couverture_taux            = (string) $data['couverture_taux'];
            $strike_cap                 = (string) $data['strike_cap'];
            $marge_banque               = (float)  floatval($data["marge_banque"]) ;
            $montant_swap               = (float)  $data["montant_swap"] ;
            $montant_cap                = (float)  $data["montant_cap"] ;
            $date_debut_swap            = $data['date_debut_swap'];
            $date_debut_cap             = $data['date_debut_cap'];
            $compteur                   = (int) 0;

            # recupération données data
            $id = $data['idemprunt'];


            # récupération du taux
            if (strlen($data["taux"]) === 1) {
                $taux = floatval($data["taux"]);
                if ($taux > 0.90) {
                    $taux = $taux / 100;
                }
            } else {
                $taux = floatval($data["taux"]);
                if ($taux > 0.90) {
                    $taux = $taux / 100;
                }
            }


            if(!Empty($data["decalage_amortissement"])){
                $date1 = $this->DatePeriode($datedepart,"y-m-d","fin");
                $date2 = $this->DatePeriode($data["decalage_amortissement"],"y-m-d","fin");
                $decalage_amortissement         = $this->DateInterval($date1, $date2, "m") ;
                $duree_financement              = $data["duree_financement"] -$decalage_amortissement;
            }


            # report de la fréquence sur les échéances
            $frequences = [
                "frequence"             => $data["frequence"],
                "trancheannee"          => 12,
                "nbecheances"           => ($nbecheances-$decalage_amortissement),
                "nbecheances_reelle"    => ($nbecheances),
                "nbinterval"            => 1
            ];



            # calcul de la frequence
            $frequences = $this->getEcheances($frequences,$datedepart,$datediffere);

            # decalage selon interval
            if($decalage_amortissement>0){
                $decalage_amortissement = round($decalage_amortissement/ $frequences["nbinterval"]);
            }


            # calcul de la date de fin si nessessaire
            if(Empty($date_fin_echeance)){
                $data1 = $this->DatePlus($date_debut_echeance,$data["duree_financement"] , "Y-m-d");
                $date_fin_echeance = $this->DatePeriode($data1,"y-m-d","fin");
            }
            $date1 = $this->DateVal(SETTING_DAY_NOW);
            $date2 = $this->DateVal($date_fin_echeance);
            if ($date1 >= $date2) {
                return array();
            }

            # capital départ
            $capital_debut  = $capital;


            # calcul du montant des échéances
            if (strtoupper($data["type_amortissement"]) === "CONSTANT") {
                $echeance_montants      = $this->CalculInterets($taux,$capital,$duree_financement,$frequences["nbinterval"],$frequences["nbecheances"]);
                $interetsdecalages      = $this->CalculInterets($taux,$capital_fin,$duree_financement,$frequences["nbinterval"],$frequences["nbecheances"]);
                $echeance            = $echeance_montants["echeance"]+$interetsdecalages["interets"];
                $interets            = $echeance_montants["interets"]+$interetsdecalages["interets"];
            }else if (strtoupper($data["type_amortissement"]) === "PROGRESSIF") {
                $progressivite          = ($data["duree_financement"] / 12);
                $suplementecheance      = $frequences["nbecheances_reelle"]-$frequences["nbecheances"];


                # progressivite
                foreach($data['coefprogressivites'] as $key => $value){
                  array_push($coefprogressivites,floatval($value)*10);
                }

                # calcul des remboursements de capital
                $derniereecheance =floatval($coefprogressivites[count($coefprogressivites)-1]);
                array_push($coefprogressivites,$derniereecheance);
                $capitrest           = $capital;
                $i =0;
                foreach($coefprogressivites as $value ){
                        array_push($capital_annee, ($capital * $coefprogressivites[intval($i)]));
                        $capitrest = ($capitrest-$capital_annee[count($capital_annee)-1]);

                    $i++;
                }

                $numprog             = 0;
                $interets            = (($valeur_res * ($taux)) / ($frequences["trancheannee"] / $frequences["nbinterval"]));
                $capital_periode     = ($capital * $coefprogressivites[$numprog]);
                $capital_rembourse   = $capital_periode / ($frequences["trancheannee"] / $frequences["nbinterval"]);
                $echeance            = ($capital_rembourse + $interets);
                // $coefprogressivites = [0 => 0.0485, 1 => 0.05, 2 => 0.0515, 3 => 0.06, 4 => 0.06, 5 => 0.0625, 6 => 0.0650, 7 => 0.0675, 8 => 0.07, 9 => 0.0725, 10 => 0.075, 11 => 0.0775, 12 => 0.0775, 13 => 0.0775, 14 => 0.08, 15 => 0.825];
            } else  if (strtoupper($data["type_amortissement"]) === "AUCUN") {
                $echeance_montants   = $this->CalculInterets($taux,$capital,$data["duree_financement"],$frequences["nbinterval"],$frequences["nbecheances"]);
                $echeance            = $echeance_montants["echeance"];
                $interets            = $echeance_montants["interets"];
            }


            # calcul des échéance
            $valeur_res = $capital;
            $this->DatePeriode($datedepart, "m");
            # $datediffere non mulle
            if (Empty($datediffere)) {
                $datediffere = $datedepart;
            }
            $data["date_premiere_echeance"] = $datediffere;

            for ($i = 1; $i <= $frequences["nbecheances_reelle"]; $i++) {
                $datecalcul = $this->DatePeriode($datedepart,"Y-m-d","fin");
                $date1 = $this->DateVal($datecalcul);
                $date2 = $this->DateVal($datediffere);
                if ($date1 >= $date2) {
                    # calcul interets & capital
                    if (!Empty($coefprogressivites) && $data["type_amortissement"] ==="progressif") {
                        if($decalage_amortissement > 0){
                            $datediff = date("Y-m-d", $date1 + 54000);
                            $numprog = $this->DateInterval($datediff, $datediff, "y");
                            $interets = (($capital_debut * ($taux)) / ($frequences["trancheannee"] / $frequences["nbinterval"]));
                            $capital_rembourse = 0;
                            $echeance =  $interets;
                            $capital_amorti = 0;
                            # calcul valeur résiduelle
                            $capital_debut = $valeur_res;
                            $valeur_res = $capital;
                            $echeancetableau = $echeance;
                            $decalage_amortissement = $decalage_amortissement - 1;
                        }else {
                            $datediff = date("Y-m-d", $date1 + 54000);
                            $numprog = $this->DateInterval($data["date_premiere_echeance"], $datediff, "y");
                            $interets = (($capital_debut * ($taux)) / ($frequences["trancheannee"] / $frequences["nbinterval"]));
                            $capital_periode = ($capital_annee[intval($numprog)]);
                            $capital_rembourse = $capital_periode / ($frequences["trancheannee"] / $frequences["nbinterval"]);
                            $echeance = ($capital_rembourse + $interets);
                            $capital_amorti = ($capital_amorti + $capital_rembourse);
                            # calcul valeur résiduelle
                            $capital_debut = $valeur_res ;
                            $valeur_res = ($capital - $capital_amorti);
                            $echeancetableau = $echeance;
                        }
                        $compteur++;
                    } else {
                        if($decalage_amortissement > 0){
                            $interets            = $echeance_montants["interets"]+$interetsdecalages["interets"];
                            $echeancetableau     = $interets ;
                            $capital_rembourse   = 0;
                            $capital_amorti      = 0;
                            $capital_debut       = $valeur_res;
                            $valeur_res          = $capital;
                            $decalage_amortissement = $decalage_amortissement - 1;
                        }else{
                            $echeance_montants   = $this->CalculInterets($taux,$capital_debut,($duree_financement-$compteur),$frequences["nbinterval"],$frequences["nbecheances"]);
                            $interets            = $echeance_montants["interets"]+$interetsdecalages["interets"];
                            $capital_rembourse   = ($echeance - $interets);
                            $capital_amorti      = ($capital_amorti + $capital_rembourse);
                            $capital_debut       = $valeur_res;
                            $valeur_res          = ($valeur_res - $capital_rembourse);
                            $echeancetableau     = $echeance;
                            $compteur++;
                        }

                    }
                    if (strtoupper($data["type_amortissement"]) === "AUCUN") {
                        $echeance_montants   = $this->CalculInterets($taux,$capital,($duree_financement-$compteur),$frequences["nbinterval"],$frequences["nbecheances"]);
                        $interets            = $echeance_montants["interets"];
                        $capital_rembourse   =0;
                        $capital_amorti      =0;
                        $compteur++;
                    }


                    if($i == ($frequences["nbecheances_reelle"])){
                        $echeancetableau = $echeancetableau + $valeur_res ;
                        $capital_rembourse = $capital_debut;
                        $valeur_res          = 0;
                        $capital_fin         = 0;
                    }

                    # tablea amortissement
                    array_push($tableau, ["idemprunt" => $id,
                            "echeances_numero"      => $i,
                            "montant_echeance"      => round($echeancetableau,2),
                            "capital"               => round($capital_debut,2),
                            "montant_interets"      => round($interets,2),
                            "capital_rembourse"     => round($capital_rembourse,2),
                            "taux"                  => round($taux*100,2),
                            "mois"                  => $moisplus,
                            "date_echeance"         => $datedepart,
                            "type_amortissement"    => $data["type_amortissement"],
                            "type_emprunt"          => $data["type_emprunt"],
                            "date_depart"           => $datediffere,
                            "valeur_residuelle"     => round($valeur_res,2)
                        ]
                    );
                } else {
                    # table amortissement
                    array_push($tableau, ["idemprunt" => $id,
                            "echeances_numero"      => $i,
                            "montant_echeance"      => round($interets,2), //round($interets),
                            "capital"               => 0,
                            "montant_interets"      => round($interets,2),
                            "capital_rembourse"     => round($capital_rembourse,2),
                            "taux"                  => round($taux*100,2),
                            "mois"                  => $moisplus,
                            "date_echeance"         => $datedepart,
                            "type_amortissement"    => $data["type_amortissement"],
                            "type_emprunt"          => $data["type_emprunt"],
                            "date_depart"           => $datediffere,
                            "valeur_residuelle"     => round($valeur_res,2)
                        ]
                    );

                }


                # calcul de la date d'échéance
                $datedepart = $this->DatePlus($datedepart, $frequences["nbinterval"], "Y-m-d");
                $datedepart = $this->DateISO8601($datedepart);
                # calcul du mois
                $moisplus = $this->DatePeriode($datedepart, "m");
            }


            return $tableau;
        }

        /**
         * calcul le tableau d'amortissement d'un credit
         * @param $data
         * @return array
         */
        public function EmpruntVariable($data)
        {
            $capital                    = (float) $data["montant_financement"];
            $capital_rembourse          = (float)0;
            $capital_debut              = (float)0;
            $capital_reserve            = (float)0;
            $capital_annee              = (array) null;
            $nbecheances                = (int) $data["duree_financement"];
            $duree_financement          = (int) $data["duree_financement"];
            $nbecheances_restant        = (int) 0;
            $couverture_taux            = (string) $data['couverture_taux'];
            $tauxutilise                = (float) 0;
            $echeancediffere            = (int)0;
            $interets                   = (float) 0;
            $taux                       = (float) 0;
            $strike_cap                 = (string) $data['strike_cap'];
            $marge_banque               = (float) floatval($data["marge_banque"]) ;
            $montant_swap               = (float) $data["montant_swap"] ;
            $montant_cap                = (float) $data["montant_cap"] ;
            $date_debut_swap            = $data['date_debut_swap'];
            $date_debut_cap             = $data['date_debut_cap'];
            $Euribor                    = (float)0;
            $tableau                    = (array) null;
            $coefprogressivites         = (array) null;
            $datedepart                 = (string) substr($data["date_premiere_echeance"], 0, 10);
            $date_debut_echeance        = (string) substr($data["date_premiere_echeance"], 0, 10);
            $date_fin_echeance          = (string) substr($data["date_dernière_echeance"], 0, 10);
            $nbinterval                 = (int)1;
            $datediffere                = (string)
            $datediffere                = (string) $data["date_differee"];
            $decalage_amortissement     = (int) 0;
            $frequences                 = (array) null;
            $moisplus                   = (int) 0;
            $valeur_res                 = (float) $capital;

            # recupération données data
            $id = $data['idemprunt'];

            if(!Empty($data["decalage_amortissement"])){
                $date1 = $this->DatePeriode($datedepart,"y-m-d","fin");
                $date2 = $this->DatePeriode($data["decalage_amortissement"],"y-m-d","fin");
                $decalage_amortissement         = $this->DateInterval($date1, $date2, "m") ;
                $duree_financement              = $data["duree_financement"] -$decalage_amortissement;
            }


            # report de la fréquence sur les échéances
            $frequences = [
                "frequence"             => $data["frequence"],
                "trancheannee"          => 12,
                "nbecheances"           => $nbecheances,
                "nbecheances_reelle"    => $nbecheances,
                "nbinterval"            => 1
            ];

            # calcul de la frequence
            $frequences = $this->getEcheances($frequences,$datedepart,$datediffere);

            # decalage selon interval
            if($decalage_amortissement>0){
                $decalage_amortissement = round($decalage_amortissement/ $frequences["nbinterval"]);
            }


            # calcul de la date de fin si nessessaire
            if(Empty($date_fin_echeance)){
                $data1 = $this->DatePlus($date_debut_echeance,$data["duree_financement"] , "Y-m-d");
                $date_fin_echeance = $this->DatePeriode($data1,"y-m-d","fin");
            }
            $date1 = $this->DateVal(SETTING_DAY_NOW);
            $date2 = $this->DateVal($date_fin_echeance);
            if ($date1 >= $date2) {
                return array();
            }

            # progressivite
            foreach($data['coefprogressivites'] as $key => $value){
                array_push($coefprogressivites,floatval($value)*10);
            }

            # calcul des remboursements de capital
            $derniereecheance =floatval($coefprogressivites[count($coefprogressivites)-1]);
            array_push($coefprogressivites,$derniereecheance);
            $capitrest           = $capital;
            $i =0;
            foreach($coefprogressivites as $value ){
                    if($decalage_amortissement > $i){
                        $capital_reserve = ($capital * $coefprogressivites[intval($i)]);
                    }
                    array_push($capital_annee, ($capital * $coefprogressivites[intval($i)]));
                    $capitrest = ($capitrest-$capital_annee[count($capital_annee)-1]);


                $i++;
            }

            # calcul des échéance
            $capital_debut  = $capital;
            $valeur_res     = $capital;


            $this->DatePeriode($datedepart, "y-m-d");
            $nbecheances_restant = (int)  $frequences["nbecheances_reelle"];
            # $datediffere non mulle
            if (Empty($datediffere)) {
                $datediffere = $datedepart;
            }


            $date_fin_echeance              = $datedepart;
            $data["date_premiere_echeance"] = $datediffere;
            for ($i = 1; $i <= $frequences["nbecheances_reelle"]; $i++) {
                $date_debut_echeance = $this->DatePeriode($datedepart,"Y-m-d");
                // $date_debut_echeance    = substr($date_fin_echeance,0,10);
                $date1                  = $this->DateVal($date_debut_echeance);
                # dernier jours du mois en cours
                $date_fin_echeance      = $this->DatePeriode($date_debut_echeance,"Y-m-d","fin");
                $date2                  = $this->DateVal($date_fin_echeance);
                $query = "select * 
                            from euribor  
                          WHERE (date_echeance BETWEEN  '$date_debut_echeance' AND '$date_fin_echeance') ";
                $q = pg_query($this->connexion, $query);
                if($q){
                    $euribors = pg_fetch_all($q);
                    $euribors = $this->FormaData($euribors, $q, false);
                }
                # enregistrement de la date d'application
                $euri_application   = $this->DatePeriode($date_debut_echeance,"Y-m-d");
                # calcul des échéances
                foreach ($euribors as $key => $value) {
                        # récupération du premier taux Euribor en cours
                        # si Euribor est négatif, on met le taux a zero
                        $taux = round(($value["euribor"]),6);
                        $Euribor =$taux;
                        if($Euribor < 0){
                            $Euribor = 0;
                            $taux =0;
                        }else{
                            break;
                        }

                }


                $datecalcul         = $this->DatePlus($datedepart, $frequences["nbinterval"]);
                $jours              = $this->DateInterval( $datedepart,$datecalcul,"d");
                $marge              = ($marge_banque/100);
                if($taux <= 0){
                    $tauxprorata        = ($marge / ($frequences["trancheannee"]/$frequences["nbinterval"]));
                    $tauxutilise        = $marge;
                }else{
                    $tauxprorata        = ((($Euribor + $marge_banque)/100) /  ($frequences["trancheannee"]/$frequences["nbinterval"]));
                    $tauxutilise        = ($marge_banque + $Euribor);
                }

                # calcul capital_rembourse
                if(!Empty($data["coefprogressivites"]) && $data["type_amortissement"] === "progressif"){
                    if($decalage_amortissement > 0){
                        $datediff = date("Y-m-d", $date1 + 54000);
                        $numprog = $this->DateInterval($datediff, $datediff, "y");
                        $interets = (($capital_debut * ($taux)) / ($frequences["trancheannee"] / $frequences["nbinterval"]));
                        $capital_rembourse = 0;
                        $echeance =  $interets;
                        $capital_amorti = 0;
                        # calcul valeur résiduelle
                        $capital_debut = $valeur_res;
                        $valeur_res = $capital;

                        $decalage_amortissement = $decalage_amortissement - 1;
                    }else {
                        $datediff = date("Y-m-d", $date1 + 54000);
                        $numprog = $this->DateInterval($data["date_premiere_echeance"], $datediff, "y");

                        # calcul du capital rembourse
                        $capital_periode = ($capital_annee[intval($numprog)]);
                        $capital_rembourse = $capital_periode / ($frequences["trancheannee"] / $frequences["nbinterval"]);


                        # calcul des intèrêts
                        $interets = ($capital_debut * $tauxprorata);

                        $capital_debut = $valeur_res;

                        # calcul de l'echeance
                        $echeance = ($capital_rembourse + $interets);

                        # calcul valeur résiduelle
                        $valeur_res = ($valeur_res - $capital_rembourse);
                    }
                }else{
                # decalage amortissement
                if( $decalage_amortissement >= $i ){
                    # calcul du taux actualise
                    $tauxactualise          = pow((1+$tauxprorata),-$frequences["nbecheances_reelle"]);
                    $taux_actualise_1       = 1-$tauxactualise;
                    if($taux_actualise_1    != 0){
                        $parametre          = $tauxprorata/$taux_actualise_1;
                    }else{
                        $parametre          = 0;
                    }
                    # calcul des intèrêts
                    $interets           = ($capital_debut * $tauxprorata);

                    $capital_debut      = $valeur_res;

                    $capital_rembourse = 0;

                    # calcul de l'echeance
                    $echeance           = ($interets);
                    # calcul valeur résiduelle
                    $valeur_res         = ($capital);

                }else{
                    # calcul du taux actualise
                    $tauxactualise          = pow((1+$tauxprorata),-$nbecheances_restant);
                    $taux_actualise_1       = 1-$tauxactualise;
                    if($taux_actualise_1    != 0){
                        $parametre          = $tauxprorata/$taux_actualise_1;
                    }else{
                        $parametre          = 0;
                    }
                    # calcul des intèrêts
                    $interets           = (($capital_debut) * $tauxprorata);

                    $capital_debut      = $valeur_res;

                    # calcul de l'echeance
                    $echeance           = ($valeur_res * $parametre);

                    $capital_rembourse  = ($echeance - $interets);
                    }
                    # calcul valeur résiduelle
                    $valeur_res         = ($valeur_res - $capital_rembourse);
                }





                # debut echeances
                $datecalcul = $this->DatePeriode($datedepart,"Y-m-d","fin");
                $date1                  = $this->DateVal($datecalcul);
                $date2                  = $this->DateVal($datediffere);


                if($i == ($frequences["nbecheances_reelle"])){
                    $echeance = $echeance + $valeur_res ;
                    $capital_rembourse = $capital_debut;
                    $valeur_res          = 0;
                }

                if ($date1 >= $date2) {
                    # tablea amortissement
                    array_push($tableau, ["idemprunt" => $id,
                            "echeances_numero"      => $i,
                            "montant_echeance"      => round($echeance,2),
                            "Euribor"               => $Euribor,
                            "marge"                 => $marge_banque,
                            "taux"                  => round(($tauxprorata * ($frequences["trancheannee"]/$frequences["nbinterval"]))*100,2),
                            "taux_utilise"          => round($tauxutilise,2),
                            "capital"               => round($capital_debut,2),
                            "capital_rembourse"     => round($capital_rembourse,2),
                            "montant_interets"      => round($interets,2),
                            "mois"                  => $moisplus,
                            "date_echeance"         => $datedepart,
                            "type_amortissement"    => $data["type_amortissement"],
                            "type_emprunt"          => $data["type_emprunt"],
                            "date_depart"           => $datediffere,
                            "valeur_residuelle"     => round($valeur_res,2)
                        ]
                    );

                } else {
                    # tablea amortissement
                    array_push($tableau, ["idemprunt" => $id,
                            "echeances_numero"      => $i,
                            "montant_echeance"      => round($interets,2),
                            "Euribor"               => $Euribor,
                            "marge"                 => $marge_banque,
                            "taux"                  => round(($tauxprorata *($frequences["trancheannee"]/$frequences["nbinterval"]))*100,2),
                            "taux_utilise"          => round($tauxutilise,2),
                            "capital"               => 0,
                            "capital_rembourse"     => 0,
                            "montant_interets"      => round($interets,2),
                            "mois"                  => $moisplus,
                            "date_echeance"         => $datedepart,
                            "type_amortissement"    => $data["type_emprunt"],
                            "date_depart"           => $datediffere,
                            "valeur_residuelle"     => round($valeur_res,2),
                        ]
                    );

                }


                # calcul de la date d'échéance toujours fin de mois
                $datedepart = $this->DatePlus($datedepart, $frequences["nbinterval"], "Y-m-d");
                $datedepart = $this->DatePeriode($datedepart,"y-m-d");
                $datedepart = $this->DateISO8601($datedepart);
                # calcul du mois
                $moisplus = $this->DatePeriode($datedepart, "m");
                # nombre d'échéance
                $nbecheances_restant--;
            }


            return $tableau;
        }

        /**
         * @param $id
         * @param $amortissement
         * @param $couverture
         * @return array|bool
         */
        public function UpdateEmpruntJson($id, $amortissements, $couverture)
        {
            $code   = (integer)NULL;
            $result = false;

            # enregistrement du tableau couverture
            if(count($couverture)>0){
                $array = json_encode(self::utf8_encode($couverture), true);
                $couverture = pg_escape_literal($array);
                $result = pg_query($this->connexion, "UPDATE emprunt_amortissement SET couverture = {$couverture} WHERE idamortissement=$id");
            }

            # enregistrement du tableau amortissement
            if($id>0) {
                $amortissements = self::utf8_encode($amortissements);
                $array = json_encode($amortissements,true);
                $amortissements = pg_escape_literal($array);
                $result = pg_query($this->connexion, "UPDATE emprunt_amortissement SET amortissements = {$amortissements} WHERE idamortissement=$id");
            }
            return $result;
        }

        /**
         * @param int|null $idinvestissement
         * @param int|null $idemprunt
         * @param array $amortissements
         * @return bool|int|null
         */
        public function CreateInvestissement(int $idinvestissement = null,int $idemprunt =null,array $amortissements = array())
        {
            $idamortissement        = (int)null;
            $portefeuille           = (array)null;
            $nom_portefeuille       = (string) null;
            $emprunts               = (array)null;
            $actifs                 = (array)null;
            $frequence              = (string)null;
            $idactifpatrimonial     = (int) null;
            $date_fin_echeance      = (string) null;
            $montant_financement    = (float) 0 ;

            # sauvegarde tableau actifs
            $actifs                 = $this->AddActifs($amortissements["actifs"],false);
            $portefeuille['actifs'] = $actifs;
            $idactifpatrimonial     = $amortissements["actifs"][0];






            # creation du portefeuille
            foreach ($amortissements["tranches"] as $key => $value) {
                $idamortissement    = $value["idamortissement"];
                if(!Empty($value["idactifpatrimonial"])){
                    $idactifpatrimonial = $value["idactifpatrimonial"];
                }


                $result = pg_query($this->connexion, "SELECT amortissements from emprunt_amortissement Where idamortissement = $idamortissement");
                $amort       = pg_fetch_all($result);
                $amort       = $this->FormaData($amort, $result, true);
                $amort = $this->getData($amort['amortissements']);

                if(Empty($amortissements["nom_portefeuille"])){
                    $keywords = preg_split("/[\s,]+/", $actifs[0]["adresse"]);

                    $nom_portefeuille = $keywords[count($keywords)-1];

                }else{
                    $nom_portefeuille = $amortissements["nom_portefeuille"];
                }


                # insertion du tableau des coefprogressivites
                if(!Empty($value['coefprogressivites'])) {
                    $coefprogressivites = $value['coefprogressivites'];
                }else{
                    $coefprogressivites = [];
                }
                # realise les calculs des interets et autres
                $totaux = $this->TotaliseAmortissement($amort);

                # les echeances n'ont pas commencees, la totalite du financement est du
                if($totaux["valeur_residuelle"] !== 0){
                 //   $totaux["valeur_residuelle"] = $value["montant_financement"];
                }
                # cumul montant financement
                $montant_financement = $montant_financement + $value["montant_financement"];

                # frequence
                $frequence = strtoupper($value["frequence"]);
                switch ($frequence) {
                    case "MENSUELLE" :
                        $frequence = "Mensuelle";
                        $duree_residuelle = intval($totaux["duree"]/12);
                        break;
                    case "TRIMESTRIELLE" :
                        $frequence = "Trimestrielle";
                        $duree_residuelle = intval($totaux["duree"]/4);
                        break;
                    case "SEMESTRIELLE" :
                        $frequence = "Semestrielle";
                        $duree_residuelle = intval($totaux["duree"]/2);
                        break;
                    case "ANNUELLE" :
                        $frequence = "Annuelle";
                        $duree_residuelle = intval($totaux["duree"]);
                        break;
                }

                # calcul de la date de fin
                $data1 = $this->DatePlus($value["date_premiere_echeance"],$value["duree_financement"] , "Y-m-d");
                $date_fin_echeance = $this->DatePeriode($data1,"y-m-d","fin");

                $emprunts[$key] = [
                    "idamortissement"           => $idamortissement,
                    "idemprunt"                 => $idemprunt,
                    "idactifpatrimonial"        => $idactifpatrimonial,
                    "montant_financement"       => $value["montant_financement"],
                    "idbanque"                  => $value["idbanque"],
                    "valeur_residuelle"         => $value["valeur_residuelle"],
                    "type_emprunt"              => $value["type_emprunt"],
                    "type_amortissement"        => $value["type_amortissement"],
                    "taux"                      => $value["taux"],
                    "nombre_echeances_restante" => $totaux["nombre_echeances"],
                    "duree_financement"         => $value["duree_financement"],
                    "date_premiere_echeance"    => $value["date_premiere_echeance"],
                    "date_derniere_echeance"    => $date_fin_echeance,
                    "date_differee"             => $value["date_differee"],
                    "decalage_amortissement"    => $value["decalage_amortissement"],
                    "frequence"                 => strtolower($frequence),
                    "capital_restant"           => $totaux["valeur_residuelle"],
                    "duree_reelle"              => $totaux["duree"],
                    "duree_residuelle"          => $duree_residuelle,
                    "CRD"                       => $totaux["valeur_residuelle"],
                    "montant_interets"          => round($totaux["montant_interets"], 2),
                    "couverture_taux"           => $value["couverture_taux"],
                    "date_debut_swap"           => $value["date_debut_swap"],
                    "date_debut_cap"            => $value["date_debut_cap"],
                    "marge_banque"              => $value["marge_banque"],
                    "taux_swap"                 => $value["taux_swap"],
                    "taux_cap"                  => $value["taux_cap"],
                    "prime_cap"                 => $value["prime_cap"],
                    "montant_prime_lisse"       => $value["montant_prime_lisse"],
                    "montant_swap"              => $value["montant_swap"],
                    "montant_cap"               => $value["montant_cap"],
                    "strike_cap"                => $value["strike_cap"],
                    "duree_cap"                 => $value["duree_cap"],
                    "coefprogressivites"        => $coefprogressivites,
                ];
            }
            # insertion du tableau des emprunts
            $portefeuille['emprunts']   = $emprunts;
            $nom_portefeuille = pg_escape_string($nom_portefeuille);

            # tableau de l'investissement
            if ($portefeuille) {
                # creation du json
                $json = json_encode($portefeuille,JSON_NUMERIC_CHECK);
                $json = pg_escape_literal($json);

                # enregistrement de investissements
                if ($idinvestissement !== 0) {
                    $result = pg_query($this->connexion, "UPDATE investissements SET investissements =($json),idactifpatrimonial = $idactifpatrimonial,nom_portefeuille = '$nom_portefeuille' WHERE idinvestissement={$idinvestissement}");
                } else {
                    $idinvestissement = $this->NewSequence( 'investissements','idinvestissement',$this->connexion);
                    $result = pg_query($this->connexion, "INSERT INTO investissements (idinvestissement, investissements,idactifpatrimonial, nom_portefeuille) VALUES ($idinvestissement,$json,$idactifpatrimonial,'$nom_portefeuille') ");
                }
                if ($result) {
                    $result = pg_query($this->connexion, "UPDATE donnees_emprunt SET idinvestissement = $idinvestissement WHERE idemprunt={$idemprunt}");
                    $result = pg_query($this->connexion, "UPDATE actif_patrimonial SET montant_du_financement = $montant_financement,
                                                                                             nom_portefeuille = '$nom_portefeuille',
                                                                                             idinvestissement = $idinvestissement,
                                                                                             financement      = true
                                                                WHERE idactifpatrimonial={$idactifpatrimonial}");
                    return $idemprunt;
                } else {
                    $state = pg_last_error();
                    $result_error = "erreur d'execution de la requete :" . __FUNCTION__ . " Detail de l'erreur :" . $state;
                    $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1) . $result_error . ': ' . __FUNCTION__);
                    return false;

                }

            } else {
                return $idemprunt;
            }
        }

        /**
         * @param $amortissements
         * @return array
         */
        public function TotaliseAmortissement($amortissements)
        {
            $compteur           = (int)0;
            $compt_eche         = (int)0;
            $interets           = (float)0;
            $valeurresiduelle   = (float) 0;
            $invest = (array)null;
            if ($amortissements) {
                $invest['montant_financement'] = ($amortissements[0]['valeur_residuelle'] + $amortissements[0]['capital']);
                $invest['type_emprunt']        = $amortissements[0]['type_emprunt'];
                $invest['type_amortissement']  = $amortissements[0]["type_amortissement"];
                $invest['taux']                = $amortissements[0]['taux'];
                $invest['date_premiere_echeance']= $amortissements[0]['date_echeance'];

                foreach ($amortissements as $key => $value) {
                    $compteur++;
                    $interval = intval($this->DateInterval($value['date_echeance'], SETTING_DAY_NOW));
                    if ($interval > 0 ) {
                        $valeurresiduelle = floatval($value["valeur_residuelle"]);
                    }

                    if ($interval < 0) {
                        $compt_eche++;
                    }
                    $interets = $interets + $value["montant_interets"];
                    $invest["duree"] = $compteur;
                    $invest["montant_interets"]       = $interets;
                    $invest['nombre_echeances']       = $compt_eche;
                    $invest["valeur_residuelle"]      = $valeurresiduelle;
                    $invest["date_derniere_echeance"] = $value['date_echeance'];

                }
            }
            # return value null else empty
            if (Empty($invest)) {
                $invest["duree"] = 0;
                $invest["montant_interets"]         = 0;
                $invest['nombre_echeances']         = 0;
                $invest["valeur_residuelle"]        = 0;
                $invest['montant_financement']      = 0;
                $invest['type_emprunt']             = null;
                $invest['type_amortissement']       = null;
                $invest['taux']                     = 0;
                $invest["date_derniere_echeance"]   = null;
                $invest['date_premiere_echeance']   = null;
            }

            return $invest;
        }

        /**
         * @param null $idemprunt
         * @param array $data
         * @return array|bool
         */
        public function AddInfosEmprunt($idinvest = null, $data = array())
        {
            $code = (integer)null;
            $result = (bool) true;
            $result_error = (string)null;
            if ($idinvest) {
                # query locaux idemprunt = $id
                $query = "SELECT  idinvestissement,nom_portefeuille,			
                            investissements FROM investissements WHERE idinvestissement ={$idinvest}";

                # test de la rtequete
                $result = pg_send_query($this->connexion, $query);
                $res1 = pg_get_result($this->connexion);
                $result_error = pg_result_error($res1);
                if (Empty($result_error)) {
                    # query locaux idlocal = id
                    $result = pg_query($this->connexion, $query);
                    # fetch result
                    $res = pg_fetch_all($result);
                    # For booleans and numeric convert
                    $res = $this->FormaData($res, $result, true);
                    return $res;

                } else {
                    return false;
                }
            }
        }

        /**
         * @url POST /donneesemprunt
         * @url POST /donneesemprunt/$data
         */
        public function AddDonneesEmprunt($request, $response, $arg)
        {
            $code                   = (integer)null;
            $result                 = (bool)null;
            $result_error           = (string)null;
            // $datas                  = $request->getParsedBody();
            $actifs                 = (array) null;
            $jsona                   = $request->getParam("data");
            if(Empty($jsona)){
                //    $jsona                   = str_replace(" ","",$request->getParam("Contenu"));
                $jsona                   = $request->getParam("Contenu");
                $jsona                  = self::utf8_encode($jsona);
            }
            $data                   = $this->getData($jsona);
            # $body                   = $request->getBody();
            $emprunt                = (array)null;
            $idemprunt              = (int)0;
            $idinvestissement       = (int) 0;
            $idamortissement        = (int) 0;
            $valeur_residuelle      = (float) 0;
            $result                 = false;
            $euribord               = (float) null;
            $couverture             = (array) null;

            foreach ($data["tranches"] as $key => $value) {

                # nettoyage
                $data["tranches"][$key]["marge_banque"]    =str_replace("%",null, $data["tranches"][$key]["marge_banque"]);
                $data["tranches"][$key]["taux"]    =str_replace("%",null, $data["tranches"][$key]["taux"]);
                $data["tranches"][$key]["taux_swap"]    =str_replace("%",null, $data["tranches"][$key]["taux_swap"]);
                $data["tranches"][$key]["taux_cap"]    =str_replace("%",null, $data["tranches"][$key]["taux_cap"]);
                $data["tranches"][$key]["strike_cap"]    =str_replace("%",null, $data["tranches"][$key]["strike_cap"]);



                # format $data with escape string
                $array = $this->InsertFormaData($data["tranches"][$key] , $this->connexion);

                # valeur par defaut
                $valeur_residuelle = $array["montant_financement"];

                # suppression des json avant l'insert
                unset($array['coefprogressivites']);
                unset($array['idamortissement']);
                unset($array['idactifpatrimonial']);
                unset($array['nombre_echeances_restante']);
                unset($array['capital_restant']);
                unset($array['duree_reelle']);
                unset($array['montant_interets']);
                unset($array['nom_portefeuille']);

                if ($array['type_emprunt'] !== 'taux_variable' ||  Empty($array["couverture_taux"])) {
                    $array["couverture_taux"]       =null;
                    $array["date_debut_swap"]       =null;
                    $array["date_debut_cap"]        =null;
                    $array["taux_swap"]             =null;
                    $array["taux_cap"]              =null;
                    $array["prime_cap"]             =null;
                    $array["montant_prime_lisse"]   =null;
                    $array["montant_swap"]          =null;
                    $array["montant_cap"]           =null;
                    $array["strike_cap"]            =null;
                    $array["duree_cap"]             =null;
                }

                # suppression des key [amortissement_anne_x]
                foreach($array  as $key2 => $value2){
                    if(substr($key2,0,19) ==='amortissement_annee' ){
                        unset($array[$key2]);
                    }
                }



                # if method PUT or POSt getValidateFields
                $error = $this->getValidateFields($this->maintable, $array);
                if ($error) {
                    $code = 400;
                    return $this->getResponseData($code, $request, $response, $error);
                }
                if ($idemprunt === 0) {
                    # insert $data
                    $array['idemprunt'] = $this->NewSequence( $this->maintable,'idemprunt',$this->connexion);
                    # creation du nouvel emprunt
                    $result = pg_insert($this->connexion, $this->maintable, $array, PGSQL_DML_EXEC);

                    if ($result) {
                        # dernier id inséré
                        $idemprunt = $array['idemprunt'];
                        # encodage json de l'array actifs'
                        if(isset($data['actifs']) && !Empty($data['actifs'])){
                            $actifs['actifs'] = $this->AddActifs($data['actifs']);
                            $actifs['actifs'] = pg_escape_literal($this->connexion, $actifs['actifs']);
                            # sauvegarde des actifs dans donnees_emprunt
                            $result = pg_query($this->connexion, "UPDATE donnees_emprunt SET actifs = {$actifs['actifs']} WHERE idemprunt= {$idemprunt}");
                        }{
                            $actifs['actifs'] = null;
                        }

                        if(isset($data['tranches'][0]['coefprogressivites'])){
                            $json = json_encode(self::utf8_encode($data['tranches'][0]['coefprogressivites']));
                            $json = pg_escape_literal($json);
                            # sauvegarde des actifs dans donnees_emprunt
                            $result = pg_query($this->connexion, "UPDATE donnees_emprunt SET coefprogressivites= {$json} WHERE idemprunt= {$idemprunt}");
                        }else{
                            $json = null;
                        }

                        if (!$result) {
                            $idemprunt = 0;
                        }
                    } else {
                        $code = 500;
                        $state = pg_last_error();
                        // some error happened
                        $result_error = "erreur d'execution de la requete 1 :" . __FUNCTION__ . " Detail de l'erreur " . $jsona;
                        $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1) . $result_error . ': ' . __FUNCTION__);
                        return $this->getResponseData($code, $request, $response, ["returncode" => 500, "message" => "Erreur lors de l'execution de la requete :" . __FUNCTION__ . " Detail :" . $result_error, "code" => 500]);
                    }
                }

                if ($idemprunt > 0) {
                    # création des paramètres de l'emprunt
                    $emprunt['idemprunt'] = $idemprunt;


                    # préparation des données pour calculer le tableau des amortissements
                    $amort = $data['tranches'][0];
                    $amort['idemprunt'] = $idemprunt;

                    # tableau d'amortissements du prêt Fixe
                    if ($array['type_emprunt'] === 'taux_fixe') {
                        $amortissements = $this->EmpruntFixe($data["tranches"][$key]);
                    }

                    # tableau d'amortissements du prêt Variable
                    if ($array['type_emprunt'] === 'taux_variable') {
                        # tableau d'amortissement du prêt
                        $amortissements = $this->EmpruntVariable($amort);
                        # couverture cap or swap
                        if (floatval($array['montant_cap']) > 0 || floatval($array['montant_swap']) > 0) {
                            $couverture = $this->CouverturePrets($amort, $amortissements);
                        }
                    }

                    # date derniere echeance, taux utilise, euribord
                    $data['tranches'][0]['date_derniere_echeance']    = $amortissements[count($amortissements) - 1]['date_echeance'];
                    $data['tranches'][0]['date_derniere_echeance']    = substr($array['date_derniere_echeance']  ,0,10);


                    $taux   = $amortissements[count($amortissements) - 1]['taux'];
                    if(isset($amortissements[count($amortissements) - 1]['Euribor']) ){
                        $euribord = $amortissements[count($amortissements) - 1]['Euribor'];
                    }



                    # mise a jour de la date de la derniere echeance & taux utilise
                    $result = pg_query($this->connexion, "UPDATE donnees_emprunt 
                                                                     SET date_derniere_echeance = {$array['date_derniere_echeance']}, 
                                                                         decalage_amortissement = {$array['decalage_amortissement']}, 
                                                                         taux ={$taux},indice_euribor ={$euribord},
                                                                         valeur_residuelle = {$valeur_residuelle}  
                                                                     WHERE idemprunt= {$idemprunt}");


                    # format $data with escape string
                    $emprunt = $this->InsertFormaData($emprunt, $this->connexion);
                    $emprunt['idsociete'] = intval($value["idsociete"]);

                    # insert into emprunt amortissement
                    $emprunt['idamortissement'] = $this->NewSequence( 'emprunt_amortissement','idamortissement',$this->connexion);
                    $result = pg_insert($this->connexion, 'emprunt_amortissement', $emprunt, PGSQL_DML_EXEC);
                    if ($result) {
                        $idamortissement = $emprunt['idamortissement'];
                        # ajouter l'idamortissement à la tranche
                        $data["tranches"][$key]["idamortissement"] = $idamortissement;

                        # insertion du tableau d'amortissement
                        $result = $this->UpdateEmpruntJson($idamortissement, $amortissements, $couverture);

                    } else {
                        $code = 500;
                        $state = pg_last_error();
                        // some error happened
                        $result_error = "erreur d'execution de la requete 3 :" . __FUNCTION__ . " Detail de l'erreur :" . $json;
                        $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1) . $result_error . ': ' . __FUNCTION__);
                        return $this->getResponseData($code, $request, $response, ["returncode" => 500, "message" => "Erreur lors de l'execution de la requete :" . __FUNCTION__ . " Detail :" . $result_error, "code" => 500]);
                    }
                }
            }
            # fin de Foreach

            if($result){

                # creation du tableau de l'investissement
                $idinvestissement = $this->NewSequence( 'investissements','idinvestissement',$this->connexion);
                $portefeuille = ["idinvestissement" =>$idinvestissement, "actifs" => [], "emprunts" => []];
                $portefeuille['actifs'] = $data["actifs"];
                # sauvegarde de l'amortissement dans le portefeuiille
                foreach ($data["tranches"] as $key => $value){
                    array_push($portefeuille["emprunts"], ["idamortissement" => $value["idamortissement"], "idemprunt" => $idemprunt]);
                }
                $invest = json_encode($portefeuille,true);
                $invest = pg_escape_literal($this->connexion,$invest);
               $res = pg_query($this->connexion, "INSERT INTO investissements (idinvestissement, investissements) VALUES ($idinvestissement, $invest)");
                $res = $this->CreateInvestissement($idinvestissement,$idemprunt, $data);
            }

            if ($result) {
                # recherce du dernier tableau saisi
                $q = pg_query($this->connexion, "SELECT max(idemprunt) as idemprunt FROM $this->maintable");
                $emprunt = pg_fetch_all($q);
                $idemprunt = intval($emprunt[0]['idemprunt']);
                # return le resultat complet (emprunt + tableau amortissement)
                $res = $this->AddInfosEmprunt($idinvestissement);
                $code = 200;
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete :" . __FUNCTION__ . " Detail de l'erreur :" . $state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1) . $result_error . ': ' . __FUNCTION__);
                return $this->getResponseData($code, $request, $response, ["returncode" => 500, "message" => "Erreur lors de l'execution de la requete :" . __FUNCTION__ . " Detail :" . $result_error, "code" => 500]);

            }
            return $this->getResponseData($code, $request, $response, $res);
        }

        /**
         * @url DELETE /donneesemprunt/$id
         */
        public function DeleteDonneesEmprunt(Request $request, Response $response, $arg)
        {
            $code = (integer)null;
            $idemprunt = intval($arg['id']);
            $idinvest = (int) null;
            $emprunts = (array) null;
            # delete ou sauvegarde des éléments de la tranche du portefeuille
            $res = pg_query($this->connexion,"SELECT idinvestissement, investissements,ele->>'idemprunt' as idemprunt
                                                        FROM investissements t,
                                                        json_array_elements(investissements->'emprunts') ele
                                                        where  (ele->>'idemprunt')::int = {$idemprunt}");

            if($res){
                $invest = pg_fetch_all($res);
                $investissements = $this->FormaData($invest, $res, true);
                # sauvegarde de l'idinvestissement
                $idinvest = intval($investissements['idinvestissement']);
                # examen du tableau des tranches
                $invest = $this->getData($investissements['investissements']);
                foreach ($invest as $key => $value){
                    if(intval(isset($value["idemprunt"]) && ($value["idemprunt"]) !== $idemprunt)){
                        $idinvest = intval($value['idinvestissement']);
                        array_push($emprunts,$value);
                    }

                }

                if(count($emprunts)>0){
                    # sauvegarde des tranches autres que $idemprunt
                    $json = json_encode(self::utf8_encode(($emprunts)));
                    $json = pg_escape_literal($json);
                    $result = pg_query($this->connexion, "UPDATE investissements SET investissements =($json) WHERE idinvestissement={$idinvest}");
                }else{
                    # delete le portefeuille
                    $result = pg_query($this->connexion, "DELETE FROM investissements WHERE idinvestissement={$idinvest}");
                }

                if ($result) {
                    # recherce du dernier tableau saisi
                    $q = pg_query($this->connexion, "DELETE FROM emprunt_amortissement WHERE idemprunt = {$idemprunt}");
                } else {

                    $code = 500;
                    $state = pg_last_error();
                    // some error happened
                    $result_error = "erreur d'execution de la requete :" . __FUNCTION__ . " Detail de l'erreur :" . $state;
                    $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1) . $result_error . ': ' . __FUNCTION__);
                    return $this->getResponseData($code, $request, $response, ["returncode" => 500, "message" => "Erreur lors de l'execution de la requete :" . __FUNCTION__ . " Detail :" . $result_error, "code" => 500]);

                }
            }

            $res = pg_delete($this->connexion, $this->maintable, ["idemprunt" => "$idemprunt"], PGSQL_DML_EXEC);
            if ($res) {
                # For booleans and numeric convert
                $res = ["message" => "L'Enregistrement a été éffacé", "Enregistrement supprimé ID :" => $idemprunt];
                $code = 200;
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete :" . __FUNCTION__ . " Detail de l'erreur :" . $state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1) . $result_error . ': ' . __FUNCTION__);
                return $this->getResponseData($code, $request, $response, ["returncode" => 500, "message" => "Erreur lors de l'execution de la requete :" . __FUNCTION__ . " Detail :" . $result_error, "code" => 500]);
            }

            return $this->getResponseData($code, $request, $response, $res);

        }

        /**
         * @param $data
         * @param array $amortissement
         * @return array
         */
        public function CouverturePrets($data, $amortissement =array())
        {
            $capital                    = (float)  0;
            $coefcapital                = (float)  0;
            $nbecheances                = (int)    intval($data["duree_financement"]);
            $nbecheances_reelle         = (int)    $nbecheances;
            $interets                   = (float)  0;
            $taux                       = (float)  0;
            $tableau                    = (array)  null;
            $datedepart                 = (string) null;
            $frequence                  = (string) $data["frequence"];
            $capital_rembourse          = (float)  0;
            $valeur_res                 = (float)  0;
            $couverture_taux            = (string) $data['couverture_taux'];
            $strike_cap                 = (string) null;
            $duree_swap                 = (int)  $data['duree_swap'];
            $duree_cap                  = (int)  $data['duree_cap'];
            $montant_swap               = (float)  0 ;
            $montant_cap                = (float)  0 ;
            $taux_swap                  = (float)  floatval($data["taux_swap"]) ;
            //$taux_cap                   = (float)  floatval($data["taux_cap"]) ;
            $prime_cap                   = (float)  floatval($data["montant_prime_lisse"]) ;
            $date_debut_swap            = (string) null;
            $date_debut_cap             = (string) null;
            $durreeannee                = (int)    $nbecheances /12;
            $parametre                  = (float) 0;
            $tauxactualise              = (float) 0;
            $tauxactualise_1            = (float) 0;
            $montanttaux                = (float) 0;
            $tauxprorata                = (float) 0;
            $compteur                    = (int) 0;

            # recupération données data id
            $id = $data['idemprunt'];

            # type de couverture
            if($data["couverture_taux"] === 'cap')
            {
                # récupération data cap
                $strike_cap         = $data['strike_cap']/100;
                $date_debut_cap     = $data['date_debut_cap'];
                $datedepart         = $date_debut_cap;
                $nbecheances         = ($duree_cap*12);
                if(Empty($duree_cap)){$nbecheances = intval($data["duree_financement"]);}
                $montant_cap        = floatval($data["montant_cap"]) ;
                $taux               = $prime_cap/100;
                $capital            = $montant_cap;
                $capital_rembourse  = $montant_cap;
                $valeur_res         = $montant_cap;
            }else if($data["couverture_taux"] === 'swap')
            {
                # récupération data swap
                $date_debut_swap    = $data['date_debut_swap'];
                $datedepart         = $date_debut_swap;
                $nbecheances         = ($duree_swap*12);
                if(Empty($duree_swap)){$nbecheances = intval($data["duree_financement"]);}
                $montant_swap       = floatval($data["montant_swap"]) ;
                $taux               = $taux_swap/100;
                $capital            = $montant_swap;
                $capital_rembourse  = $montant_swap;
                $valeur_res         = $montant_swap;

            }

            foreach ($amortissement as $key1 => $amort){
                $date1 = $this->DatePeriode($datedepart,"Y-m-d","fin");
                $date2 = $this->DatePeriode($amort["date_echeance"],"Y-m-d","fin");
                $date1 = $this->DateVal($date1);
                $date2 = $this->DateVal($date2);
                $compteur++;
                if($date2 >=$date1){break;}
            }

            # calcul de la frequenc & report de la fréquence sur les échéances
            $frequences = [
                "frequence"             => $data["frequence"],
                "trancheannee"          => 12,
                "nbecheances"           => $nbecheances,
                "nbecheances_reelle"    => $nbecheances,
                "nbinterval"            => 1
            ];
            # calcul de la frequence
            $frequences = $this->getEcheances($frequences,$datedepart,$datedepart);

            if(!Empty($data["couverture_taux"])) {
                if($data["couverture_taux"] ==="cap"){

                }
                $montanttaux                = ($taux);
                $tauxprorata                = ($montanttaux /  ($frequences["trancheannee"]/$frequences["nbinterval"]));


                # calcul taux Actualise
                $tauxactualise      = pow((1+$tauxprorata),(-$frequences['nbecheances']));
                $tauxactualise_1    = 1-$tauxactualise;
                # calcul des intèrêts
                $interets           = ($capital * $tauxprorata);
                # paramêtre
                if($tauxprorata !== 0){
                    $parametre      = ($tauxprorata/$tauxactualise_1);
                }

                # calcul de l'echeance
                $echeance           = ($parametre * $capital);
                //$echeance           = ($capital * $taux * pow((1 + $taux), $frequences['nbecheances'])) / (pow((1 + $taux), $frequences['nbecheances']) - 1);
                # calcul du capital restant
                $capital_rembourse  = ($echeance - $interets);
            }

            $coefcapital    = ($amortissement[0]["capital"]/$capital);
            $this->DatePeriode($datedepart, "m");
            # $datediffere non mulle
            if (Empty($datediffere)) {
                $datediffere = $datedepart;
            }
            for ($i = 1; $i <= $frequences['nbecheances_reelle']; $i++) {
                $date1 = $this->DateVal($datedepart);
                $date2 = $this->DateVal($datediffere);

            # calcul de la pate reception du SWAP
            if($data["couverture_taux"] ==="swap") {
                $tauxprorata_pate_reception = (($amortissement[$compteur]["Euribor"] + $amortissement[$compteur]["marge"]) / 100);
                $pate_reception = $valeur_res * ($tauxprorata_pate_reception / ($frequences["trancheannee"] / $frequences["nbinterval"]));
            }

            # calcul de la patereception du CAP
            # si % $tauxprorata_pate_reception >= $strike, on déclenche le remboursement de la pate reception
            if($data["couverture_taux"] ==="cap"){
                $tauxprorata_pate_reception     = (($amortissement[$compteur]["Euribor"]+$amortissement[$compteur]["marge"])/100);
                if($tauxprorata_pate_reception >= $strike_cap){
                    $tauxprorata_pate_reception     = (($amortissement[$compteur]["Euribor"]+$amortissement[$compteur]["marge"])/100)-$strike_cap;
                    $pate_reception                 = $valeur_res*($tauxprorata_pate_reception/ ($frequences["trancheannee"]/$frequences["nbinterval"]));
                }else{
                    $pate_reception                 = 0;
                }
             }



                if ($date1 >= $date2) {
                    # tablea amortissement
                    array_push($tableau, ["idemprunt" => $id,
                            "echeances_numero"   => $i,
                            "capital_debut"      => round($valeur_res, 2),
                            "mensualite"         => round($echeance,2),
                            "pate_reception"     => round($pate_reception,2),
                            "net"                => round($pate_reception-$echeance,2) ,
                            "pate_payeuse"       => $interets, # La pate payeuse est l'intêret
                            "date_echeance"      => $datedepart,
                            "capital_rembourse"  => round($capital_rembourse, 2),
                            "capital_restant"    => round($valeur_res - $capital_rembourse, 2),
                        ]
                );
                }


                # calcul de la date d'échéance
                $datedepart = $this->DatePlus($datedepart, $frequences['nbinterval'], "Y-m-d");
                $datedepart = $this->DateISO8601($datedepart);
                # calcul du mois
                $moisplus = $this->DatePeriode($datedepart, "m");
                # calcul capital restant
               // $valeur_res = ($valeur_res - $capital_rembourse);
                # calcul des intèrêts
                $valeur_res      = ($amortissement[$compteur]["capital"]/ $coefcapital);
                $interets           = ($valeur_res* $tauxprorata);
                $capital_rembourse  = ($echeance - $interets);
                $compteur++;
            }


            return $tableau;
        }

        /**
         * @param $frequences
         * @return mixed
         */
        public function getEcheances($frequences,$datedepart, $datediffere){
            $nbecheances        = (int) $frequences["nbecheances"];
            $nbecheances_reelle = (int) $frequences["nbecheances_reelle"];
            # calcul des dates différés
            if (!Empty($datediffere)) {
                $echeancediffere = $this->DateInterval($datedepart, $datediffere, "m") ;
                $nbecheances_reelle = $nbecheances_reelle + $echeancediffere;
            }else {
                $nbecheances_reelle = $nbecheances;
            }

            # calcul de la frequence
            if (strpos($frequences["frequence"], 'elle') === false) {
                $frequences["frequence"] = str_replace("mensuel", "mensuelle", $frequences["frequence"]);
                $frequences["frequence"] = str_replace("trimestriel", "trimestrielle", $frequences["frequence"]);
                $frequences["frequence"] = str_replace("semestriel", "semestrielle", $frequences["frequence"]);
                $frequences["frequence"] = str_replace("annuel", "annuelle", $frequences["frequence"]);
            }
            # report de la fréquence sur les échéances
            $frequence = strtoupper($frequences["frequence"]);
            switch ($frequence) {
                case "MENSUELLE" :
                    $frequences["nbinterval"]           = 1;
                    $frequences["frequence"]            = "mensuelle";
                    $frequences["trancheannee"]         = 12;
                    $frequences["nbecheances"]          = $nbecheances/$frequences["nbinterval"];
                    $frequences["nbecheances_reelle"]   = round($nbecheances_reelle/$frequences["nbinterval"]);
                    break;
                case "TRIMESTRIELLE" :
                    $frequences["nbinterval"]           = 3;
                    $frequences["frequence"]            = "trimestrielle";
                    $frequences["trancheannee"]         = 12;
                    $frequences["nbecheances"]          = $nbecheances/$frequences["nbinterval"];
                    $frequences["nbecheances_reelle"]   = round($nbecheances_reelle/$frequences["nbinterval"]);
                    if( ($frequences["nbecheances_reelle"] % 3) !== 0){
                      //   $frequences["nbecheances_reelle"] += 1;
                    }
                    break;
                case "SEMESTRIELLE" :
                    $frequences["nbinterval"]           = 6;
                    $frequences["frequence"]            = "semestrielle";
                    $frequences["trancheannee"]         = 2;
                    $frequences["nbecheances"]          = $nbecheances/$frequences["nbinterval"];
                    $frequences["nbecheances_reelle"]   = round($nbecheances_reelle/$frequences["nbinterval"]);
                    if( ($frequences["nbecheances_reelle"] % 6) !== 0){
                        $frequences["nbecheances_reelle"] += 1;
                    }
                    break;
                case "ANNUELLE" :
                    $frequences["nbinterval"]           = 12;
                    $frequences["frequence"]            = "annuelle";
                    $frequences["trancheannee"]         = 1;
                    $frequences["nbecheances"]          = $nbecheances/$frequences["nbinterval"];
                    $frequences["nbecheances_reelle"]   = round($nbecheances_reelle/$frequences["nbinterval"]);
                    break;
            }


            return $frequences;
        }


        /**
         * @param $taux
         * @param $capital
         * @param $duree_financement
         * @param $nbinterval
         * @param $nbecheance
         * @return array
         */
        public function CalculInterets($taux,$capital,$duree_financement, $nbinterval, $nbecheance) {
            $prorata        = (float) $taux /  (12/$nbinterval);
            $actualise      = (float) pow((1+$prorata),-$nbecheance);
            $actualise_1    = (float) 1-$actualise;
            $param          = (float) ($prorata / $actualise_1);
            $echeance       = (float) ($capital * $param);
            $interets       = (float) ($capital * $prorata);
            $partcapital    = (float) ($echeance-$interets);

            return ["interets" => $interets, "echeance" => $echeance, "partcapital" => $partcapital];
        }


        /**
         * @param Request $request
         * @param Response $response
         * @param $arg
         * @return Response
         */
        public function getCalculateur(Request $request, Response $response, $arg)
        {
            $code                   = (integer) null;
            $jsona                  = $request->getParam("data");
            $data                   = $this->getData($jsona);
            $taux                   = (float)   $data["taux"]/100;
            $capital                = (float)   $data["capital"];
            $part_capital           = (float)   0;
            $echeance               = (float)   0;
            $duree_financement      = (int)     $data["duree_annee"]*12;
            $nbinterval             = (int)     3;
            $nbecheance             = (int)     $duree_financement / $nbinterval;
            $result                 = (array)   array();
            $emprunt                = (array)   array();


            for($i =1; $i <=4;$i++){
                # calcul échances, intérets
                $result = $this->CalculInterets($taux,$capital,$duree_financement, $nbinterval, $nbecheance);
                # pour les échéances un seul trimestre
                if(!isset($emprunt["trimestrialite"])){
                    $emprunt["trimestrialite"]   = round($result["echeance"],2);
                    $echeance    = round($result["echeance"],2);
                }
                # calcul part capital
                $part_capital = ($echeance-$result["interets"]);
                $emprunt["interets_annee"]      += round($result["interets"],2);
                $emprunt["echeance_annee"]      += round($echeance,2);
                $emprunt["capital_annee"]       += round($part_capital,2);
                # calcul capital restant
                $capital = $capital-$part_capital;

            }



            if($result) {
                # return le resultat complet (interets, echeances, partcapital)
                $result = json_encode($emprunt);
                $code = 200;
            } else{
                $code = 400;
                $state = "Aucune donnees à calculer";
                // some error happened
                $result_error = "erreur calculateur :" . $state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1) . $result_error . ': ' . __FUNCTION__);
                return $this->getResponseData($code, $request, $response, ["returncode" => 400, "message" => "Erreur lors de l'execution de la fonction :" . __FUNCTION__ . " Detail :" . $result_error, "code" => 400]);
            }

            return $this->getResponseData($code, $request, $response, $result);

        }


    }
}

