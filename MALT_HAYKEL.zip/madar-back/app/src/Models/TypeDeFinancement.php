<?php
/**
 * Copyright (c)  2018. L’ensemble du contenu (codes, textes, photographies, infographies, icônes, etc.) du site www.you-fleet.fr est la propriété exclusive de  sas ODEA, éditeur du site you-fleet.fr enregistrés à l'agence pour la protection des programmes sous le N°IDDN.FR.001.43005.000.R.P.2016.000.20100 Tous droits de reproduction ou de représentation de ceux-ci sont réservés.
 */



/**
 * Created by PhpStorm.
 * User: dahan
 * Date: 08/07/2018
 * Time: 10:37
 */

namespace  App\Models {
    require_once __DIR__ . '/Tools.php';
    use Psr\Log\LoggerInterface;
    use \Psr\Http\Message\ServerRequestInterface as Request;
    use \Psr\Http\Message\ResponseInterface as Response;
    use App\Models\Tools;
    use PDO;

    class TypeDeFinancement extends Tools
    {

        /**
         * @var $connexion
         */
        public $connexion;

        /**
        /**
         * @var \Psr\Log\LoggerInterface
         */
        private $logger;

        /**
         * @var \PDO
         */
        private $pdo;

        /**
         * @var $maintable
         */
        private $maintable;

        /**
         * TypeDeFinancement constructor.
         */
        public function __construct(LoggerInterface $logger, PDO $pdo, $table,$c)
        {
            parent::__construct($c, $logger);

            # connexion to php_pgsql
            $this->connecte();

            # name of the data table
            $this->maintable = $table;

            # log this access data
            $this->logger    = $logger;

            # if you need PDO
            //$this->pdo       = $pdo;

            # renumber the sequences when config is true
            if (SETTING_NEW_SEQUENCE)
            {
                $this->setSequence($table);
            }

        }


        /**
         *  destruct a curently connexion
         * TypeDeFinancement destruct.
         */
        public function __destruct()
        {
            pg_close($this->connexion);
        }


        /**
         * modifier la sequence des id automatique
         * @param null
         */
        public function setSequence($table)
        {
            $q = pg_query($this->connexion, "SELECT max(idtype_de_financement) as idtype_de_financement FROM $table");
            $actif = pg_fetch_all($q);
            $newmax = (intval($actif[0]['idtype_de_financement'])+1);
            $this->RenumSequence($table,$newmax,$this->connexion);
        }


        /**
         * @url GET /typedefinancement
         */
        public function getListTypeDeFinancement(Request $request,Response $response, $arg)
        {
            $code = (integer) null;
            $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);
            $table = $this->maintable != '' ? $this->maintable : $this->path;
            $q = pg_query($this->connexion, "SELECT * FROM $this->maintable");
            $res = pg_fetch_all($q);
            if ($res) {
                # For booleans and numeric convert
                $res =$this->FormaData($res, $q, false);
                $code = 200;
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
            }
            return $this->getResponseData($code, $request, $response,$res);
        }


        /**
         * @url GET /typedefinancement/$id
         * @url GET /typedefinancement=current
         */
        public function getTypeDeFinancement(Request $request,Response $response, $arg)
        {
            $code = (integer) null;
            $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);
            $table = $this->maintable != '' ? $this->maintable : $this->path;
            $id = $arg['id'];
            if ($id) {
                # query locaux idtype_de_financement = id
                $q = pg_query($this->connexion, "SELECT * FROM $this->maintable WHERE idtype_de_financement ={$id}");
                # fetch result
                $res = pg_fetch_all($q);
                if ($res) {
                    # For booleans and numeric convert
                    $res =$this->FormaData($res, $q, true);
                    $code = 200;
                } else {
                    $code = 500;
                    $state = pg_last_error();
                    // some error happened
                    $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                    $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                    return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
                }
            } else {
                $code = 400;
            }
            return $this->getResponseData($code, $request, $response,$res);
        }


        /**
         * @url PUT /typedefinancement/$id
         * @url PUT /typedefinancement/$id/$data
         */
        public function UpdateTypeDeFinancement(Request $request,Response $response, $arg)
        {
            $code = (integer) null;
            $id = $arg['id'];
            $data = $request->getParam('data');
            $data = $this->getData($data);
            # if method PUT or POSt getValidateFields
            $error = $this->getValidateFields($this->maintable,$data);
            if($error){
                $code = 400;
                return $this->getResponseData($code, $request, $response,$error);
            }

            # format $data with escape string
            $array =$this->InsertFormaData($data,$this->connexion);
            # update $data
            $result = pg_update($this->connexion, $this->maintable , $array, ["idtype_de_financement" => "$id"], PGSQL_DML_EXEC);
            if ($result) {
                $q = pg_query($this->connexion, "SELECT * FROM $this->maintable WHERE idtype_de_financement ={$id}");
                # fetch result
                $res = pg_fetch_all($q);
                $res =$this->FormaData($res, $q,true);
                $code = 200;
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
            }

            return $this->getResponseData($code, $request, $response,$res);
        }


        /**
         * @url POST /typedefinancement
         * @url POST /typedefinancement/$data
         */
        public function AddTypeDeFinancement(Request $request,Response $response, $arg)
        {
            $code = (integer) null;
            $data = $request->getParam('data');
            $data = $this->getData($data);
            # if method PUT or POSt getValidateFields
            $error = $this->getValidateFields($this->maintable,$data);
            if($error){
                $code = 400;
                return $this->getResponseData($code, $request, $response,$error);
            }

            # format $data with escape string
            $array =$this->InsertFormaData($data,$this->connexion);

            # insert $data
            $result = pg_insert($this->connexion, $this->maintable , $array, PGSQL_DML_EXEC);
            if ($result) {
                $q = pg_query($this->connexion, "SELECT max(idtype_de_financement) as idtype_de_financement FROM $this->maintable");
                $actif = pg_fetch_all($q);
                $id = intval($actif[0]['idtype_de_financement']);
                # recherche de l'id
                $q = pg_query($this->connexion, "SELECT * FROM $this->maintable WHERE idtype_de_financement ={$id}");
                # fetch result
                $res = pg_fetch_all($q);
                $res =$this->FormaData($res, $q,true);
                $code = 200;
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
            }
            return $this->getResponseData($code, $request, $response,$res);
        }


        /**
         * @param $table
         * @return array
         */
        public function getValidateFields($table,$data) {
            $validfields = $this->ValidateField($table, $this->connexion);
            $res         = $this->verifyRequiredParams($data,$validfields);
            return $res;
        }


        /**
         * @url DELETE /typedefinancement/$id
         */
        public function DeleteTypeDeFinancement(Request $request,Response $response, $arg)
        {
            $code = (integer) null;
            $id = $arg['id'];
            # delete
            $res = pg_delete($this->connexion, $this->maintable , ["idtype_de_financement" => "$id"], PGSQL_DML_EXEC);
            if ($res) {
                # For booleans and numeric convert
                $res = ["message" => "L'Enregistrement a été éffacé", "Enregistrement supprimé ID :" => $id];
                $code = 200;
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
            }

            return $this->getResponseData($code, $request, $response,$res);

        }
    }
}
