<?php

/**
 * Created by PhpStorm.
 * User: dahan
 * Date: 10/09/2018
 * Time: 08:37
 */

namespace  App\Models {
    require __DIR__.'/../../../vendor/autoload.php';
    require_once __DIR__ . '/Tools.php';
    require_once __DIR__ . '/../../../batch/BatchIndice.php';

    use PDO;
    use DateTime;
    use Psr\Http\Message\ResponseInterface as Response;
    use Psr\Http\Message\ServerRequestInterface as Request;
    use Psr\Log\LoggerInterface;
    use App\Batch\BatchIndice;

    class GestionFin extends Tools
    {

        /**
         * @var $connexion
         */
        public $connexion;

        /**
        /**
         * @var \Psr\Log\LoggerInterface
         */
        private $logger;

        /**
         * @var \PDO
         */
        private $pdo;

        /**
         * @var $maintable
         */
        private $maintable;

        /**
         * @var tauxindices
         */
        public $tauxindices;

        /**
         * @var BatchIndice
         */
        public $batchindice;

        /**
         * @var array
         */
        public $tables_liees;

        /**
         * BatchGestionFin constructor.
         */
        public function __construct(LoggerInterface $logger, PDO $pdo, $table, $c)
        {
            parent::__construct($c, $logger);

            # connexion to php_pgsql
            $this->connecte();

            # name of the data table
            $this->maintable = $table;

            # log this access data
            $this->logger    = $logger;

            # if you need other tables
            $this->tables_liees = ["gestion_fin","locaux", "bail"];

            $this->batchindice = new BatchIndice();

            # recupere tous les indices
            foreach(["ICC","ILAT","ILC"] as $indice){
                $this->tauxindices[$indice] = $this->batchindice->getListIndice($indice,null);
            }

        }


        /**
         *  destruct a curently connexion
         * BatchGestionFin destruct.
         */
        public function __destruct()
        {
         //   pg_close($this->connexion);
        }


        /**
         * modifier la sequence des id automatique
         * @param null
         */
        public function setSequence($table)
        {
            $q = pg_query($this->connexion, "SELECT max(idgestion_fin) as idgestion_fin FROM $table");
            $actif = pg_fetch_all($q);
            $newmax = (intval($actif[0]['idgestion_fin'])+1);
            $this->RenumSequence($table,$newmax,$this->connexion);
        }

        /**
         * @param Request $request
         * @param Response $response
         * @param $arg
         * @return Response
         */
        public function getCumulGestionFin(Request $request,Response $response, $arg){
            $code                = (int) 0;
            $dscr_facial_acte    = (float) 0;
            $dscr_potentiel      = (float) 0;
            $dscr_actuel         = (float) 0;
            $loyer_actuel        = (float) 0;
            $frais_de_gestion    = (float) 0;
            $surface_totale      = (float) 0;
            $prix_revient        = (float) 0;
            $taux_capitalisation = (float) 0;
            $valeur_venal        = (float) 0;
            $loyer_actuel        = (float) 0;
            $complement_loyer    = (float) 0;
            $loyer_vacant        = (float) 0;
            $revenu_facial       = (float) 0;
            $valeur_locative     = (float) 0;
            $frais_gestion       = (float) 0;
            $charge_emprunt      = (float) 0;
            $CRD                 = (float) 0;
            $capital_rembourse_an= (float) 0;
            $dscr_actuel         = (float) 0;
            $dscr_facial         = (float) 0;
            $dscr_potentiel      = (float) 0;
            $paris               = (int) 0;
            $banlieue            = (int) 0;
            $province            = (int) 0;
            $surface_paris       = (int) 0;
            $surface_banlieue    = (int) 0;
            $surface_province    = (int) 0;
            $nombre_locaux       = (int) 0;
            $echeance            = (float) 0;
            $capital_restant     = (float) 0;
            $echeancier          = (array) null;
            $rapport             = (array) null;
            $portefeuille        = (array) null;
            # verification request
            $querie = $this->getUrlQuery($request, $this->tables_liees, $this->connexion);

            # activer le filtre VACANT
            if(strpos($querie,"VACANT") != false && strpos($querie,"VACANT") != 0){
                $vacant = true;
            }

            # query
            $query = "SELECT  G.idactifpatrimonial,sum(G.surface_totale) as surface_totale , sum(G.prix_revient_acquisition) as prix_revient_acquisition ,sum(G.valeur_venale) as valeur_venale, 
                                        sum(G.taux_capi) as taux_capi,sum( G.loyer_actuel) as loyer_actuel,sum(G.complement_loyer_attendu) as complement_loyer,sum(G.loyer_vacant) as loyer_vacant,
                                        sum(G.revenu_facial)as revenu_facial,sum(G.valeur_locative) as valeur_locative,sum(G.frais_gestion) as frais_gestion, sum(G.charge_emprunt) as charge_emprunt,
                                        sum(G.capital_restant_du) as CRD, sum(G.capitalrembouannee) as capital_rembourse_an
                                        
                             FROM gestion_fin as G ";

            $query = $query . "\r\n" . $querie;
            $query = $query . "\r\n" . "GROUP BY G.idactifpatrimonial";




            # test de la valitdité de la requete
            $result = pg_send_query($this->connexion, $query);
            $res1 = pg_get_result($this->connexion);
            $result_error = pg_result_error($res1);
            if (Empty($result_error)) {
                # query locaux idlocal = id
                $result = pg_query($this->connexion, $query);
                # fetch result
                $actif = pg_fetch_all($result);
                # For booleans and numeric convert
                $gestion_fin = $this->FormaData($actif, $result, false);
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete ligne 170 :" . __FUNCTION__ . " Detail de l'erreur :" . $state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1) . $result_error . ': ' . __FUNCTION__);
                return $this->getResponseData($code, $request, $response, ["returncode" => 500, "message" => "Erreur lors de l'execution de la requete :" . __FUNCTION__ . " Detail :" . $result_error, "code" => 500]);
            }


            foreach($gestion_fin as $key =>$value) {
                $frais_de_gestion   = $value["frais_gestion"];
                $loyer_actuel       = $value["loyer_actuel"];
                $idactifpatrimonial = $value["idactifpatrimonial"];


                $query = "SELECT I.idinvestissement,I.investissements,I.idactifpatrimonial
                                                      FROM investissements I
                                                      join actif_patrimonial A ON A.idactifpatrimonial = I.idactifpatrimonial
                                                      where I.idactifpatrimonial =$idactifpatrimonial";


                $q = pg_query($this->connexion, $query);

                # fetch result
                $invest = pg_fetch_all($q);

                if($invest) {
                    foreach ($invest as $key1 => $value1) {
                        $capital_restant = 0;
                        $echeance = 0;
                        # portefeuille
                        $array = $this->getData($value1["investissements"]);
                        $idamortissement = $array["emprunts"][0]["idamortissement"];
                        $query = "SELECT * from emprunt_amortissement                                                       
                          where idamortissement = $idamortissement";
                        $q = pg_query($this->connexion, $query);

                        # fetch result
                        $amortissement = pg_fetch_all($q);
                        $amortissement = $this->getData($amortissement[0]["amortissements"]);
                        $annee = intval(SETTING_YEAR_NOW);

                        foreach ($amortissement as $key2 => $amort) {
                            $anneeplus = intval($this->DatePeriode($amort["date_echeance"], "Y"));
                            if ($anneeplus !== $annee) {
                                $echeance = 0;
                                $capital_restant = 0;
                                $annee++;
                            }
                            $echeance = floatval($amort["montant_echeance"]);
                            if ($capital_restant == 0) {
                                $capital_restant = $echeancier[$annee]["capital_restant"] + floatval($amort["valeur_residuelle"]);
                            }


                            if ($anneeplus === $annee) {
                                if (isset($echeancier[$annee]["echeance"])) {
                                    $echeancier[$annee]["echeance"] = $echeancier[$annee]["echeance"] + $echeance;
                                } else {
                                    $echeancier[$annee]["echeance"] = $echeance;
                                }
                                if ($capital_restant !== 0) {
                                    $echeancier[$annee]["capital_restant"] = $capital_restant;
                                }


                            }


                        }

                    }
                    if (count($echeancier) < 15) {
                        $echeance = $echeancier[$annee]["echeance"];
                        $capital_restant = $echeancier[$annee]["capital_restant"];
                        $annee++;
                        for ($i = count($echeancier); $i <= 15; $i++) {
                            $echeancier[$annee]["echeance"] = $echeance;
                            $echeancier[$annee]["capital_restant"] = $capital_restant;
                            $annee++;
                        }
                    }
                }

                $query = "select ordre,surface ,nombre_locaux from (
                            SELECT  'paris' as ordre, count(*) as nombre_locaux ,  sum(L.surface_totale) as surface
                            from locaux L
                            join actif_patrimonial A ON A.idactifpatrimonial = L.idactifpatrimonial                                                       
                            where  A.idactifpatrimonial =$idactifpatrimonial and A.ordre =1
                            GROUP BY A.ordre
                            UNION            
                            SELECT   'banlieue' as ordre, count(*) as nombre_locaux  , sum(L.surface_totale) as surface
                            from locaux L
                            join actif_patrimonial A ON A.idactifpatrimonial = L.idactifpatrimonial                                                       
                            where  A.idactifpatrimonial =$idactifpatrimonial and A.ordre =2
                            GROUP BY A.ordre
                            UNION            
                            SELECT  'province' as ordre, count(*) as nombre_locaux  , sum(L.surface_totale) as surface
                            from locaux L
                            join actif_patrimonial A ON A.idactifpatrimonial = L.idactifpatrimonial                                                       
                            where  A.idactifpatrimonial =$idactifpatrimonial and A.ordre =3
                            GROUP BY A.ordre                        
                          ) as repartition";
                $result = pg_query($this->connexion, $query);

                # fetch result
                $locaux = pg_fetch_all($result);
                $locaux = $this->FormaData($locaux, $result, false);
                if($locaux){
                    for($i=0;$i<count($locaux);$i++){
                        if($locaux[$i]["ordre"] == "paris"){
                            $paris          = $paris + intval($locaux[$i]["nombre_locaux"]);
                            $surface_paris  = $surface_paris  + intval($locaux[$i]["surface"]);
                        }
                        if($locaux[$i]["ordre"] == "banlieue"){
                            $banlieue = $banlieue + intval($locaux[$i]["nombre_locaux"]);
                            $surface_banlieue  = $surface_banlieue  + intval($locaux[$i]["surface"]);
                        }
                        if($locaux[$i]["ordre"] == "province"){
                            $province = $province + intval($locaux[$i]["nombre_locaux"]);
                            $surface_province  = $surface_province  + intval($locaux[$i]["surface"]);
                        }
                    }
                }

                # verification
                if (!Empty($value["charge_emprunt"])) {
                    $dscr_facial_acte = round(($value["loyer_total"] / $value["charge_emprunt"]) * 100, 2);
                    $dscr_potentiel = round(($value["loyer_potentiel"] / $value["charge_emprunt"]) * 100, 2);
                    $dscr_actuel = round((($loyer_actuel + $frais_de_gestion) / $value["charge_emprunt"]) * 100, 2);
                } else {
                    $dscr_facial_acte = 0;
                    $dscr_potentiel = 0;
                    $dscr_actuel = 0;
                }
                if ($value["valeur_venale"] > 0 && $value["capital_restant_du"] > 0) {
                    $lvt = ($value["capital_restant_du"] / $value["valeur_venale"]) * 100;
                } else {
                    $lvt = 0;
                }

                if ($value["prix_revient_acquisition"] > 0 && $value["CRD"] > 0) {
                    $ltc = ($value["CRD"] / $value["prix_revient_acquisition"]) * 100;
                } else {
                    $ltc = 0;
                }
                if (is_nan($dscr_actuel) || is_infinite($dscr_actuel)) {
                    $dscr_actuel = 0;
                }
                if (is_nan($dscr_facial_acte) || is_infinite($dscr_facial_acte)) {
                    $dscr_facial_acte = 0;
                }
                if (is_nan($dscr_potentiel) || is_infinite($dscr_potentiel)) {
                    $dscr_potentiel = 0;
                }
                   $nombre_locaux           += round($nombre_locaux);
                   $surface_totale           += round(floatval($value["surface_totale"])) ;
                   $prix_revient             += round(floatval($value["prix_revient_acquisition"])) ;
                   $taux_capitalisation      += round(floatval($value["taux_capi"]));
                   $valeur_venal             += round(floatval($value["valeur_venale"]));
                   $loyer_actuel             += round(floatval($value["loyer_actuel"]));
                   $complement_loyer         += round(floatval($value["complement_loyer"]));
                   $loyer_vacant             += round(floatval($value["loyer_vacant"]));
                   $revenu_facial            += round(floatval($value["revenu_facial"]));
                   $valeur_locative          += round(floatval($value["valeur_locative"]));
                   $frais_gestion            += round(floatval($value["frais_gestion"]));
                   $charge_emprunt           += round(floatval($value["charge_emprunt"]));
                   $CRD                      += round(floatval($value["CRD"]));
                   $capital_rembourse_an     += round(floatval($value["capital_rembourse_an"]));
                   $dscr_actuel              += round($dscr_actuel);
                   $dscr_facial              += round($dscr_facial_acte);
                   $dscr_potentiel           += round($dscr_potentiel);

                }
    # nombre de locaux
    $nombre_locaux = $paris + $banlieue + $province;

    $rapport = ["nombre_locaux"            => $nombre_locaux,
                "paris"                    => $paris,
                "banlieue"                 => $banlieue,
                "province"                 => $province,
                "surface_paris"            => $surface_paris   ,
                "surface_banlieue"         => $surface_banlieue,
                "surface_province"         => $surface_province,
                "surface_totale"           => $surface_totale,
                "prix_revient"             => $prix_revient,
                "taux_capitalisation"      => $taux_capitalisation,
                "valeur_venale"             => $valeur_venal        ,
                "loyer_actuel"             => $loyer_actuel        ,
                "complement_loyer"         => $complement_loyer    ,
                "loyer_vacant"             => $loyer_vacant        ,
                "revenu_facial"            => $revenu_facial       ,
                "valeur_locative"          => $valeur_locative     ,
                "frais_gestion"            => $frais_gestion       ,
                "charge_emprunt"           => $charge_emprunt      ,
                "CRD"                      => $CRD                 ,
                "capital_rembourse_an"     => $capital_rembourse_an ,
                "dscr_actuel"              => $dscr_actuel         ,
                "dscr_facial"              => $dscr_facial         ,
                "dscr_potentiel"           => $dscr_potentiel      ,
                "ltv"                      => $lvt,
                "ltc"                      => $ltc,
                "echeancier"                => [$echeancier],
            ];


            $code=200;
            return $this->getResponseData($code, $request, $response, $rapport);
        }

        /**
         * @url GET /rapports/synthese/?type=globale
         */
        public function getGestionFinGlobale(Request $request,Response $response, $arg)
        {
            $code               = (integer) null;
            $query              = (string)null;
            $taux_indice        = (float) 0;
            $lvt                = (float) 0;
            $ltc                = (float) 0;
            $dscr_actuel        = (float) 0;
            $dscr_facial_acte   = (float) 0;
            $dscr_potentiel     = (float) 0;
            $rapport            = (array) null;
            $vacant             = (bool) false;
            $date_effet_bail    = (string) null;
            $indice_reference   = (string) null;
            $bail_en_cours      = (string) null;
            $tunnel_indexation  = (string) null;
            $frais_de_gestion   = (float) 0;
            $loyer_actuel       = (float) 0;
            $complement_loyer   = (float) 0;
            $valeur_locative    = (float) 0;
            $infosbail          = (array) null;
            $compteur           = (int)  0;
            $surfacevacant      = (int)  0;
            $idactif            = (int)  null;
            $surfaceactif       = (int)  0;
            $query              = (string) null;
            $result_error       = (string) null;
            $date_prochain_break = (string) null;


            try {

                # verification request
                $querie = $this->getUrlQuery($request, $this->tables_liees, $this->connexion);

                # activer le filtre VACANT
                if(strpos($querie,"VACANT") != false && strpos($querie,"VACANT") != 0){
                    $vacant = true;
                }

                # query
                $query = "SELECT distinct  G.idactifpatrimonial, G.adresse, G.code_postal, G.ville, G.date_acquisition, G.surface_totale, G.prix_revient_acquisition, 
                                        G.capital_restant_du, G.charge_emprunt, G.loyer_actuel, G.complement_loyer_attendu, G.loyer_total, G.loyer_actu_k_restant_du, 
                                        G.loyact_charemp, G.loyer_total_investisst_initial, G.loyer_potentiel, G.valeur_venale, G.taux_capi, G.p_m2, G.p_m2_loue, 
                                        G.date_echeance, G.idbanque, G.banque, G.montant_financement, G.image_1, G.duree_ans, G.commentaire, G.idsociete, G.societe, 
                                        G.charge_emprunt_tmp, G.capital_reste_du_tmp, G.ordre, G.duree_resid_credit, G.valeur_expertise, G.nom_expert, G.tauxfix, 
                                        G.tauxvariable, G.capitalrembouannee, G.montant_swap, G.montant_cap, G.strike_cap, G.duree_cap, G.taux_swap, G.duree_swap, 
                                        G.taux_cap, G.nom_portefeuille, G.marge_banque, G.loyer_vacant, G.idinvestissement, G.surface_vacante, G.indexation, G.prime_cap,
                                        G.tunnel_indexation,G.travaux,G.duree_initiale
                             FROM gestion_fin as G
                              left join locaux as L ON L.idactifpatrimonial = G.idactifpatrimonial 
                              left join bail as B ON B.idlocal = L.idlocal ";

                $query = $query . "\r\n" . $querie;

                $query = $query . "\r\n" . "ORDER BY G.ordre, G.code_postal";


                # test de la valitdité de la requete
                $result = pg_send_query($this->connexion, $query);
                $res1 = pg_get_result($this->connexion);
                $result_error = pg_result_error($res1);
                if (Empty($result_error)) {
                    # query locaux idlocal = id
                    $result = pg_query($this->connexion, $query);
                    # fetch result
                    $actif = pg_fetch_all($result);
                    # For booleans and numeric convert
                    $actif = $this->FormaData($actif, $result, false);
                } else {
                    $code = 500;
                    $state = pg_last_error();
                    // some error happened
                    $result_error = "erreur d'execution de la requete ligne 170 :" . __FUNCTION__ . " Detail de l'erreur :" . $state;
                    $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1) . $result_error . ': ' . __FUNCTION__);
                    return $this->getResponseData($code, $request, $response, ["returncode" => 500, "message" => "Erreur lors de l'execution de la requete :" . __FUNCTION__ . " Detail :" . $result_error, "code" => 500]);
                }
                foreach ($actif as $key => $value) {
                    $date_effet_bail = null;
                    $indice_reference = null;
                    $bail_en_cours = null;
                    $frais_de_gestion = 0;
                    $loyer_actuel = 0;
                    $surfacevacant = 0;
                    $complement_loyer = 0;
                    $surfaceactif = 0;
                    $tunnel_indexation=null;
                    $infosbail = null;
                    $idactif = $value["idactifpatrimonial"];
                    $query = "SELECT B.idbail, B.idlocal,L.surface_totale as surface_loue, L.nombre_parking_int as nombre_parking, L.etage,L.surface_etage,L.surface_rdc,L.surface_sous_sol, 
                                      CASE  WHEN L.surface_totale<>0 THEN  (B.loyer_actuel/L.surface_totale) 
                                            ELSE 0
                                      END as valeur_m2_an,
                                B.nom_du_locataire as nom_locataire,B.activite, B.type_de_bail as bail_en_cours, B.date_effet_du_bail as date_effet_bail,B.type_de_bail,
                                B.date_dentree_du_locataire as date_entree_locataire, B.date_fin_bail as date_fin_bail,B.indice_reference as indice_reference,tunnel_indexation,
                                B.loyer_actuel as loyer_fiscal, B.caution, B.frais_gestion as frais_de_gestion, B.charges_refacturees as charges_refacturees,B.complement_loyer,B.duree_preavis,
                                B.valeur_locative,B.affectation_commerce,B.affectation_reserve,B.affectation_bureau,B.affectation_stockage,B.affectation_res_sous_sol,B.depot_de_garantie,
                                B.affectation_comm_sous_sol,B.affectation_habitation,B.tunnel_indexation,B.cap_indexation,L.extraction,B.duree_bail,B.caution_bancaire,B.caution_societe,B.caution_perso,B.caution_garantie_premiere_demande,
                                B.caution_garantie_solvabilite
                              FROM bail as B
                              JOIN locaux as L ON L.idlocal = B.idlocal";


                    if ($vacant === true) {
                        $query = $query . "\r\n" . " WHERE L.idactifpatrimonial = $idactif AND B.bailactif = true ";
                        $query = $query . "\r\n" . " AND B.type_de_bail ='VACANT'";
                    } else {
                        $query = $query . "\r\n" . " WHERE L.idactifpatrimonial = $idactif AND B.bailactif = true ";
                    }
                    # query bail idlocal = idpatrimonial
                    $result = pg_query($this->connexion, $query);
                    if (!$result) {
                        $code = 500;
                        $state = pg_last_error();
                        $result_error = "erreur d'execution de la requete ligne 217 :" . __FUNCTION__ . " Detail de l'erreur :" . $state . "-->id :" . $idactif;
                        $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1) . $result_error . ': ' . __FUNCTION__);
                        return $this->getResponseData($code, $request, $response, ["returncode" => 500, "message" => "Erreur lors de l'execution de la requete :" . __FUNCTION__ . " Detail :" . $result_error, "code" => 500]);
                    }
                    # fetch result
                    $baux = pg_fetch_all($result);
                    # For booleans and numeric convert
                    $baux = $this->FormaData($baux, $result, false);
                    foreach ($baux as $key1 => $bail) {
                        $taux_indice = 0;
                        if ($bail["type_de_bail"] === "VACANT" || $vacant == true) {
                            $surfacevacant = $surfacevacant + intval($bail["surface_loue"]);
                        } else {
                            $surfaceactif = $surfaceactif + intval($bail["surface_loue"]);
                        }


                        if (Empty($bail["caution"])) {
                            $bail["caution"] = "Non";
                        }
                        $idbail                 = $bail["idbail"];
                        $date_effet_bail        = substr($bail["date_effet_bail"], 0, 10);
                        $indice_reference       = $bail["indice_reference"];
                        $bail_en_cours          = $bail["bail_en_cours"];
                        $frais_de_gestion       = $bail["frais_de_gestion"];
                        $valeur_locative        = $bail["valeur_locative"];
                        $complement_loyer       = $bail["complement_loyer"];
                        $loyer_actuel           = $bail["loyer_fiscal"];
                        $tunnel_indexation      = $bail["tunnel_indexation"];
                        $date_prochain_break    = null;
                        $indexation             = 0;
                        # indexation
                        if (!Empty($indice_reference) && !Empty($date_effet_bail)) {
                            $taux_indice = $this->getIndiceBail($indice_reference, $date_effet_bail, $bail_en_cours);
                            $date_prochain_break = $taux_indice["date_prochain_break"];
                            $indexation          = $taux_indice["indice"];
                        }

                        if (($loyer_actuel + $complement_loyer) != 0) {
                            $potentiel_reversion =  ($valeur_locative / ($loyer_actuel + $complement_loyer)) * 100;
                        } else {
                            $potentiel_reversion = 0;
                        }

                        if (is_nan($potentiel_reversion) || is_infinite($potentiel_reversion)) {
                            $potentiel_reversion = 0;
                        }

                        $infosbail[$key1] = [
                            "item_bail"             => $idbail,
                            "idlocal"               => $bail["idlocal"],
                            "surface_loue"          => round($bail["surface_loue"]),
                            "surface_etage"         => round($bail["surface_etage"]),
                            "surface_rdc"           => round($bail["surface_rdc"]),
                            "surface_sous_sol"      => round($bail["surface_sous_sol"]),
                            "nombre_parking"        => round($bail["nombre_parking"]),
                            "etage"                 => round($bail["etage"]),
                            "valeur_m2_an"          => round($bail["etage"], 2),
                            "nom_locataire"         => $bail["nom_locataire"],
                            "activite"              => $bail["activite"],
                            "bail_en_cours"         => $bail["bail_en_cours"],
                            "date_effet_bail"       => $this->DatePeriode($bail["date_effet_bail"], "j/m/Y"),
                            "date_entree_locataire" => $this->DatePeriode($bail["date_entree_locataire"], "j/m/Y"),
                            "date_fin_bail"         => $this->DatePeriode($bail["date_fin_bail"], "j/m/Y"),
                            "date_prochain_break"   =>$date_prochain_break,
                            "indice_reference"      => $bail["indice_reference"],
                            "loyer_fiscal"          => $bail["loyer_fiscal"],
                            "loyer_actuel"          => $loyer_actuel,
                            "caution"               => $bail["caution"],
                            "caution_bancaire"      => $bail["caution_bancaire"],
                            "caution_societe"       => $bail["caution_societe"],
                            "caution_perso"         => $bail["caution_perso"],
                            "caution_garantie_premiere_demande" => $bail["caution_garantie_premiere_demande"],
                            "caution_garantie_solvabilite" => $bail["caution_garantie_solvabilite"],
                            "indexation"            =>$indexation,
                            "duree_preavis"         =>$bail["duree_preavis"],
                            "potentiel_de_reversion"  => round($potentiel_reversion,2),                          # potentiel de reversion = (Valeur locative (vacants+occupés)/ revenu facial) *100
                            "depot_de_garantie"     => $bail["depot_de_garantie"],
                            "tunnel_indexation"     => $bail["tunnel_indexation"],
                            "frais_de_gestion"      => $bail["frais_de_gestion"],
                            "charges_refacturees"   => $bail["charges_refacturees"],
                            "complement_loyer"      => $complement_loyer,
                            "date_effective_depart" => $this->DatePeriode($bail["date_effective_depart"], "j/m/Y"),
                            "dernier_loyer"         => $loyer_actuel,
                            "extraction"            => $bail["extraction"],
                            "valeur_locative"       => $bail["valeur_locative"],
                            "affectation_commerce"  => $bail["affectation_commerce"],
                            "affectation_reserve"   => $bail["affectation_reserve"],
                            "affectation_bureau"    => $bail["affectation_bureau"],
                            "affectation_stockage"  => $bail["affectation_stockage"],
                            "affectation_res_sous_sol" => $bail["affectation_res_sous_sol"],
                            "affectation_comm_sous_sol" => $bail["affectation_comm_sous_sol"],
                            "affectation_habitation" => $bail["affectation_habitation"],
                            "duree_bail "           => $bail["duree_bail"],
                        ];
                    }



                    if ($value["valeur_venale"] > 0 && $value["capital_restant_du"] > 0) {
                        $lvt = ($value["capital_restant_du"] / $value["valeur_venale"]) * 100;
                    } else {
                        $lvt = 0;
                    }

                    if ($value["prix_revient_acquisition"] > 0 && $value["capital_restant_du"] > 0) {
                        $ltc = ($value["capital_restant_du"] / $value["prix_revient_acquisition"]) * 100;
                    } else {
                        $ltc = 0;
                    }


                    # verification
                    if (!Empty($value["charge_emprunt"])) {
                        $dscr_facial_acte = round(($value["loyer_total"] / $value["charge_emprunt"]) * 100, 2);
                        $dscr_potentiel = round(($value["loyer_potentiel"] / $value["charge_emprunt"]) * 100, 2);
                        $dscr_actuel = round((($loyer_actuel + $frais_de_gestion) / $value["charge_emprunt"]) * 100, 2);
                    } else {
                        $dscr_facial_acte = 0;
                        $dscr_potentiel = 0;
                        $dscr_actuel = 0;
                    }

                    if (is_nan($dscr_actuel) || is_infinite($dscr_actuel)) {
                        $dscr_actuel = 0;
                    }
                    if (is_nan($dscr_facial_acte) || is_infinite($dscr_facial_acte)) {
                        $dscr_facial_acte = 0;
                    }
                    if (is_nan($dscr_potentiel) || is_infinite($dscr_potentiel)) {
                        $dscr_potentiel = 0;
                    }


                    array_push($rapport,
                        [
                            "societe"                   => $value["societe"],                                               # nom de la societe
                            "idactifpatrimonial"        => $value["idactifpatrimonial"],                                    # idactifpatrimonial
                            "adresse"                   => utf8_decode($value["adresse"]),                                               # adresse
                            "code_postal"               => $value["code_postal"],                                           # code postale
                            "ville"                     => utf8_decode($value["ville"]),                                                 # ville
                            "surface"                   => $value["surface_totale"],                                        # surface totale de l'actif
                            "date_acquisition"          => $this->DatePeriode($value["date_acquisition"],"j/m/Y"),   # date_acquisition
                            "prix_de_revient"           => $value["prix_revient_acquisition"],                              # prix_revient_acquisition = prix de revient de l'actif
                            "banque"                    => $value["banque"],                                                # nom dee la banque
                            "portefeuille_financier"    => $value["nom_portefeuille"],                                      # portefeuille_financier = nom du portefeuille
                            "taux_variable"             => $value["tauxvariable"],                                          # taux_variable = taux euribor
                            "marge_taux_variable"       => round($value["marge_banque"],2),                        # marge_taux_variable =  marge banque
                            "charge_emprunt"            => round($value["charge_emprunt"],2),                      # charge d'emprunt = total montant des échéances de l'année
                            "capital_rembourse_an"      => round($value["capitalrembouannee"],2),                  # capital_rembourse_an = capital remboursé dans l'année
                            "crd"                       => round($value["capital_restant_du"],2),                  # CRD = capital restant du
                            "duree_residuelle_financement" => round($value["duree_resid_credit"]),                          # durée residuelle financement  = Durée en année + décimale
                            "montant_financement"       => $value["montant_financement"],
                            "duree_initiale"            => $value["duree_initiale"],
                            "notionnel_cap"             => round($value["montant_cap"],2),                         # notionnel cap = montant cap
                            "strike_cap"                => round($value["strike_cap"],2),                          # strike cap = poucentage du strike (plafond)
                            "duree_cap"                 => round($value["duree_cap"]),                                      # duree cap = durée en année
                            "notionnel_swap"            => round($value["montant_swap"],2),                        # notionnel_swap = montant swap
                            "duree_swap"                => round($value["duree_swap"],2),                          # durre swap = durée en année
                            "dscr_actuel"               => $dscr_actuel,                                                    # =dscr actuel = (( Loyer actuel annuel + frais gestion ) / charges d'emprunt *100
                            "dscr_facial"               => $dscr_facial_acte,                                               # dscr facial = revenu facial / charge emprunt ) *100
                            "dscr_potentiel"            => $dscr_potentiel,                                                 # dscr potentier = (revenus facial + valeur locative des vacants / charge emprunt ) *100
                            "ltv"                       => round($lvt,2),                                          # LTC = (capital restant du / valeur venale) *100
                            "ltc"                       => round($ltc,2),                                          # LVT =  (capital restant du / valeur venale) *100
                            "taux_capitalisation"       => round($value["taux_capi"],2),                           # taux capitalisation = (loyer annuel +frais de gestion) /valeur venale
                            "loyer_actuel"              => round($loyer_actuel,2),                                 # loyer actuel = loyer annuel
                            "indexation"                => round($indexation,2),                        # indexation taux d'indexation de l'indice des loyer suivant reference ICC, ILAT..
                            "tunnel_indexation"         => $tunnel_indexation,                                              # tunnel indexation =  champ tunnel indexation de bail
                            "revenu_facial"             => round($value["revenu_facial"]),
                            "loyer_facial_acte"         => round($value["loyer_total"],2),                         # loyer total loyer actuel +frais de gestion + complement
                            "loyer_vacant"              => round($value["loyer_vacant"],2),                        # loyer vacant ou libre = représente la valeur locative; que si le type de bail est vacant
                            "loyer_potentiel"           => round($value["loyer_potentiel"],2),                     # loyer potentiel = valeur locative + revenu facial
                            "complement_loyer"          => round($complement_loyer,2),                             # complement loyer = montant des réductions de loyer
                            "revenus_facial_CRD"        => round($value["loyer_actu_k_restant_du"],2),             # revenus facial CRD =  (revenus facial / CRD) *100
                            "revenus_facial_investissement"=> round($value["loyer_total_investisst_initial"],2),   # revenus facial de l'investissement = (revenus facial / investissement initial)*100
                            "nom_expert"                => $value["nom_expert"],                                            # nom de l'expert
                            "valeur_expertise"          => round($value["valeur_expertise"],2),                    # valeur après expertise
                            "valeur_venale"             => round($value["valeur_venale"],2),                        # valeur venale du bien : valeur venale de l'actif
                            "travaux"                   => $value["travaux"],                                               # travaux
                            "surface_actif"             => round($value["surface_totale"]),                                 # surface totale de l'actif : champ surface actif
                            "surface_vacante"           => round($value["surface_vacante"]),                                # surface vide ou vacante: si champ du bail VACANT surface
                            "commentaires"              => utf8_decode($value["commentaire"]),                                           # commentaire de l'actif: champ commentaires
                            "setorder"                  => $value["ordre"],                                                 # trie pour trier comme:  paris/banlieu/province
                            "info_bail"                 => $infosbail,                                                      # tableau infos du bail
                        ]
                    );
                }
                $code =200;
            $rapport = $this->utf8_encode($rapport);

            } catch (\HttpException $ex) {
                $code =500;
                $rapport = $ex;
                echo $ex;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1) . $ex . ': ' . __FUNCTION__);
            }

            return $this->getResponseData($code, $request, $response, $rapport);
        }

        /**
         * @param float|null $indice
         * @param string|null $dateeffetbail
         * @param string|null $typebail
         * @return int|mixed
         */
        public function getIndiceBail( $indice =null, $dateeffetbail = null, $typebail = null){

            $duree_bail         = (array)  null;
            $dateecheancebail   = (string) null;
            $tauxindice         = (array)  null;
            $annees             = explode("/",$typebail);

            switch ($typebail){
                case "3/6/9 ans"    : $duree_bail = [9,6,3];break;
                case "9/12 ans"     : $duree_bail = [12,3];break;
                case "Precaire"     : $duree_bail = null;break;
                case "VACANT"       : $duree_bail = null;break;
                case "4/6/9 ans"    : $duree_bail = [9,6,4];break;
                case "9ans fermes"  : $duree_bail = [9];break;
                case "5/6/9 ans"    : $duree_bail = [9,6,5];break;
                case "3/6/9/10 ans" : $duree_bail = [10,9,6,3];break;
                case "6/9 ans"      : $duree_bail = [9,6];break;
                case "Derogatoire " : $duree_bail = null;break;
                case "6/9/12 ans"   : $duree_bail = [12,6,3];break;
                case "12 ans fermes": $duree_bail = [12];break;
                case "3/6/9/12 ans" : $duree_bail = [12,9,6,3];break;
                default :
                    $durre_bail = null;break;
            }

            # pas de duree on return 0
            if(Empty($duree_bail)){
                //  return 0;
            }

            foreach($duree_bail as $duree){
                $dateecheancebail =$this->DatePlus($dateeffetbail,($duree*12),"Y-m-d");
                $dateecheancebail =  $this->DatePeriode($dateecheancebail,"Y-m-d");
                $dateproche = $this->DateVal(SETTING_DAY_NOW);
                # recherche indice  entre date
                foreach ($this->tauxindices[$indice] as $key => $value) {
                    $dateindice = $this->DatePeriode($value["date"], "Y-m-d");
                    $dateindice = $this->DateVal($dateindice);
                    if($dateproche>= $dateindice){
                         $tauxindice = ["indice" => $value["indice"],
                            "date_prochain_break" => $dateecheancebail,
                        ];
                    }
                    $dateproche = $dateindice;
                    if (!Empty($tauxindice)) {
                        break;
                    }
                }
            }

            # calcul de la date de break prochaine
            if (!Empty($duree_bail)) {
                asort($duree_bail);
                foreach($duree_bail as $duree) {
                    $dateecheancebail =$this->DatePlus($dateeffetbail,($duree*12),"Y-m-d");
                    $dateecheancebail =  $this->DatePeriode($dateecheancebail,"Y-m-d");
                    $dateproche = $this->DateVal($dateecheancebail);
                    $dateindice = $this->DateVal(SETTING_DAY_NOW);
                    if($dateproche>= $dateindice){
                        $tauxindice["date_prochain_break"] = $dateecheancebail;
                        break;
                    }
                }

            }
            # return l'indice
            return $tauxindice;
        }


        /**
         * @url GET /gestionfin/$id
         * @url GET /gestionfin=current
         */
        public function getGestionFin(Request $request,Response $response, $arg)
        {
            $code = (integer) null;
            $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);
            $table = $this->maintable != '' ? $this->maintable : $this->path;
            $id = $arg['id'];
            if ($id) {
                # query locaux idgestion_fin = id
                $q = pg_query($this->connexion, "SELECT * FROM $this->maintable WHERE idgestion_fin ={$id}");
                # fetch result
                $res = pg_fetch_all($q);
                if ($res) {
                    # For booleans and numeric convert
                    $res =$this->FormaData($res, $q, true);
                    $code = 200;
                } else {
                    $code = 500;
                    $state = pg_last_error();
                    // some error happened
                    $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                    $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                    return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
                }
            } else {
                $code = 400;
            }
            return $this->getResponseData($code, $request, $response,$res);
        }


        /**
         * @url PUT /gestionfin/$id
         * @url PUT /gestionfin/$id/$data
         */
        public function UpdateGestionFin(Request $request,Response $response, $arg)
        {
            $code = (integer) null;
            $id = $arg['id'];
            $data = $request->getParam('data');
            $data = $this->getData($data);
            # if method PUT or POSt getValidateFields
            $error = $this->getValidateFields($this->maintable,$data);
            if($error){
                $code = 400;
                return $this->getResponseData($code, $request, $response,$error);
            }

            # format $data with escape string
            $array =$this->InsertFormaData($data,$this->connexion);
            # update $data
            $result = pg_update($this->connexion, $this->maintable , $array, ["idgestion_fin" => "$id"], PGSQL_DML_EXEC);
            if ($result) {
                $q = pg_query($this->connexion, "SELECT * FROM $this->maintable WHERE idgestion_fin ={$id}");
                # fetch result
                $res = pg_fetch_all($q);
                $res =$this->FormaData($res, $q,true);
                $code = 200;
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
            }

            return $this->getResponseData($code, $request, $response,$res);
        }


        /**
         * @url POST /gestionfin
         * @url POST /gestionfin/$data
         */
        public function AddGestionFin(Request $request,Response $response, $arg)
        {
            $code                   = (integer) null;
            $data                   = $request->getParam('data');
            $type                   = (string) $request->getParam("type");
            $data                   = $this->getData($data);
            $invest                 = (array) array();
            $portefeuille           = (array) array();
            $amortissements         = (array) array();
            $gestion                = (array) array();
            $gestionfin             = (array) 0;
            $charge_emprunt         = (float) 0;
            $montant_financement    = (float) 0;
            $capital_remb           = (float) 0;
            $capital_restant_du     = (float) 0;
            $idactifpatrimonial     = (int) 0;
            $duree_initiale         = (int)0;

            # suppression de toute les lignes & remise a zero compteur de gestion_fin
            $result = $this->TruncateGestionFin();
            if ($result){
                # Création de toute les lignes de gestion_fin
                # 1- informer idactifpatrimonial avec l'adresse le code_postal, la ville, la date d'acquisition du bien, la surface totale le prix de revient acquisition. valeur_venale
                # informer idbanque et nom_banque, la societe idsociete et societe
                $gestionfin = $this->CreateLignesGestionFin();
            }


            # si aucun actif problème
            if(Empty($gestionfin)){
                $code = 500;
                $result_error = "erreur d'execution de la function :".__FUNCTION__." Detail de l'erreur : acun actifs n'a été ajouté da  nsd gestion_fin";
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
            }


            # 2- informer Capital_restant_du, charge_emprunt, taux_capi ?, montant_financement, duree_ans
            # charge_emprunt_tmp, capital_reste_du_tmp, ordre, duree_residuelle_credit, valeur_expertise, nom_expert, taux_fixe, taux_variable, capitalRembouAnnee
            # date_echeance (prochaine preise en compte des charges emprunts)
            $q = pg_query($this->connexion, "SELECT I.idinvestissement,I.investissements,I.nom_portefeuille,D.idemprunt
                                                      FROM investissements I
                                                      join donnees_emprunt D ON D.idinvestissement = I.idinvestissement");
            # fetch result
            $invest = pg_fetch_all($q);

            foreach ($invest as $key => $value) {
                # portefeuille
                $array = $this->getData($value["investissements"]);
                array_push($portefeuille, $array["emprunts"][0]);
                $portefeuille[$key]["idinvestissement"] = $value["idinvestissement"];
                $portefeuille[$key]["nom_portefeuille"] = $value["nom_portefeuille"];
                $portefeuille[$key]["actifs"]           = $this->getData($value["actifs"]);

            }
            if(count($portefeuille)>0){
                foreach ($portefeuille as $key => $value)
                {
                    $idemprunt                  = intval($value["idemprunt"]);
                    $gestion["tauxvariable"]    = null;
                    $gestion["tauxfix"]         = null;
                    $gestion["date_echeance"]   = null;
                    $prix_revient_acquisition   = null;
                    $capital_restant_du         = null;
                    $valeur_venal               = null;
                    $surface_total              = null;
                    $capital_remb               = 0;
                    $charge_emprunt             = 0;
                    $datedepart                 = null;
                    $datejour                   = null;
                    $idactifpatrimonial         = $value["idactifpatrimonial"];
                    $idamortissement            = $value["idamortissement"];
                    $duree_initiale             = $value["duree_financement"];
                    # calcul
                    foreach ($gestionfin as $key1=>$value1){
                        if($value1["idactifpatrimonial"] === $idactifpatrimonial){
                            $prix_revient_acquisition   = $value1["prix_revient_acquisition"];
                            $valeur_venal               = $value1["valeur_venale"];
                            $surface_total              = $value1["surface_totale"];
                            break;
                        }
                    }


                    # calcul des taux
                    switch ($value["type_emprunt"]){
                        case "taux_fixe" :
                            if($value["type_amortissement"] === "constant"){
                            }
                            if($value["type_amortissement"] === "progressif"){
                            }
                            $gestion["tauxfix"] = $value["taux"];
                            $gestion["tauxvariable"] = 0;
                            break;
                        case "taux_variable":
                            $gestion["tauxvariable"]        = $value["taux"];
                            $gestion["marge_banque"]        = $value["marge_banque"];
                            $gestion["taux_swap"]           = $value["taux_swap"];
                            $gestion["taux_prime_lisse"]    = $value["montant_prime_lisse"];    # erreur inversé dans l'UI
                            $gestion["prime_cap"]           = $value["prime_cap"];              # erreur inversé dans l'UI
                            $gestion["montant_swap"]        = $value["montant_swap"];
                            $gestion["montant_cap"]         = $value["montant_cap"];
                            $gestion["strike_cap"]          = $value["strike_cap"];
                            $gestion["duree_cap"]           = $value["duree_cap"];
                            $gestion["tauxfix"]             = 0;


                            break;
                    }

                    # amortissements
                    $q = pg_query($this->connexion, "SELECT E.amortissements
                                                      FROM emprunt_amortissement E
                                                      WHERE idamortissement= {$idamortissement}");
                    # fetch result
                    $amort = pg_fetch_all($q);
                    $array = $this->getData($amort[0]["amortissements"]);
                    $amortissements = $array;

                    # calcul des charges d'emprunt
                    foreach ($amortissements as $key2 => $value2){
                        $year = intval($this->DatePeriode($value2["date_echeance"],"Y"));

                        if($year === intval(SETTING_YEAR_NOW)){
                            # calcul capital rembourse
                            $capital_remb = $capital_remb  + floatval($value2["capital_rembourse"]);
                            # calcul des charges d'emprunt
                            $charge_emprunt = $charge_emprunt  + floatval($value2["montant_echeance"]);
                            # derniere date_echeance payee
                            $datedepart = $this->DateVal($value2["date_echeance"]);
                            $datejour   = $this->DateVal(SETTING_DAY_NOW);
                            if( $datedepart < $datejour){
                                # date derniere echeance payee
                                $gestion["date_echeance"]           = $value2["date_echeance"];
                                $gestion["capital_reste_du_tmp"]    = floatval($value2["valeur_residuelle"]);
                                $gestion["capital_restant_du"]      = floatval($value2["valeur_residuelle"]);
                                $capital_restant_du                 = floatval($value2["valeur_residuelle"]);
                            }
                        }elseif ($charge_emprunt != 0 && $year !== intval(SETTING_YEAR_NOW)){
                            break;
                        }
                    }

                    # on ne cumule pâs quand différent idemprunt
                    if(intval($value["idactifpatrimonial"]) !== $idactifpatrimonial){
                        $montant_financement        = floatval($value["montant_financement"]);
                    }else {
                        $montant_financement        = $montant_financement + floatval($value["montant_financement"]);
                    }



                    $gestion["montant_financement"]     = $montant_financement;
                    $gestion["idactifpatrimonial"]      = $value["idactifpatrimonial"];
                    $gestion["charge_emprunt"]          = $charge_emprunt;
                    $gestion["capitalrembouannee"]      = $capital_remb;
                    $gestion["marge_banque"]            = $value["marge_banque"];
                    $gestion["idinvestissement"]        = $value["idinvestissement"];
                    $gestion["nom_portefeuille"]        = $value["nom_portefeuille"];

                    switch ($value["frequence"]){
                        case "mensuelle"    :
                            $gestion["duree_ans"]     = ($value["duree_financement"]/12);break;
                        case "trimestrielle":
                            $gestion["duree_ans"]     = (($value["duree_financement"]*3)/12);break;
                        case "semestrielle" :
                            $gestion["duree_ans"]     = (($value["duree_financement"]*6)/12);break;
                        case "anuelle"      :
                            $gestion["duree_ans"]     = (($value["duree_financement"]*12));break;
                    }

                    $gestion["duree_resid_credit"]    = $this->DateInterval(SETTING_DAY_NOW,$value["date_derniere_echeance"],"d")/365;
                    $gestion["duree_initiale"]        = $duree_initiale;


                    # 5- informer les Loyers, complements loyer, taux_capi, DSR, p_m2, pm2_loue
                    $loyeractif = $this->setLoyersGestionFin($value["idactifpatrimonial"], $capital_restant_du, $charge_emprunt, $prix_revient_acquisition, $valeur_venal, $surface_total);
                    $gestion["loyer_actuel"]                    = $loyeractif["loyer_actuel"];                          # Loyer_actuel
                    $gestion["complement_loyer_attendu"]        = $loyeractif["complement_loyers_attendu"];             # Complement_loyer_Attendu
                    $gestion["loyer_total"]                     = $loyeractif["total_loyers"];                          # Loyer_total
                    $gestion["loyer_actu_k_restant_du"]         = $loyeractif["loyer_actuel_capital_Restant"];          # Loy_actu_K_restant_du
                    $gestion["loyact_charemp"]                  = $loyeractif["loyer_actuel_Charge_emprunt"];           # LoyAct_CharEmp
                    $gestion["loyer_total_investisst_initial"]  = $loyeractif["loyer_total_investis_initial"];          # Loyer_total__Investisst_initial
                    $gestion["taux_capi"]                       = $loyeractif["taux_capi"];                             # Taux_capi
                    $gestion["p_m2"]                            = $loyeractif["P_m2"];                                  # p_m2 Prix au m2
                    $gestion["surface_vacante"]                 = $loyeractif["surface_vacante"];                       # surface_vacante
                    $gestion["revenu_facial"]                   = $loyeractif["revenu_facial"];
                    $gestion["frais_gestion"]                   = $loyeractif["frais_gestion"];

                    if($surface_total>0) {
                        $gestion["p_m2_loue"]                   = ($loyeractif["Loyer_total"]/$surface_total);          # p_m2_loue Prix au m2 loue
                    }else{
                        $gestion["p_m2_loue"] =0;
                    }
                    # loyer potentiel
                    $gestion["loyer_potentiel"]                 = $loyeractif["loyer_vacant"] + $loyeractif["total_loyers"];
                    $gestion["loyer_vacant"]                    = $loyeractif["loyer_vacant"];

                    # format $data with escape string
                    $gestion =$this->InsertFormaData($gestion,$this->connexion);
                    # update $gestion_fin
                    $result = pg_update($this->connexion, gestion_fin , $gestion, ["idactifpatrimonial" => $gestion["idactifpatrimonial"]], PGSQL_DML_EXEC);
                    if(!$result){
                        $state =json_encode($gestion);
                        $result_error = "erreur d'execution de la requete Update Gestion_fin :".__FUNCTION__." Update id: ".$state;
                        $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                        return $result_error;
                    }
                    # sauvegarde de l'idactifpatrimonial
                    $idactifpatrimonial = intval($value["idactifpatrimonial"]);
                }

            }

            if (!$result)
            {
                $code = 500;
                $state =json_encode($gestion);
                // some error happened
                $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur : la requete Update id: ".$state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
            }
            return $this->getGestionFinGlobale($request, $response,$type);
        }


        /**
         * @param $table
         * @return array
         */
        public function getValidateFields($table,$data) {
            $validfields = $this->ValidateField($table, $this->connexion);
            $res         = $this->verifyRequiredParams($data,$validfields);
            return $res;
        }



        /**
         * @url DELETE /gestionfin/$id
         */
        public function DeleteGestionFin(Request $request,Response $response, $arg)
        {
            $code = (integer) null;
            $id = $arg['id'];
            # delete
            $res = pg_delete($this->connexion, $this->maintable , ["idgestion_fin" => "$id"], PGSQL_DML_EXEC);
            if ($res) {
                # For booleans and numeric convert
                $res = ["message" => "L'Enregistrement a été éffacé", "Enregistrement supprimé ID :" => $id];
                $code = 200;
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
            }

            return $this->getResponseData($code, $request, $response,$res);

        }

        /**
         * @function TruncateGestionFin
         * @return array|bool|resource
         */
        public function TruncateGestionFin()
        {

            # truncate
            $res = pg_query($this->connexion,"TRUNCATE gestion_fin RESTART IDENTITY" );
            if ($res) {
                # For booleans and numeric convert
                $res = ["message" => "Les enregistrements ont été éffacé"];
                $code = 200;

            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                return false;
            }

            return $res;

        }

        /**
         * @function CreateLignesGestionFin
         * @return int
         */
        public function CreateLignesGestionFin()
        {

            $idgestion_fin  = (int) 0;
            $gestion        = (array) null;
            $gestionfin     = (array) null;
            $compteur       = (int) 0;
            $result         = (bool) false;
            $q = pg_query($this->connexion, "SELECT entite as societe, * FROM actif_patrimonial ORDER BY idactifpatrimonial");
            $actif = pg_fetch_all($q);
            $actif =$this->FormaData($actif, $q,false);
            foreach($actif as $key => $value){
                if(!Empty($value["idsociete"])){
                    $gestion["societe"] = $this->getNomSociete($value["idsociete"]);
                }

                # traitement ordre pour le trie des enregistrements
                # banlieue
                if(intval($value["code_postal"]) >= 77000 & intval($value["code_postal"]) <= 78999){
                    $ordre     = 21;
                }else # paris
                    if(intval($value["code_postal"]) >= 75000 & intval($value["code_postal"]) <= 75022){
                        $ordre     = 1;
                    }else # banlieue
                        if(intval($value["code_postal"]) >= 91000 & intval($value["code_postal"]) <= 95999){
                            $ordre     = 2;
                        }else # province
                            if(intval($value["code_postal"]) >= 1 & intval($value["code_postal"]) <= 99999){
                                $ordre     = 3;
                            }

                $gestion["idactifpatrimonial"]       = $value["idactifpatrimonial"];
                $gestion["adresse"]                  = $value["adresse"];
                $gestion["code_postal"]              = $value["code_postal"];
                $gestion["ville"]                    = $value["ville"];
                $gestion["surface_totale"]           = $value["surface_totale_actif"];
                $gestion["date_acquisition"]         = $value["date_acquisition"];
                $gestion["prix_revient_acquisition"] = $value["prix_revient_dachat"];
                $gestion["montant_financement"]      = $value["montant_du_financement"];
                $gestion["nom_expert"]               = $value["nom_expert"];
                $gestion["valeur_expertise"]         = $value["valeur_expertise"];
                $gestion["capital_reste_du_tmp"]     = $value["capital_reste_du_tmp"];
                $gestion["charge_emprunt_tmp"]       = $value["charge_emprunt_tmp"];
                $gestion["commentaire"]              = $value["commentaire"];
                $gestion["valeur_venale"]             = $value["valeur_venale"];
                $gestion["ordre"]                    = $value["ordre"];
                $gestion["idsociete"]                = $value["idsociete"];
                $gestion["banque"]                   = $value["banque"];
                $gestion["idbanque"]                 = $value["idbanque"];
                $gestion["ordre"]                    = $ordre;


                # creation de l'id
                $idgestion_fin = $this->NewSequence( 'gestion_fin','idgestion_fin',$this->connexion);
                $gestion["idgestion_fin"]            = $idgestion_fin;
                $error = $this->getValidateFields(gestion_fin, $gestion);
                if(Empty($error) && $idgestion_fin > 0){
                    # insert des infos actifs
                    # format $tranches with escape string
                    $gestion = $this->InsertFormaData($gestion, $this->connexion);
                    $result = pg_insert($this->connexion, gestion_fin,$gestion,PGSQL_DML_EXEC);
                    # comptage
                    if($result){$compteur++;}
                }

            }
            # requete de controle, touys les actifs doivent être présent
            $q = pg_query($this->connexion, "select * from actif_patrimonial where idactifpatrimonial NOT IN(select idactifpatrimonial from gestion_fin)");
            $actif = pg_fetch_all($q);
            $actif =$this->FormaData($actif, $q,false);
            if(!Empty($actif)){
                $compteur =-1;
                $code = 500;
                $state = $actif[0]["idpatrimonial"]." de la table actifpatrimonial n'a pas été importé pour une raison inconnue";
                // some error happened
                $result_error = "erreur d'execution : ".__FUNCTION__." Detail de l'erreur :".$state;
                return $result_error;
            }else{
                $q = pg_query($this->connexion, "select idactifpatrimonial,prix_revient_acquisition,montant_financement,valeur_venale,surface_totale,capital_restant_du from gestion_fin");
                $gestionfin = pg_fetch_all($q);
                $gestionfin =$this->FormaData($gestionfin, $q,false);
            }

            return $gestionfin;

        }

        /**
         * @param $idactif
         * @param $capital_restant_du
         * @param $charge_emprunt
         * @param $prix_revient_acquisition
         * @param $valeur_venal
         * @param $surface_total
         * @return array
         */
        public function setLoyersGestionFin($idactif, $capital_restant_du, $charge_emprunt, $prix_revient_acquisition, $valeur_venal, $surface_total ) {
            $loyers                                     = (array) null;
            $loyeractif                                 = (array) null;
            $loyeractif["total_loyers"]                 = (float) 0;
            $loyeractif["loyers_actuel"]                = (float) 0;
            $loyeractif["loyers_annuel"]                = (float) 0;
            $loyeractif["loyer_vacant"]                 = (float) 0;
            $loyeractif["surface_vacante"]              = (int)   0;
            $loyeractif["tunnel_indexation"]            = (string)null;
            $loyeractif["cap_indexation"]               = (float) 0;
            $loyeractif["frais_gestion"]                = (float) 0;
            $loyeractif["complement_loyers_attendu"]    = (float) 0;
            $loyeractif["loyers_annuel_frais_gestion"]  = (float) 0;
            $loyeractif["total_annuel_frais_gestion"]   = (float) 0;
            $loyeractif["total_complement_loyers"]      = (float) 0;
            $loyeractif["loyer_actuel_capital_Restant"] = (float) 0;
            $loyeractif["loyer_actuel_Charge_emprunt"]  = (float) 0;
            $loyeractif["loyer_total_investis_initial"] = (float) 0;
            $loyeractif["P_m2"]                         = (float) 0;
            $loyeractif["taux_capi"]                    = (float) 0;
            $loyeractif["loyer_actuel_capital_Restant"] = (float) 0;
            $loyeractif["loyer_actuel_Charge_emprunt"]  = (float) 0;
            $loyeractif["revenu_facial"]                = (float) 0;





            # requete recherche dui nom de la societe
            $q = pg_query($this->connexion, "SELECT loyer_annuel,loyer_actuel, frais_gestion, complement_loyer, type_de_bail ,valeur_locative, L.surface_totale,B.tunnel_indexation,B.cap_indexation
                                                   FROM bail as B
                                                          join locaux as L ON L.idlocal = B.idlocal
                                                          join actif_patrimonial as A ON A.idactifpatrimonial = L.idactifpatrimonial
                                                    WHERE L.idactifpatrimonial = $idactif AND B.bailactif");
            $loyers = pg_fetch_all($q);
            $loyers =$this->FormaData($loyers, $q,false);
            if(!Empty($loyers)){
                foreach ($loyers as $key => $loyer){
                    if($loyer["type_de_bail"] === "VACANT"){
                        $loyeractif["loyer_vacant"]             += $loyer["valeur_locative"];
                        $loyeractif["surface_vacante"]          += $loyer["surface_totale"];
                    }else{
                        $loyeractif["loyer_vacant"]            += 0;
                        $loyeractif["surface_vacante"]         += 0;
                    }
                    $loyeractif["revenu_facial"]                += $loyer["loyer_annuel"]+ $loyer["complement_loyer"];
                    $loyeractif["loyer_actuel"]                 += $loyer["loyer_annuel"];
                    $loyeractif["loyers_annuel"]                += $loyer["loyer_annuel"];
                    $loyeractif["frais_gestion"]                += $loyer["frais_gestion"];
                    $loyeractif["complement_loyers_attendu"]    += $loyer["complement_loyer"];
                }
                $loyeractif["tunnel_indexation"]            = $loyer["tunnel_indexation"];
                $loyeractif["cap_indexation"]               = $loyer["cap_indexation"];
                $loyeractif["loyers_annuel_frais_gestion"]  = ($loyeractif["loyers_annuel"] * $loyer["frais_gestion"])/100 + $loyeractif["loyers_annuel"];
                $loyeractif["total_annuel_frais_gestion"]   = ($loyeractif["total_annuel_frais_gestion"] + $loyeractif["loyers_annuel_frais_gestion"]);
                $loyeractif["total_complement_loyers"]      = ($loyeractif["total_complement_loyers"] + $loyeractif["complement_loyers_attendu"]);
                # total loyer
                $loyeractif["total_loyers"] = $loyeractif["total_annuel_frais_gestion"] + $loyeractif["total_complement_loyers"];

                # loyer actuel capital restant du
                if ($loyeractif["total_annuel_frais_gestion"] > 0 && $capital_restant_du > 0) {
                    $loyeractif["loyer_actuel_capital_Restant"] = round(($loyeractif["total_annuel_frais_gestion"] / $capital_restant_du)*100,2);
                }

                #  DSCR actuel
                if($loyeractif["total_annuel_frais_gestion"] > 0 && $charge_emprunt > 0){
                    $loyeractif["loyer_actuel_Charge_emprunt"] = round(($loyeractif["total_annuel_frais_gestion"]/$charge_emprunt)*100,2);
                }

                if($prix_revient_acquisition >0){
                    $loyeractif["loyer_total_investis_initial"] = round(($loyeractif["total_annuel_frais_gestion"]/$prix_revient_acquisition)*100,2);
                }


                if($loyeractif["total_loyers"] > 0 && $valeur_venal > 0) {
                    $loyeractif["taux_capi"]  = round(($loyeractif["total_loyers"]/$valeur_venal)*100,2);
                }

                if($surface_total > 0){
                    $loyeractif["P_m2"]  = round($prix_revient_acquisition/$surface_total,0);
                }

            }

            return $loyeractif;
        }

        /**
         * @param Request $request
         * @param Response $response
         * @param $arg
         * @return Response
         */
        public function getCalculateur($data)
        {
            $code                   = (integer) null;
            $taux                   = (float)   $data["taux"]/100;
            $capital                = (float)   $data["capital"];
            $part_capital           = (float)   0;
            $echeance               = (float)   0;
            $duree_financement      = (int)     $data["duree_annee"]*12;
            $nbinterval             = (int)     3;
            $nbecheance             = (int)     $duree_financement / $nbinterval;
            $result                 = (array)   array();
            $emprunt                = (array)   array();


            for($i =1; $i <=4;$i++){
                # calcul échances, intérets
                $result = $this->CalculInterets($taux,$capital,$duree_financement, $nbinterval, $nbecheance);
                # pour les échéances un seul trimestre
                if(!isset($emprunt["trimestrialite"])){
                    $emprunt["trimestrialite"]   = round($result["echeance"],2);
                    $echeance    = round($result["echeance"],2);
                }
                # calcul part capital
                $part_capital = ($echeance-$result["interets"]);
                $emprunt["interets_annee"]      += round($result["interets"],2);
                $emprunt["capital_annee"]       += round($part_capital,2);
                # calcul capital restant
                $capital = $capital-$part_capital;

            }


            return  $result;

        }

        /**
         * @param $idactifpatrimonial
         * @return mixed
         */
        public function getValeurLocative($idactifpatrimonial){

            $querie = "SELECT SUM(B.valeur_locative) AS lsv FROM bail as B 
                        join locaux as L ON L.idlocal = B.idlocal
                        WHERE L.idactifpatrimonial  = $idactifpatrimonial  AND B.type_de_bail = 'VACANT'";
            $q = pg_query($this->connexion,$querie);
            $valeurlocative = pg_fetch_object($q);
            return $valeurlocative->lsv;
        }

        /**
         * @param societe
         */
        public function getGraphiqueTotalDSCR(Request $request,Response $response, $arg){
            $idsociete              = (int)   $arg["id"];
            $idamortissement        = (int)   null;
            $code                   = (int)   null;
            $amortissement          = (array) array();
            $graphique              = (array) array();
            $couverture             = (array) array();
            $couvertureok           = (bool) false;
            $actif                  = (array) array();
            $actifs                 = (array) array();
            $locatives              = (array) array();
            $dscr_actuel            = (float) 0;
            $dscr_facial            = (float) 0;
            $dscr_potentiel         = (float) 0;
            $loyeractuel            = (float) 0;
            $loyerattendu           = (float) 0;
            $loyertotal             = (float) 0;
            $valeurvenale           = (float) 0;
            $complementloyer        = (float) 0;
            $prixrevient            = (float) 0;
            $chargeemprunt          = (float) 0;
            $chargetotalemprunt     = (float) 0;
            $valeurvenaletotal      = (float) 0;
            $prixrevienttotal       = (float) 0;
            $loyeractueltotal       = (float) 0;
            $fraisgestiontotal      = (float) 0;
            $loyerpotentieltotal    = (float) 0;

            try {
                # verification request
                //$querie = $this->getUrlQuery($request, ["gestion_fin"], $this->connexion);
                $params = explode("&", str_replace("+", " ", $_SERVER['QUERY_STRING']));
                foreach ($params as $key => $value) {
                    $querie = explode("=", $value);
                    if ($querie[0] === "couverture") {
                        if ($querie[1] === "true") {
                            $couvertureok = true;
                        } else {
                            $couvertureok = false;
                        }

                    }

                }
                # requete amortissements
                $query = "SELECT A.idactifpatrimonial,investissements 
                        FROM actif_patrimonial as A
                        join investissements as I ON I.idactifpatrimonial = A.idactifpatrimonial
                        WHERE A.idsociete = {$idsociete} ";
                $q = pg_query($this->connexion, $query);
                $array = pg_fetch_all($q);
                $res =$this->FormaData($array, $q,false);

                foreach ($res as $keys => $data) {
                    $actifs = $this->getData($data["investissements"]);
                    $idactifpatrimonial = $actifs["emprunts"][0]["idactifpatrimonial"];
                    $idamortissement    =  $actifs["emprunts"][0]["idamortissement"];
                    $loyeractuel     =  0;
                    $loyerattendu    =  0;
                    $loyertotal      =  0;
                    $valeurvenale    =  0;
                    $complementloyer =  0;
                    $prixrevient     =  0;
                    $chargeemprunt   =  0;
                # requete amortissements
                $query = "SELECT A.amortissements,A.couverture,D.actifs 
                        FROM donnees_emprunt as D 
                        join emprunt_amortissement as A ON A.idemprunt = D.idemprunt
                        WHERE A.idamortissement = $idamortissement  ";
                $q = pg_query($this->connexion, $query);
                $array = pg_fetch_all($q);
                $amortissement = $this->getData($array[0]["amortissements"]);
                $actif = $this->getData($array[0]["actifs"]);
                $idactifpatrimonial = $actif[0]["idactifpatrimonial"];
                if ($couvertureok === true) {
                    $couverture = $this->getData($array[0]["couverture"]);
                } elseif ($couvertureok === false) {
                    $couverture = array();
                }


                # requete loyers
                $query = "SELECT sum(B.loyer_actuel) as loyer_actuel,sum(B.loyer_annuel) as loyer_annuel, sum(B.frais_gestion) as frais_gestion,A.prix_revient_dachat, 
                            sum(B.complement_loyer) as complement_loyer,sum( B.valeur_locative) as valeur_locative, A.valeur_venale 
                   FROM bail as B 
                         join locaux as L ON L.idlocal = B.idlocal
                          join actif_patrimonial as A ON A.idactifpatrimonial = L.idactifpatrimonial 
                       WHERE A.idactifpatrimonial=$idactifpatrimonial
                       GROUP BY valeur_venale,prix_revient_dachat ";

                $q = pg_query($this->connexion, $query);
                $locative = pg_fetch_object($q);
                $fraisgestion = floatval($locative->frais_gestion);
                $complementloyer = floatval($locative->complement_loyer);
                $valeurvenale = floatval($locative->valeur_venale);
                $prixrevient = floatval($locative->prix_revient_dachat);
                $valeurlocative = floatval($locative->valeur_locative);


                $locative = $this->loyerByAnne($idactifpatrimonial);

                if (Empty($locative)) {
                    $result = "cet actif n'a pas de données de local ou de bail";
                    $code = 400;
                    return $this->getResponseData($code, $request, $response, ["returncode" => $code, "message" => "Erreur lors de l'execution de la requete :" . __FUNCTION__ . " Detail : " . $result, "code" => 400]);
                }
                $annee = intval($this->DatePeriode($amortissement[0]["date_echeance"], "Y"));
                $anneeChart = $annee;
                $montantecheance = 0;
                $ltv = 0;
                $ltc = 0;
                $compteur = 0;
                # calcul des chargesemprunt
                foreach ($amortissement as $key => $amort) {
                    $annee = intval($this->DatePeriode($amort["date_echeance"], "Y"));
                    # prend seulement le capital du depuis début annee
                    if ($ltv == 0 && $ltc == 0) {
                        $ltv = floatval($amort["valeur_residuelle"]) + floatval($amort["capital_rembourse"]); #  valeur_residuelle emprunt = capital restant
                        $ltc = floatval($amort["valeur_residuelle"]) + floatval($amort["capital_rembourse"]); #  valeur_residuelle emprunt = capital restant
                    }


                    if (isset($locative[$annee])) {
                        $chargeemprunt = floatval($amort["montant_interets"]) + floatval($amort["capital_rembourse"]);
                        $locative[$annee]["chargesemprunt"] += $chargeemprunt;
                        $locative[$annee]["ltv"] = $ltv;
                        $locative[$annee]["ltc"] = $ltc;
                        if ($annee !== $anneeChart) {
                            $chargeemprunt = 0;
                            $ltv = 0;
                            $ltc = 0;
                        }
                    }
                    $anneeChart = intval($this->DatePeriode($amort["date_echeance"], "Y"));
                    $compteur++;
                }


                foreach ($locative as $key => $loc) {
                    $montantcouverture = 0;
                    if ($montantcouverture === 0) {
                        foreach ($couverture as $key1 => $couv) {
                            $pate_reception = floatval($couv["pate_reception"]);
                            $pate_payeuse = floatval($couv["pate_payeuse"]);
                            if (intval($this->DatePeriode($couv["date_echeance"], "Y")) === $key) {
                                $montantcouverture = $montantcouverture + ($pate_reception - $pate_payeuse);
                            }
                        }

                    }
                    if (isset($locative[$key]["chargesemprunt"])) {
                        $locative[$key]["chargesemprunt"] += $montantcouverture;
                        $chargeemprunt = $locative[$key]["chargesemprunt"];
                    } else {
                        $locative[$key]["chargesemprunt"] = $chargeemprunt;
                        $locative[$key]["ltv"] = $ltv;
                        $locative[$key]["ltc"] = $ltc;
                    }
                }

                    foreach ($locative as $key1 => $value1) {
                        if(!isset($locatives[$key1])) {
                            $locatives[$key1]   =    $locative[$key1];
                        }else{
                            $locatives[$key1]["loyers"]          += $locative[$key1]["loyers"];
                            $locatives[$key1]["chargesemprunt"]  += $locative[$key1]["chargesemprunt"];
                            $locatives[$key1]["ltv"]             += $locative[$key1]["ltv"];
                            $locatives[$key1]["ltc"]             += $locative[$key1]["ltc"];
                        }
                    }

                $valeurvenaletotal     += $valeurvenale;
                $prixrevienttotal      += $prixrevient;

                $compteur = 0;
                # calcul des dscr
                foreach ($locatives as $key => $value) {
                    $key_existe=null;
                    $loyeractuel            = $locatives[$key]["loyers"];
                    $loyerpotentiel         = ($loyeractuel + $complementloyer + $valeurlocative);
                    $chargetotalemprunt     = round($locatives[$key]["chargesemprunt"], 2);
                    $fraisgestiontotal      = $fraisgestion;
                    $loyerpotentieltotal    = $loyerpotentiel;
                    $dscr_actuel = round((($loyeractueltotal + $fraisgestiontotal) / $chargetotalemprunt) * 100, 4);
                    $dscr_facial = round((($loyeractueltotal) /$chargetotalemprunt) * 100, 4);
                    $dscr_potentiel = round((($loyerpotentieltotal) / $chargetotalemprunt) * 100, 4);
                    $loyeractueltotal       = $loyeractuel;

                    for($i=0;$i<count($graphique);$i++){
                        if($graphique[$i]["annee_emprunt"]===$key){
                           $key_existe=$i;
                           break;
                        }
                    }

                    if($key_existe ===null) {
                        array_push($graphique,
                            [
                                "annee_emprunt" => $key,
                                "charge_emprunt" => round($chargetotalemprunt, 2),
                                "dscr_actuel" => round($dscr_actuel, 2),
                                "dscr_facial_acte" => round($dscr_facial, 2),
                                "dscr_potentiel" => round($dscr_potentiel, 2),
                                "LTV" => round(($locatives[$key]["ltv"] / $valeurvenaletotal) * 100, 4),
                                "LTC" => round(($locatives[$key]["ltc"] / $prixrevienttotal) * 100, 4),
                            ]);
                    }else{
                        # on remplace les données
                        $graphique[$key_existe] =
                            [
                                "annee_emprunt" => $key,
                                "charge_emprunt" => round($chargetotalemprunt, 2),
                                "dscr_actuel" => round($dscr_actuel, 2),
                                "dscr_facial_acte" => round($dscr_facial, 2),
                                "dscr_potentiel" => round($dscr_potentiel, 2),
                                "LTV" => round(($locatives[$key]["ltv"] / $valeurvenaletotal) * 100, 4),
                                "LTC" => round(($locatives[$key]["ltc"] / $prixrevienttotal) * 100, 4),
                            ];
                    }

                }
            }


                $code = 200;
            }catch(\Exception  $e){
                $graphique= $e->getMessage();
            }
            return $this->getResponseData($code, $request, $response,$graphique);
        }



        /**
         * @param $idemprunt
         */
        public function getGraphiqueDSCR(Request $request,Response $response, $arg){
            $idamortissement = (int)   $arg["id"];
            $code            = (int)   null;
            $amortissement   = (array) array();
            $graphique       = (array) array();
            $couverture      = (array) array();
            $couvertureok    = (bool) false;
            $actif           = (array) array();
            $loyeractuel     = (float) 0;
            $loyerattendu    = (float) 0;
            $loyertotal      = (float) 0;
            $valeurvenale    = (float) 0;
            $complementloyer = (float) 0;
            $prixrevient     = (float) 0;
            $chargeemprunt   = (float) 0;

            try {
                # verification request
                //$querie = $this->getUrlQuery($request, ["gestion_fin"], $this->connexion);
                $params = explode("&", str_replace("+", " ", $_SERVER['QUERY_STRING']));
                foreach ($params as $key => $value) {
                    $querie = explode("=", $value);
                    if ($querie[0] === "couverture") {
                        if ($querie[1] === "true") {
                            $couvertureok = true;
                        } else {
                            $couvertureok = false;
                        }

                    }

                }
                if (Empty($idamortissement)) {
                    $code = 400;

                    return $this->getResponseData($code, $request, $response, ["returncode" => $code, "message" => "Erreur lors de l'execution de la requete :" . __FUNCTION__ . " Detail : idemprunt manquant", "code" => 404]);
                }

                # requete amortissements
                $query = "SELECT A.amortissements,A.couverture,D.actifs 
                        FROM donnees_emprunt as D 
                        join emprunt_amortissement as A ON A.idemprunt = D.idemprunt
                        WHERE A.idamortissement = $idamortissement  ";
                $q = pg_query($this->connexion, $query);
                $array = pg_fetch_all($q);
                $amortissement = $this->getData($array[0]["amortissements"]);
                $actif = $this->getData($array[0]["actifs"]);
                $idactifpatrimonial = $actif[0]["idactifpatrimonial"];
                if ($couvertureok === true) {
                    $couverture = $this->getData($array[0]["couverture"]);
                } elseif ($couvertureok === false) {
                    $couverture = array();
                }


                # requete loyers
                $query = "SELECT sum(B.loyer_actuel) as loyer_actuel,sum(B.loyer_annuel) as loyer_annuel, sum(B.frais_gestion) as frais_gestion,A.prix_revient_dachat, 
                            sum(B.complement_loyer) as complement_loyer,sum( B.valeur_locative) as valeur_locative, A.valeur_venale 
                   FROM bail as B 
                         join locaux as L ON L.idlocal = B.idlocal
                          join actif_patrimonial as A ON A.idactifpatrimonial = L.idactifpatrimonial 
                       WHERE A.idactifpatrimonial=$idactifpatrimonial
                       GROUP BY valeur_venale,prix_revient_dachat ";

                $q = pg_query($this->connexion, $query);
                $locative = pg_fetch_object($q);
                $fraisgestion = floatval($locative->frais_gestion);
                $complementloyer = floatval($locative->complement_loyer);
                $valeurvenale = floatval($locative->valeur_venale);
                $prixrevient = floatval($locative->prix_revient_dachat);
                $valeurlocative = floatval($locative->valeur_locative);


                $locative = $this->loyerByAnne($idactifpatrimonial);

                if(Empty($locative)){
                    $result = "cet actif n'a pas de données de local ou de bail";
                    $code = 400;
                    return $this->getResponseData($code, $request, $response, ["returncode" => $code, "message" => "Erreur lors de l'execution de la requete :" . __FUNCTION__ . " Detail : ".$result, "code" => 400]);
                }
                $annee = intval($this->DatePeriode($amortissement[0]["date_echeance"], "Y"));
                $anneeChart = $annee;
                $montantecheance = 0;
                $ltv = 0;
                $ltc = 0;
                $compteur = 0;
                # calcul des chargesemprunt
                foreach ($amortissement as $key => $amort) {
                    $annee = intval($this->DatePeriode($amort["date_echeance"], "Y"));
                    # prend seulement le capital du depuis début annee
                    if ($ltv == 0 && $ltc == 0) {
                        $ltv = floatval($amort["valeur_residuelle"]) + floatval($amort["capital_rembourse"]); #  valeur_residuelle emprunt = capital restant
                        $ltc = floatval($amort["valeur_residuelle"]) + floatval($amort["capital_rembourse"]); #  valeur_residuelle emprunt = capital restant
                    }


                    if (isset($locative[$annee])) {
                        $chargeemprunt = floatval($amort["montant_interets"]) + floatval($amort["capital_rembourse"]);
                        $locative[$annee]["chargesemprunt"]+= $chargeemprunt;
                        $locative[$annee]["ltv"] = $ltv;
                        $locative[$annee]["ltc"] = $ltc;
                        if ($annee !== $anneeChart) {
                            $chargeemprunt = 0;
                            $ltv = 0;
                            $ltc = 0;
                        }
                    }
                    $anneeChart = intval($this->DatePeriode($amort["date_echeance"], "Y"));
                    $compteur++;
                }


                foreach($locative as $key=>$loc){
                    $montantcouverture = 0;
                    if($montantcouverture === 0) {
                        foreach ($couverture as $key1 => $couv) {
                            $pate_reception = floatval($couv["pate_reception"]);
                            $pate_payeuse = floatval($couv["pate_payeuse"]);
                            if (intval($this->DatePeriode($couv["date_echeance"], "Y")) === $key) {
                                $montantcouverture = $montantcouverture + ($pate_reception - $pate_payeuse);
                            }
                        }

                    }
                        if(isset($locative[$key]["chargesemprunt"])){
                            $locative[$key]["chargesemprunt"] += $montantcouverture;
                            $chargeemprunt = $locative[$key]["chargesemprunt"];
                        }else {
                            $locative[$key]["chargesemprunt"] = $chargeemprunt;
                            $locative[$key]["ltv"] = $ltv;
                            $locative[$key]["ltc"] = $ltc;
                        }
                }


                $compteur =0;
                # calcul des dscr
                foreach ($locative as $key => $value) {
                        $loyeractuel = $locative[$key]["loyers"];
                        $loyerpotentiel = ($loyeractuel + $complementloyer + $valeurlocative);
                        $dscr_actuel = round((($loyeractuel + $fraisgestion) / $locative[$key]["chargesemprunt"]) * 100, 4);
                        $dscr_facial = round((($loyeractuel) / $locative[$key]["chargesemprunt"]) * 100, 4);
                        $dscr_potentiel = round((($loyerpotentiel) / $locative[$key]["chargesemprunt"]) * 100, 4);


                    array_push($graphique,
                        ["annee_emprunt" => $key,
                            "charge_emprunt" => round($locative[$key]["chargesemprunt"], 4),
                            "dscr_actuel" => round($dscr_actuel, 2),
                            "dscr_facial_acte" => round($dscr_facial, 2),
                            "dscr_potentiel" => round($dscr_potentiel, 2),
                            "LTV" => round(($locative[$key]["ltv"] / $valeurvenale) * 100, 4),
                            "LTC" => round(($locative[$key]["ltc"] / $prixrevient) * 100, 4),
                        ]
                    );

                }


                $code = 200;
            }catch(\Exception  $e){
                $graphique= $e->getMessage();
            }
            return $this->getResponseData($code, $request, $response,$graphique);
        }

        public function loyerByAnne(int $idactifpatrimonial = null){
            $dscr           =(array) null;
            $anne           = (int) 0;
            $coef           = (int) 0;
            $coefreserve    = (int) 0;
            $montantresa    = (array) null;
            # requete loyers
            $querie = "SELECT B.loyer_actuel, B.loyer_annuel, B.paliers, B.date_effet_du_bail 
                       FROM bail as B 
                          join locaux as L ON L.idlocal = B.idlocal
                       WHERE L.idactifpatrimonial=$idactifpatrimonial AND B.bailactif =true";

            $q          = pg_query($this->connexion,$querie);
            $locative   = pg_fetch_all($q);
            $locative           = $this->FormaData($locative, $q,true);
            $datedujour         = SETTING_DAY_NOW;

            if(Empty($locative)){
                return null;
            }

            $anne               = SETTING_YEAR_NOW;
            for($i=0; $i<15;$i++) {
                $loyeractuel        = floatval($locative["loyer_annuel"]);
                $loyerannuel        = floatval($locative["loyer_annuel"]);
                $paliers            = $this->getData($locative["paliers"]);
                $dateeffetdubail    = $locative["date_effet_du_bail"];

                # calcul des paliers
                foreach ($paliers as $key2 => $value2) {
                    $montantprorata = floatval($paliers[$key2]["montant"])/365;
                    $datedebut      = $paliers[$key2]["date_debut"];
                    $datefin        = $paliers[$key2]["date_fin"];
                    $anneedebut     = $this->DatePeriode($datedebut,"Y");
                    $anneefin        = $this->DatePeriode($datefin,"Y");
                    $datefinannee   = $anneedebut."-12-31";
                    if($this->DateVal($datefinannee)>= $this->DateVal($datefin)){
                        $coef       = $this->DateInterval($datedebut,$datefin,"d");
                    }else{
                        $coef        = $this->DateInterval($datedebut,$datefinannee,"d");
                        $coefreserve = $this->DateInterval($datefinannee,$datefin,"d");
                        $montantresa[$anneefin]= ["montant"=> ($montantprorata*$coefreserve)];
                    }
                    $montant =($montantprorata*$coef);

                    # sauvegarde du loyer actuel -> contractuel
                    if ($montant != 0 && !Empty($datedebut)) {
                        $datedeb = $this->DateVal($datedebut);
                        $dateend = $this->DateVal($datefin);
                        $datejour = $this->DateVal($datedujour);
                        if ($datejour >= $datedeb && $datejour <= $dateend) {
                            # application du palier
                            $loyeractuel = ($loyerannuel - $montant);
                        }
                    }
                    # montant reduction annee suivante
                    if(isset($montantresa[$anne])) {
                         $loyeractuel = $loyeractuel - $montantresa[$anne]["montant"];
                        $coefreserve = 0;
                        unset($montantresa[$anne]);
                    }

                }

                # report des reductions
                $dscr[$anne]        = ["loyers"=>$loyeractuel];
                $datedujour         = $this->DatePlus($datedujour,12,"Y-m-d");
                $anne++;
            }

            return $dscr;

        }


        public function getGraphiqueCRDBanque(Request $request,Response $response, $arg){
            $idsociete      = (int)   $arg["id"];
            $code           = (int)   null;
            $query          = (string) null;
            $querie         = (string) null;
            $filtre         = (string) null;
            $totalchiffre   = (object) null;
            $chiffresbanque = (array) array();
            $graphique      = (array) array();

            # verification request
            $querie = $this->getUrlQuery($request, ["gestion_fin"], $this->connexion);




            # requete amortissements
            $query = "SELECT sum(G.capital_restant_du) as crd FROM gestion_fin as G ";




            $query = $query. $querie;




            $q = pg_query($this->connexion,$query);

            $totalchiffre = pg_fetch_object($q);

            if(Empty($querie)){
                $querie = "WHERE Capital_restant_du > 0";
            }else{
                $querie = $querie . " AND Capital_restant_du > 0";
            }


            $query = "SELECT banque, SUM (G.capital_restant_du) AS CRD
                        FROM gestion_fin as G
                      $querie
                      GROUP BY G.banque
                      ORDER BY CRD DESC ";

            $q = pg_query($this->connexion,$query);
            $chiffresbanque = pg_fetch_all($q);
            $code =200;
            $banque = null;
            foreach ($chiffresbanque as $key => $value){
                foreach ($value as $key1=> $value1){
                    if($key1==="banque"){
                        $banque = strval($value1);
                        $graphique[$banque] = null;
                    }else{
                        $graphique[$banque] =floatval($value1);
                    }

                }

            }
            $graphique["Total_CRD"] =floatval($totalchiffre->crd);
            return $this->getResponseData($code, $request, $response,$graphique);
        }

        /**
         * @url liste files /rapports/excel
         */
        public function getListFilesExcel(Request $request,Response $response, $arg)
        {
            $code       = (integer) 200;
            $files      = 0;
            $filesXLS   = (array) null;
            $dossiers   = null;
            if($dossiers = opendir(PATRIMONIAL_PATH_EXPORT)) {
                while (false !== ($files = readdir($dossiers))) {
                    if ($files != '.' && $files != '..') {

                        $date =  date ("Y-m-d H:i", filemtime(PATRIMONIAL_PATH_EXPORT."/$files"));
                        $datetime = new \DateTime($date);
                        $dateiso = $datetime->format(DateTime::ISO8601);
                        array_push($filesXLS,["folder"=> PATRIMONIAL_PATH_EXPORT, "file" => $files,"creation_date" =>$dateiso]);
                    }
                }
            }


            return $this->getResponseData($code, $request, $response,$filesXLS);

        }

        /**
         * @param Request $request
         * @param Response $response
         * @param $args
         * @return Response
         */
        public function downloadFileExcel(Request $request,Response $response, $args)
        {
            # faire un select from societe
            # recupérer le codefichier
            $file                   = $args['file'];
            # le downloader avec cette procedure
            $file = PATRIMONIAL_PATH_EXPORT.'/'.$file;
            $fh = fopen($file, 'rb');

            $stream = new \Slim\Http\Stream($fh); // create a stream instance for the response body

            return $response->withHeader('Content-Type', 'application/force-download')
                ->withHeader('Content-Type', 'application/octet-stream')
                ->withHeader('Content-Type', 'application/download')
                ->withHeader('Content-Description', 'File Transfer')
                ->withHeader('Content-Transfer-Encoding', 'binary')
                ->withHeader('Content-Disposition', 'attachment; filename="' . basename($file) . '"')
                ->withHeader('Expires', '0')
                ->withHeader('Cache-Control', 'must-revalidate, post-check=0, pre-check=0')
                ->withHeader('Pragma', 'public')
                ->withBody($stream); // all stream contents will be sent to the response
        }


        /**
         * @param null $idsociete
         * @return null
         */
        public function getNomSociete($idsociete = null)
        {
            $code = (integer)null;
            $result = (bool) true;
            $result_error = (string)null;
            if ($idsociete) {
                # query locaux idemprunt = $id
                $query = "SELECT  nom_societe FROM societe  WHERE idsociete ={$idsociete}";

                # test de la rtequete
                $result = pg_send_query($this->connexion, $query);
                $res1 = pg_get_result($this->connexion);
                $result_error = pg_result_error($res1);
                if (Empty($result_error)) {
                    # query locaux idlocal = id
                    $result = pg_query($this->connexion, $query);
                    # fetch result
                    $res = pg_fetch_object($result);
                    return $res->nom_societe;
                } else {
                    return null;
                }
            }
        }

        /**
         * @return array|null
         */
        public function getCAByActivite(Request $request,Response $response, $arg)
        {

            $code = (integer)null;
            $result = (bool)true;
            $chiffres = (array)null;
            $caactivite = (array)null;

            $total = (float)0;

            $result_error = (string)null;

            # query locaux idemprunt = $id
            $query = "SELECT B.type_activite as activite, sum(B.loyer_actuel) as Loyer_total 
                      FROM bail as B
                      join locaux as L ON L.idlocal =B.idlocal
                      join actif_patrimonial as A ON A.idactifpatrimonial = L.idactifpatrimonial
                      GROUP BY type_activite
                      order by type_activite asc";

            # test de la rtequete
            $result = pg_send_query($this->connexion, $query);
            $res1 = pg_get_result($this->connexion);
            $result_error = pg_result_error($res1);
            if (Empty($result_error)) {
                # query locaux idlocal = id
                $result = pg_query($this->connexion, $query);
                # fetch result
                $chiffres = pg_fetch_all($result);

                foreach ($chiffres as $key => $value) {

                    array_push($caactivite,["activite"=>$value["activite"],"loyer_total"=>floatval($value["loyer_total"])]);

                }

                $code =200;
                return $this->getResponseData($code, $request, $response,$caactivite);
            } else {
                return $this->getResponseData(500, $request, $response,$result_error);
            }

        }

        /**
         * @param null $idsociete
         * @return null
         */
        public function getCAByRegion(Request $request,Response $response, $arg)
        {
            $code            = (integer)null;
            $result          = (bool) true;
            $chiffres        = (array) null;
            $caregion        = (array) null;
            $caparis         = (float) 0;
            $cabanlieue      = (float) 0;
            $caprovince      = (float) 0;
            $total           = (float) 0;

            $result_error = (string)null;

            # query locaux idemprunt = $id
            $query = "SELECT A.code_postal as code_postal, sum(B.loyer_actuel) as Loyer_total 
                      FROM bail as B
                      join locaux as L ON L.idlocal =B.idlocal
                      join actif_patrimonial as A ON A.idactifpatrimonial = L.idactifpatrimonial
                      GROUP BY code_postal,ville
                      order by code_postal";

            # test de la rtequete
            $result = pg_send_query($this->connexion, $query);
            $res1 = pg_get_result($this->connexion);
            $result_error = pg_result_error($res1);
            if (Empty($result_error)) {
                # query locaux idlocal = id
                $result = pg_query($this->connexion, $query);
                # fetch result
                $chiffres = pg_fetch_all($result);

                foreach($chiffres as $key =>$value){
                    # banlieue
                    if(intval($value["code_postal"]) >= 77000 & intval($value["code_postal"]) <= 78999){
                        $cabanlieue     = $cabanlieue +floatval($value["loyer_total"]);
                    }else if(intval($value["code_postal"]) >= 75000 & intval($value["code_postal"]) <= 75022){
                        $caparis        = $caparis +floatval($value["loyer_total"]);
                    }else if(intval($value["code_postal"]) >= 91000 & intval($value["code_postal"]) <= 95999){
                        $cabanlieue     = $cabanlieue +floatval($value["loyer_total"]);
                    }else if(intval($value["code_postal"]) >= 1 & intval($value["code_postal"]) <= 99999){
                        $caprovince     = $caprovince +floatval($value["loyer_total"]);
                    }

                    $total = $total + floatval($value["loyer_total"]);
                }

                $caregion = ["Paris" => $caparis, "Banlieue" =>$cabanlieue, "Province" => $caprovince, "Total"=>$total];

                $code =200;
                return $this->getResponseData($code, $request, $response,$caregion);
            } else {
                return $this->getResponseData(500, $request, $response,$result_error);
            }

        }


        /**
         * @param null $idsociete
         * @return null
         */
        public function getCAByArrondissements(Request $request,Response $response, $arg)
        {
            $code            = (integer)null;
            $result          = (bool) true;
            $caparis         = (array) null;
            $total           = (float) 0;
            $result_error    = (string)null;

            # query locaux idemprunt = $id
            $query = "SELECT A.code_postal as code_postal, sum(B.loyer_actuel) as Loyer_total 
                      FROM bail as B
                      join locaux as L ON L.idlocal =B.idlocal
                      join actif_patrimonial as A ON A.idactifpatrimonial = L.idactifpatrimonial
                      WHERE A.code_postal LIKE '75%'
                      GROUP BY code_postal
                      order by code_postal";

            # test de la rtequete
            $result = pg_send_query($this->connexion, $query);
            $res1 = pg_get_result($this->connexion);
            $result_error = pg_result_error($res1);
            if (Empty($result_error)) {
                # query locaux idlocal = id
                $result = pg_query($this->connexion, $query);
                # fetch result
                $chiffres = pg_fetch_all($result);

                foreach($chiffres as $key =>$value){
                    # banlieue
                    array_push( $caparis,["Arrondismment" => $value["code_postal"], "loyer_total" => floatval($value["loyer_total"])]);


                    $total = $total + floatval($value["loyer_total"]);
                }
                $code=200;
                array_push( $caparis,["Arrondismment" => "Total", "loyer_total" => $total]);
                return $this->getResponseData($code, $request, $response,$caparis);
            } else {
                return $this->getResponseData(500, $request, $response,$result_error);
            }

        }


    }
}
