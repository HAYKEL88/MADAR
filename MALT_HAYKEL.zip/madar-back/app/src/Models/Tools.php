<?php
/**
 * Copyright (c)  2018. L’ensemble du contenu (codes, textes, photographies, infographies, icônes, etc.) du site www.you-fleet.fr est la propriété exclusive de  sas ODEA, éditeur du site you-fleet.fr enregistrés à l'agence pour la protection des programmes sous le N°IDDN.FR.001.43005.000.R.P.2016.000.20100 Tous droits de reproduction ou de représentation de ceux-ci sont réservés.
 */



/**
 * Created by PhpStorm.
 * User: dahan
 * Date: 12/07/2018
 * Time: 09:36
 */

namespace App\Models;

require_once __DIR__ . '/JsonTools.php';

use \Datetime;
use \DateInterval;
use phpDocumentor\Reflection\Types\Parent_;
use Psr\Http\Message\RequestInterface;
use \Psr\Http\Message\ServerRequestInterface;
use \Psr\Http\Message\ResponseInterface;
use Psr\Log\LoggerInterface;

class Tools {

    # connexion
    public $connexion;

    public $toolstable;

    public static $container;

    /**
     * /**
     * @var \Psr\Log\LoggerInterface
     */
    private $logger;

    public function __construct($c,LoggerInterface $logger)
    {
        self::$container = $c;

        # Exception reporté à la fonction
        set_error_handler(array($this, 'exception_error_handler'));

        # log this access data
        $this->logger = $logger;
    }

    # les exceptions sont déportés par cette procédures
    public function exception_error_handler($c) {
        self::$container['errorHandler'] = function ($c) {
            return function (RequestInterface $request, ResponseInterface $response, $exception) use ($c) {
                return $c['response']->withStatus(500)
                    ->withHeader('Content-Type', 'text/html')
                    ->withJson('Something went wrong!');
                    //->write('Something went wrong!');
            };
        };
    }



    /**
     * @return object
     */
    public function connecte()
    {

        $this->connexion = \pg_connect('host=' . SETTING_HOST .
            ' port=' . SETTING_PORT .
            ' dbname=' . SETTING_DBNAME .
            ' user=' . SETTING_USER .
            ' password=' . SETTING_PSWD) or die('connection failed');

        return $this->connexion;

    }


    /**
     * @param $data
     * @param $conn
     * @return array
     */
    public function InsertFormaData($data, $conn)
    {
        $date = (string) null;
        if ($data) {
            foreach ($data as $key => $value) {
                $type = gettype($value);
                $dateok = false;
                $date = (string) null;
                if($type == "string" && strlen($value) >= 10) {
                    $date = substr($value,0,10);
                    $dateok = $this->validateDate($date,'Y-m-d');
                }


                if ($type == "string" && strlen($value) > 0) {
                    if ($value === null || $value === "''" || $value === '') {
                        $data[$key] = NULL;
                    } else {
                        $data[$key] = pg_escape_string($conn,$value);
                    }
                }

                if (is_bool($value)) {
                    if($value) {
                        $data[$key] = "t";
                    } else {
                        $data[$key] = "f";
                    }

                }

                # For Date convert to Datime:ISO01
                if ($dateok) {
                    $data[$key] = pg_escape_string($date);
                }

            }


        }

        return $data;

    }

    /**
     * @param $data
     * @param $conn
     * @return array
     */
    public function FormaData($data = array(), $conn = null, $reduce = false)
    {
        $array = array();
        if ($data) {
            foreach ($data as $value) {
                foreach ($value as $key2 => $value2) {
                    $type = pg_field_type($conn, pg_field_num($conn, $key2));

                    # For booleans, convert 't' and 'f' back to true and false.
                    if ($type == 'bool') {
                        $value[$key2] = ($value2 == 't');
                    }

                    # For numeric, convert '00.00000' back to 00.000000
                    if ($type == 'numeric' || $type == 'float4') {
                        $value[$key2] = (floatval($value2));
                    }

                    # For numeric, convert '10' back to 10
                    if ($type == 'int4' || $type == 'int2') {
                        $value[$key2] = (intval($value2));
                    }

                    # For Date convert to Datime:ISO01
                    if ($type == 'date' && $value2 !== null ) {
                        $value[$key2] = (self::DateISO8601($value2));
                    }
                }

                array_push($array, $value);

            }

            if($reduce){
                $array = $array[0];
            }
        }


        return $array;

    }


    /**
     * @param $dateparam
     * @return mixed Datime Format = "2011-07-05T00:00:00+0000"
     */
    public function DateISO8601($dateparam)
    {
        # objet DateTime from $dateparam
        $date = new DateTime($dateparam. ' 00:00:00');
        $dateiso = $date->format(DateTime::ISO8601);
        return $dateiso;

    }


    /**
     * @param $table
     * @param $conn
     * @return array|null
     */
    public function ValidateField($table, $conn){
        $q =  pg_query($conn, "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = '$table'");
        $result = pg_fetch_all($q);
        $data = array();
        foreach ($result as  $value) {
            foreach ($value as $key2 => $value2) {
                array_push($data, strtoupper(trim($value2)));
            }
        }
        return array_flip($data);
    }


    /**
     * @param $date
     * @param string $format
     * @return bool
     */
    public function validateDate($date, $format = 'Y-m-d H:i:s')
    {
        $d = DateTime::createFromFormat($format, $date);
        return $d && $d->format($format) == $date;
    }


    /**
     * @return string
     */
    public function generateApiKey(){
        return md5(uniqid(rand(), true));
    }


    /**
     * @param $table
     * @param $sequence
     * @param $conn
     */
    public function RenumSequence($table,$conn) {
        $seqname = (string) null;
        $querie =  "SELECT ns.nspname as schema, cl.relname as table, co.conname as 
                    cle_primaire, at.attname as colonne, seq.sequence_name as sequence
                    FROM
	                pg_constraint co
	                JOIN pg_class cl
		            ON cl.oid = co.conrelid AND co.contype = 'p'
	                JOIN pg_namespace ns
		                ON ns.oid = co.connamespace
	                JOIN pg_attribute at
		                ON at.attrelid = co.conrelid AND at.attnum = ANY( co.conkey )
	                JOIN information_schema.sequences seq
		                ON seq.sequence_name LIKE concat(cl.relname,'%')
		            WHERE cl.relname='$table' ";
        $q = pg_query($conn, $querie);
        $result = pg_fetch_object($q);

        # on recherche la dernier clef unique
        if(count($result)>0){
            $querie =  "SELECT (max(".$result->colonne.")+1) as max FROM $table ";
            $q = pg_query($conn, $querie);
            $sequence = pg_fetch_object($q);
            if(!Empty($sequence)){
                if($sequence->max ==null){
                    $sequence->max =1;
                }
            }
        }
        if (isset($result->sequence) && !Empty($result->sequence)){
            $seq = $result->sequence;
            $query = "ALTER SEQUENCE ".$seq." RESTART WITH ". $sequence->max;
            $q = pg_query($conn,$query);
            $seqname = $seq;
        }

        return $seqname;
    }


    /**
     * @param $table
     * @param $idname
     * @param $conn
     * @return int
     */
    public function NewSequence($table, $idname, $conn){
        $sequence = (int) null;
        $seqname = pg_escape_literal($conn,$this->RenumSequence($table,$conn));
        $q = pg_query($conn,"SELECT nextval ($seqname)");
        $res = pg_fetch_row($q);
        if($res){
            $sequence = intval($res[0]);
        }else{
            $result_error = pg_last_error();
            $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1) . $result_error . ': ' . __FUNCTION__);
            return false;
        }

        return $sequence;
    }

    /**
     * @return bool|mixed|string
     */
    public function getData($data)
    {
        $contents   = self::utf8_encode($data);
        //$contents   = $data;

        if (empty($contents)) {
            $contents = file_get_contents('php://input');
        }
        $json = str_replace("\\","/",$contents);
        $json = str_replace(array("\n","\r"),"",$json);
        $json = preg_replace('/([{,]+)(\s*)([^"]+?)\s*:/','$1"$3":',$json);
        $json = preg_replace('/(,)\s*}$/','}',$json);

     //   $res = json_decode($json, true);
        $res = JsonTools::decode($contents, TRUE);
        return $res;
    }


    /**
     * @param $data
     * @return bool|string
     */
    function removeBOM($data) {
        if (0 === strpos(bin2hex($data), 'efbbbf')) {
            return substr($data, 3);
        }
        return $data;
    }

    /**
     * @param $code
     * @param RequestInterface $request
     * @param ResponseInterface $response
     * @param $data
     * @return ResponseInterface
     */
    public function getResponseData($code,RequestInterface $request,ResponseInterface $response,$data ){
       $response = $response->withStatus($code)->write('before');
        //$response = $next($request, $response);
        $body = $response->getBody()->__toString();
        if ($code === 200) {
            $body = $response->withStatus(200)
                ->getBody($data);
            $response = $response->withJson(array('status' => 'success', 'data' => $data, 'message' => "For Table: ".$this->toolstable,"code"=> $code));
        }else {
            $body = $response->withStatus($code)
                ->getBody($data);
            $response = $response->withJson($data);
        }
        return $response;
    }


    /**
     * @param $required_fields
     * @param $request_params
     * @return array
     */
    public function verifyRequiredParams($required_fields,$request_params)
    {
        $error          = (bool) false;
        $code           = (integer) null;
        $error_fields   = (string) '';
        $returnresponse = (array) array();

        if ($_SERVER['REQUEST_METHOD'] == 'PUT' || $_SERVER['REQUEST_METHOD'] == 'POST') {
            # compare from data
            foreach ($required_fields as $key => $value) {
                $keyclean = strtoupper(trim($key));
                if (!array_key_exists($keyclean, $request_params)) {
                    $error = true;
                    $error_fields .= $keyclean . ', ';
                }
            }

            if ($error || Empty($required_fields)) {
                $code = 400;
                $returnmessage = 'Some Fields Are Empty, Required
   field(s) ' . strtolower(substr($error_fields, 0, -2)) . ' is missing or empty';
                $returnresponse['returncode'] = $code;
                $returnresponse['error-message'] = $returnmessage;
                $returnresponse['returndatacount'] = count($error_fields);
                return $returnresponse;
            }
        }

        return $returnresponse;
    }


    /*
    * fonction VPM, param :
      * $iTaux = taux de remboursement, taux périodique de l'emprunt. il est donné généralement annuellement, siles les remboursements
      * sont mensuels, il doit être divisé par 12.
      * $nbmois = nombre de remboursements, typiquement le nombre d'années multiplié par 12
      * $MontantFinance= valeur de départ, capital emprunté
      * $ValResiduelle = valeur après paiement des échéances,
      * $iType = échu ou à échoir
      * return = réel ou 0
   */
    public function VPM($iTaux,$nbmois,$MontantFinance,$ValResiduelle,$iType)
    {
        $iTaux          =   $iTaux/100;
        $iTaux          =   $iTaux/12;
        $iTaux1         =   1+$iTaux;
        $rTtxActu       =   pow($iTaux1 , -$nbmois);
        $ValResiduelle  =   -$ValResiduelle;

        if ($iType  >1 || $iType<0 ){ return 0;}

        if ((1-$rTtxActu)==0) {return 0;}

        $iVpm=  ( ($MontantFinance + $ValResiduelle * $rTtxActu) * $iTaux / (1 - $rTtxActu) ) / (1 + $iTaux * $iType);


        return $iVpm;

    }



    # return la date + interval en string
    public function DatePlus($date = null, $nbinterval =1,$format="Y-m-d"){
        # pas de date return null
        if($date === null) {return null;}
        # calcul de la date de fin
        $datefin  = new \DateTime($date);
        $datefin->add(new \DateInterval('P'.$nbinterval.'M'));
        return $datefin->format($format);
    }

    # return le mois ou l'annee en string
    public function DatePeriode($date = null,$format="m", $periode = "aucun"){
        $datevalide= (string) null;
        # pas de date return null
        if($date === null) {return null;}

        # calcul des periodes
        if($periode === "fin") {
            # calcul de la date de fin
            $dateparam = new \DateTime($date);
            $dayend = (int)mktime(0, 0, 0, ($dateparam->format("m") + 1), 0, $dateparam->format("y"));
            return date("Y-m-d",$dayend);
        } else if($periode === "debut") {
            # calcul de la date de fin
            $dateparam = new \DateTime($date);
            $dayfirst = (int)mktime(0, 0, 0, $dateparam->format("m"), 1, $dateparam->format("y"));
            return date("Y-m-d",$dayfirst);
        } else if($periode === "aucun") {
            # calcul de la date de fin
            $datevalide = new \DateTime($date);
        }

        # renvoi de la periode suivant le format
        return $datevalide->format($format);
    }

    public function DateInterval($datedebut = null,$datefin = null,$format = "d" ){
        $tz = new \DateTimeZone('Europe/Paris');
        # calcul de la date de fin du bail
        $datedebut  = new \DateTime($datedebut,$tz);
        $datefin  = new \DateTime($datefin,$tz);
        $interval = $datedebut->diff($datefin);
        switch($format){
            case "d" :  $diff =  $interval->days;break;     //format("%$format");
            case "m" :
                $diff = $interval->y;
                if($diff > 0){
                    $diff = $diff * 12; // annee
                }else{
                    $diff = $interval->format("m");
                }
                $diff = $diff + $interval->m;
                break;
            default :
                $diff = $interval->format("%$format");
        }

        # pour retour d'un nombre inf
        if($datefin < $datedebut){
            $diff = (-$diff);
        }

        # return nombre de mois et jours d'interval
        return $diff;
    }

    public function DateVal($date = null){
        $tz = new \DateTimeZone('Europe/Paris');
        $date = new \DateTime($date,$tz);
        // date inilisation
        $dateval = mktime($date->format("h"), $date->format("i"), $date->format("s"), $date->format("m")  , $date->format("d"), $date->format("Y"));

        return $dateval;
    }

    /*
    * fonction trimestre, param :
    * date  en nombre depuis Jesus-C
    * return = entier du n° de trimestre date param
    */
    public function TrimestreEnCours($date){
        $mois_base = date('n',$date);
        $trimestre=1;
        for($i=1 ; $i<=$mois_base; $i++ ){
            if(($i % 3)==0  ){
                $trimestre++;
            }

        }
        return $trimestre;
    }

    /**
     * @param $request
     * @param $tables
     * return = string
     */
    public function getUrlQuery($request,$tables,$conn){
        $data       =(array) null;
        $needle     = (string) null;

        if(!$data){
            //return null;
        }
        $query = (string) null;
        $tablesliason = $this->CheckLiason($tables,$conn);
        # path url delimiter
        $path = explode('/', $request->getUri()->getPath())[1];
        # tableau d'operateurs disponible
        $operateurs = ["=","=inf","=sup", "<", ">"];
        $key1 = 0;
        # tableau associatif de la query
        $data = $request->getParams();
        # tableau indicé de la query (afin d'obtenir le verbe complet de la query)
        $params = explode("&", str_replace("+"," ",$_SERVER['QUERY_STRING']));
        foreach ($data as $key => $value) {
            $key2 = 0;
            for($i=0;$i<count($params);$i++){
                foreach ($operateurs as $key1 =>$value2){
                    $pos = strpos($params[$i], $value2);
                    $pos2 = strpos($params[$i], $key);
                    if($pos2 !== false && $pos !== false ){
                        $key2= $key1;
                        $needle = $key;
                      if($key1 ===1){
                          # suppression de "inf"
                          $value = substr($value,3,strlen($value)-3);
                          $key2=3;
                          break;
                      }
                      if($key1 ===2){
                            $key2=4;
                            # suppression de "sup"
                            $value = substr($value,3,strlen($value)-3);
                            break;
                        }
                    }
                }
            }
            foreach($tablesliason as $key3 => $value3){
                $pos   = strpos($value3, $needle);
                if($pos !== false &&  substr($value3,2,strlen($value3)-2) === $needle){
                    $key = $value3;
                    break;
                }
            }
            if(!Empty($value)){
                if(Empty($query)){

                    $query = " WHERE ".$key. $operateurs[$key2] . pg_escape_literal($this->connexion,$value);

                }else{

                    $query = $query . " AND ".$key. $operateurs[$key2] . pg_escape_literal($this->connexion,$value);
                }

            }
        }
        return $query;
    }


    /**
     * @param $table
     * @param $conn
     * @return array|null
     */
    public function CheckLiason($table, $conn){
        if(is_array($table)){
            $filter = implode(",", $table);
            $filter = str_replace(",","','",$filter);
        }else{
            $filter = $table;
        }

        $q =  pg_query($conn, "SELECT COLUMN_NAME, TABLE_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME IN('$filter')");
        $result = pg_fetch_all($q);
        $data = array();
        foreach ($result as  $value) {
            foreach ($value as $key2 => $value2) {
                if($key2 === "column_name"){
                    $name = $value2;
                }
                if($key2 === "table_name"){
                    array_push($data, strtoupper(substr($value2,0,1)). "." .$name);
                }

            }
        }
        return $data;
    }

    /**
     * Usage: Tools::utf8_encode( $data );
     * @param mixed $d
     * @return mixed
     */
    public static function utf8_encode($d) {
        if (is_array($d)) {
            foreach ($d as $k => $v) {
                $d[$k] = self::utf8_encode($v);
            }
        } elseif (is_object($d)) {
            foreach ($d as $k => $v) {
                $d->$k = self::utf8_encode($v);
            }
        } elseif (is_scalar($d)) {
            $d = utf8_encode($d);
        }

        return $d;
    }

    public function getNomSociete($idsociete){
        $nom = (string) null;
        if(Empty($idsociete)){return null;}
        # requete recherche dui nom de la societe
        $q = pg_query($this->connexion, "select nom_societe from societe where idsociete= $idsociete ");
        $societe = pg_fetch_object($q);
        if(!Empty($societe)){
            $nom = $societe->nom_societe;
        }
        return $nom;

    }

    public function getNomBanque($idbanque){
        $nom = (string) null;
        if(Empty($idbanque)){return null;}
        # requete recherche dui nom de la societe
        $q = pg_query($this->connexion, "select nom_banque from banque where idbanque= $idbanque ");
        $banque = pg_fetch_object($q);
        if(!Empty($banque)){
            $nom = $banque->nom_banque;
        }
        return $nom;

    }

    /**
     * @return array
     */
    protected function info_about_ip () {
        //
        // cloudfare ip ranges
        //
        // https://www.cloudflare.com/ips-v4 28/2/2016
        // https://www.cloudflare.com/ips-v6 28/2/2016
        //
        if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            $cf_ip_ranges = array(
                '103.21.244.0/22',
                '103.22.200.0/22',
                '103.31.4.0/22',
                '104.16.0.0/12',
                '108.162.192.0/18',
                '131.0.72.0/22',
                '141.101.64.0/18',
                '162.158.0.0/15',
                '172.64.0.0/13',
                '173.245.48.0/20',
                '188.114.96.0/20',
                '190.93.240.0/20',
                '197.234.240.0/22',
                '198.41.128.0/17',
                '199.27.128.0/21',
                '2400:cb00::/32',
                '2405:8100::/32',
                '2405:b500::/32',
                '2606:4700::/32',
                '2803:f800::/32',
            );
            foreach ($cf_ip_ranges as $range) {
                if ($this->ipVersion($range) == 4) {
                    if ($this->ip_in_range($_SERVER['REMOTE_ADDR'], $range)) {
                        $_SERVER['REMOTE_ADDR'] = $_SERVER['HTTP_CF_CONNECTING_IP'];
                        break;
                    }
                } else {
                    if ($this->PMA_ipv6MaskTest($range,$_SERVER['REMOTE_ADDR'])) {
                        $_SERVER['REMOTE_ADDR'] = $_SERVER['HTTP_CF_CONNECTING_IP'];
                        break;
                    }
                }
            }
        }

        $array = array(
            "REMOTE_ADDR" => $_SERVER['REMOTE_ADDR']
        );

        return $array;
    }

}
