<?php return array (
  0 => 
  array (
    'GET' => 
    array (
      '/hello' => 'route0',
      '/uploads/' => 'route2',
      '/actifs/' => 'route3',
      '/activites/' => 'route9',
      '/amortissements/' => 'route14',
      '/baux/' => 'route19',
      '/banques/' => 'route27',
      '/categories/' => 'route32',
      '/coeffprogs/' => 'route37',
      '/emprunts/' => 'route42',
      '/emprunts/calculateur' => 'route43',
      '/rapports/synthese' => 'route49',
      '/rapports/regions' => 'route53',
      '/rapports/activites' => 'route54',
      '/rapports/arrondissements' => 'route55',
      '/rapports/total' => 'route56',
      '/rapports/crd' => 'route57',
      '/rapports/excel' => 'route58',
      '/etats/' => 'route63',
      '/euribors/' => 'route68',
      '/portefeuilles/' => 'route73',
      '/importationegides/' => 'route78',
      '/indices/' => 'route83',
      '/locaux/' => 'route84',
      '/notifications/' => 'route92',
      '/rendezvous/' => 'route97',
      '/societes/' => 'route102',
      '/typesbaux/' => 'route107',
      '/typefinancements/' => 'route112',
      '/users/' => 'route117',
      '/login/' => 'route123',
    ),
    'POST' => 
    array (
      '/uploads/base64' => 'route1',
      '/actifs/' => 'route6',
      '/activites/' => 'route11',
      '/amortissements/' => 'route16',
      '/baux/' => 'route24',
      '/banques/' => 'route29',
      '/categories/' => 'route34',
      '/coeffprogs/' => 'route39',
      '/emprunts/' => 'route46',
      '/rapports/' => 'route60',
      '/etats/' => 'route65',
      '/euribors/' => 'route70',
      '/portefeuilles/' => 'route75',
      '/importationegides/' => 'route80',
      '/locaux/' => 'route89',
      '/notifications/' => 'route94',
      '/rendezvous/' => 'route99',
      '/societes/' => 'route104',
      '/typesbaux/' => 'route109',
      '/typefinancements/' => 'route114',
      '/users/' => 'route119',
      '/login/' => 'route122',
      '/logout/' => 'route124',
    ),
  ),
  1 => 
  array (
    'GET' => 
    array (
      0 => 
      array (
        'regex' => '~^(?|/actifs/([0-9]+)|/actifs/portefeuilles/([0-9]+)()|/activites/([0-9]+)()()|/amortissements/([0-9]+)()()()|/baux/([0-9]+)()()()()|/baux/locaux/([0-9]+)()()()()()|/baux/bailactif/([^/]+)()()()()()()|/baux/([^/]+)/bailactif/([^/]+)()()()()()()|/banques/([0-9]+)()()()()()()()()|/categories/([0-9]+)()()()()()()()()()|/coeffprogs/([0-9]+)()()()()()()()()()())$~',
        'routeMap' => 
        array (
          2 => 
          array (
            0 => 'route4',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          3 => 
          array (
            0 => 'route5',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          4 => 
          array (
            0 => 'route10',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          5 => 
          array (
            0 => 'route15',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          6 => 
          array (
            0 => 'route20',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          7 => 
          array (
            0 => 'route21',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          8 => 
          array (
            0 => 'route22',
            1 => 
            array (
              'bool' => 'bool',
            ),
          ),
          9 => 
          array (
            0 => 'route23',
            1 => 
            array (
              'id' => 'id',
              'bool' => 'bool',
            ),
          ),
          10 => 
          array (
            0 => 'route28',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          11 => 
          array (
            0 => 'route33',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          12 => 
          array (
            0 => 'route38',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
        ),
      ),
      1 => 
      array (
        'regex' => '~^(?|/emprunts/([0-9]+)|/emprunts/portefeuilles/([0-9]+)()|/rapports/synthese/([0-9]+)()()|/rapports/dscr/([0-9]+)()()()|/rapports/totaldscr/([0-9]+)()()()()|/rapports/excel/([^/]+)()()()()()|/etats/([0-9]+)()()()()()()|/euribors/([0-9]+)()()()()()()()|/portefeuilles/([0-9]+)()()()()()()()()|/importationegides/([0-9]+)()()()()()()()()()|/locaux/([0-9]+)()()()()()()()()()())$~',
        'routeMap' => 
        array (
          2 => 
          array (
            0 => 'route44',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          3 => 
          array (
            0 => 'route45',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          4 => 
          array (
            0 => 'route50',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          5 => 
          array (
            0 => 'route51',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          6 => 
          array (
            0 => 'route52',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          7 => 
          array (
            0 => 'route59',
            1 => 
            array (
              'file' => 'file',
            ),
          ),
          8 => 
          array (
            0 => 'route64',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          9 => 
          array (
            0 => 'route69',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          10 => 
          array (
            0 => 'route74',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          11 => 
          array (
            0 => 'route79',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          12 => 
          array (
            0 => 'route85',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
        ),
      ),
      2 => 
      array (
        'regex' => '~^(?|/locaux/actifs/([0-9]+)|/locaux/bailactif/([^/]+)()|/locaux/([0-9]+)/bailactif/([^/]+)()|/notifications/([0-9]+)()()()|/rendezvous/([0-9]+)()()()()|/societes/([0-9]+)()()()()()|/typesbaux/([0-9]+)()()()()()()|/typefinancements/([0-9]+)()()()()()()()|/users/([0-9]+)()()()()()()()())$~',
        'routeMap' => 
        array (
          2 => 
          array (
            0 => 'route86',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          3 => 
          array (
            0 => 'route87',
            1 => 
            array (
              'bool' => 'bool',
            ),
          ),
          4 => 
          array (
            0 => 'route88',
            1 => 
            array (
              'id' => 'id',
              'bool' => 'bool',
            ),
          ),
          5 => 
          array (
            0 => 'route93',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          6 => 
          array (
            0 => 'route98',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          7 => 
          array (
            0 => 'route103',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          8 => 
          array (
            0 => 'route108',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          9 => 
          array (
            0 => 'route113',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          10 => 
          array (
            0 => 'route118',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
        ),
      ),
    ),
    'PUT' => 
    array (
      0 => 
      array (
        'regex' => '~^(?|/actifs/([0-9]+)|/activites/([0-9]+)()|/amortissements/([0-9]+)()()|/baux/([0-9]+)()()()|/banques/([0-9]+)()()()()|/categories/([0-9]+)()()()()()|/coeffprogs/([0-9]+)()()()()()()|/emprunts/([0-9]+)()()()()()()()|/rapports/([0-9]+)()()()()()()()()|/etats/([0-9]+)()()()()()()()()())$~',
        'routeMap' => 
        array (
          2 => 
          array (
            0 => 'route7',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          3 => 
          array (
            0 => 'route12',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          4 => 
          array (
            0 => 'route17',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          5 => 
          array (
            0 => 'route25',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          6 => 
          array (
            0 => 'route30',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          7 => 
          array (
            0 => 'route35',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          8 => 
          array (
            0 => 'route40',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          9 => 
          array (
            0 => 'route47',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          10 => 
          array (
            0 => 'route61',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          11 => 
          array (
            0 => 'route66',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
        ),
      ),
      1 => 
      array (
        'regex' => '~^(?|/euribors/([0-9]+)|/portefeuilles/([0-9]+)()|/importationegides/([0-9]+)()()|/locaux/([0-9]+)()()()|/notifications/([0-9]+)()()()()|/rendezvous/([0-9]+)()()()()()|/societes/([0-9]+)()()()()()()|/typesbaux/([0-9]+)()()()()()()()|/typefinancements/([0-9]+)()()()()()()()()|/users/([0-9]+)()()()()()()()()())$~',
        'routeMap' => 
        array (
          2 => 
          array (
            0 => 'route71',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          3 => 
          array (
            0 => 'route76',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          4 => 
          array (
            0 => 'route81',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          5 => 
          array (
            0 => 'route90',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          6 => 
          array (
            0 => 'route95',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          7 => 
          array (
            0 => 'route100',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          8 => 
          array (
            0 => 'route105',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          9 => 
          array (
            0 => 'route110',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          10 => 
          array (
            0 => 'route115',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          11 => 
          array (
            0 => 'route120',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
        ),
      ),
    ),
    'DELETE' => 
    array (
      0 => 
      array (
        'regex' => '~^(?|/actifs/([^/]+)|/activites/([^/]+)()|/amortissements/([^/]+)()()|/baux/([^/]+)()()()|/banques/([^/]+)()()()()|/categories/([^/]+)()()()()()|/coeffprogs/([^/]+)()()()()()()|/emprunts/([^/]+)()()()()()()()|/rapports/([^/]+)()()()()()()()()|/etats/([^/]+)()()()()()()()()())$~',
        'routeMap' => 
        array (
          2 => 
          array (
            0 => 'route8',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          3 => 
          array (
            0 => 'route13',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          4 => 
          array (
            0 => 'route18',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          5 => 
          array (
            0 => 'route26',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          6 => 
          array (
            0 => 'route31',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          7 => 
          array (
            0 => 'route36',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          8 => 
          array (
            0 => 'route41',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          9 => 
          array (
            0 => 'route48',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          10 => 
          array (
            0 => 'route62',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          11 => 
          array (
            0 => 'route67',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
        ),
      ),
      1 => 
      array (
        'regex' => '~^(?|/euribors/([^/]+)|/portefeuilles/([^/]+)()|/importationegides/([^/]+)()()|/locaux/([^/]+)()()()|/notifications/([0-9]+)()()()()|/rendezvous/([^/]+)()()()()()|/societes/([^/]+)()()()()()()|/typesbaux/([^/]+)()()()()()()()|/typefinancements/([^/]+)()()()()()()()()|/users/([^/]+)()()()()()()()()())$~',
        'routeMap' => 
        array (
          2 => 
          array (
            0 => 'route72',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          3 => 
          array (
            0 => 'route77',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          4 => 
          array (
            0 => 'route82',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          5 => 
          array (
            0 => 'route91',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          6 => 
          array (
            0 => 'route96',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          7 => 
          array (
            0 => 'route101',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          8 => 
          array (
            0 => 'route106',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          9 => 
          array (
            0 => 'route111',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          10 => 
          array (
            0 => 'route116',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          11 => 
          array (
            0 => 'route121',
            1 => 
            array (
              'id' => 'id',
            ),
          ),
        ),
      ),
    ),
  ),
);