<?php
/**
 * Copyright (c)  2018. L’ensemble du contenu (codes, textes, photographies, infographies, icônes, etc.) du site www.you-fleet.fr est la propriété exclusive de  sas ODEA, éditeur du site you-fleet.fr enregistrés à l'agence pour la protection des programmes sous le N°IDDN.FR.001.43005.000.R.P.2016.000.20100 Tous droits de reproduction ou de représentation de ceux-ci sont réservés.
 */

/**
 * Created by PhpStorm.
 * User: dahan
 * Date: 08/07/2018
 * Time: 10:32
 */



# include path global
set_include_path(SITE_PATH.PATH_SEPARATOR.
                                SITE_PATH.'/app'.PATH_SEPARATOR.
                                SITE_PATH.'/files'.PATH_SEPARATOR.
                                SITE_PATH.'/files/export'.PATH_SEPARATOR.
                                SITE_PATH.'/files/pictures'.PATH_SEPARATOR.
                                SITE_PATH.'/files/import'.PATH_SEPARATOR.
                                SITE_PATH.'/uploads'.PATH_SEPARATOR.
                                SITE_PATH.'/log');

return [
    'settings' => [
        // Slim Settings
        'determineRouteBeforeAppMiddleware' => true,
        'addContentLengthHeader' => false,
        'displayErrorDetails' => true,
        'PoweredBy' => 'Powered by Odea ',
        'debug' => false,
        'routerCacheFile' => __DIR__.'/cache/cache.php',


        // database settings
        'pdo' => [
            'dsn' =>'pgsql:host='.SETTING_HOST.';port='.SETTING_PORT.';user='.SETTING_USER.';password='.SETTING_PSWD.';dbname=server_access',
            'username' => SETTING_USER,
            'password' => SETTING_PSWD,
        ],

        'server_acces_limiter'=>[
            'access_token'  => 'api_key',
            'time_limiter'  => '01:00:00',
            'password'      => 'password',
            'login_user'    => 'login_user',
        ],

        // api rate limiter settings
        'api_rate_limiter' => [
            'requests' => '10000',
            'inmins' => '60',
            'access_token' => '12e7665ce8ab498dc6abd1047bb35662',
        ],
        // Renderer settings
        'renderer' => [
            'template_path' => __DIR__ . '/../templates/',
        ],
        // monolog settings
        'logger' => [
            'name' => 'app',
            'path' => __DIR__.'/../log/app.log',
            'level' => \Monolog\Logger::DEBUG,
        ],
    ],
];
