#/bin/sh
#
#
#


cd madar
npm run build
cd ..
cd /root/frontend/site_madar
./copy.sh
