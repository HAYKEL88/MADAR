import "babel-polyfill";
import React from "react";
import ReactDOM from "react-dom";

import MuiPickersUtilsProvider from "material-ui-pickers/utils/MuiPickersUtilsProvider";
import MomentUtils from "material-ui-pickers/utils/moment-utils";
import moment from "moment";
import registerServiceWorker from "./registerServiceWorker";
import Index from "./pages/index";
import "moment/locale/fr";
import "typeface-roboto";
import Typography from "@material-ui/core/Typography";

moment.locale("fr");

ReactDOM.render(
  <MuiPickersUtilsProvider utils={MomentUtils}>
    <Typography component="div">
      <Index />
    </Typography>
  </MuiPickersUtilsProvider>,
  document.getElementById("root")
);
registerServiceWorker();
