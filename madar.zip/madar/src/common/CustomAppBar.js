import React from "react";
import AppBar from "@material-ui/core/AppBar";
import { withStyles } from "@material-ui/core/styles";
import { withRouter } from "react-router-dom";

const myAppBar = ({ location, children }) => {
  return (
    <AppBar
      position="fixed"
      color={location.pathname === "/" || location.pathname === "/login" ? "default" : "primary"}
      elevation={location.pathname === "/" || location.pathname === "/login" ? 0 : 3}
    >
      {children}
    </AppBar>
  );
};

const CustomAppBar = withStyles(theme => {
  const backgroundColorDefault =
    theme.palette.type === "light" ? theme.palette.grey[100] : theme.palette.grey[900];
  return {
    colorDefault: {
      backgroundColor: "white",
      color: theme.palette.getContrastText(backgroundColorDefault),
    },
    colorPrimary: {
      backgroundColor: theme.palette.primary.light,
      color: theme.palette.primary.contrastText,
    },
    colorSecondary: {
      backgroundColor: theme.palette.secondary.main,
      color: theme.palette.secondary.contrastText,
    },
  };
})(withRouter(myAppBar));

export default CustomAppBar;
