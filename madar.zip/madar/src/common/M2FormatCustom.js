import React from "react";
import NumberFormat from "react-number-format";

const M2FormatCustom = props => {
  const { inputRef, onChange, ...other } = props;
  return (
    <NumberFormat
      {...other}
      ref={inputRef}
      onValueChange={values => {
        onChange({
          target: {
            value: values.value
          }
        });
      }}
      thousandSeparator=" "
      suffix={" m²"}
    />
  );
};

export default M2FormatCustom;
