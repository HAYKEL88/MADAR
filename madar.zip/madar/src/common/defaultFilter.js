const filter = (props, state) => {
  const { datas, idField } = props;
  const {
    societe,
    id,
    idactifpatrimonial,
    codePostal,
    ville,
    adresse,
    surfaceTotale,
    biensNonAcquis,
    nom_du_locataire,
    nom_portefeuille,
  } = state;

  const datasSociete = societe ? datas.filter(b => b.idsociete === societe) : datas;
  const datasSocieteF = datasSociete.filter(
    b => (biensNonAcquis ? b.date_acquisition === null : b.date_acquisition !== null),
  );

  const filter =
    id !== "" ||
    idactifpatrimonial !== "" ||
    codePostal !== "" ||
    ville !== "" ||
    adresse !== "" ||
    surfaceTotale !== "" ||
    nom_portefeuille !== "" ||
    nom_du_locataire !== "";
  const datasFiltred = filter
    ? datasSocieteF.filter(b => {
        let show = true;
        if (surfaceTotale !== "") {
          const [sC, value] = surfaceTotale.split(" ");
          const valueNum = parseInt(value, 10);
          if (!Number.isNaN(valueNum) && (sC === ">" || sC === "<")) {
            const val = parseInt(b.surface_totale || b.surface_totale_actif, 10);
            if (sC === ">") show = val > valueNum;
            if (sC === "<") show = val < valueNum;
          }
        }

        if (id !== "" && show) show = `${b[idField]}` === `${id}`;
        if (idactifpatrimonial !== "" && show) show = `${b["idactifpatrimonial"]}` === idactifpatrimonial;
        if (codePostal !== "" && show) show = `${b.code_postal}` === codePostal;
        if (adresse !== "" && show) show = `${b.adresse.toLowerCase()}`.indexOf(adresse.toLowerCase()) !== -1;
        if (ville !== "" && show) show = `${b.ville}`.toUpperCase() === ville.toUpperCase();
        if (nom_du_locataire !== "" && show)
          show = `${b.nom_du_locataire}`.toLowerCase().indexOf(nom_du_locataire.toLowerCase()) !== -1;
        if (nom_portefeuille !== "" && show)
          show = `${b.nom_portefeuille}`.toLowerCase().indexOf(nom_portefeuille.toLowerCase()) !== -1;

        return show;
      })
    : datasSocieteF;

  return { datasFiltred, filter };
};

export default filter;
