import React from "react";
import PropTypes from "prop-types";
import { withStyles } from "@material-ui/core/styles";
import { withRouter } from "react-router-dom";
import TextField from "@material-ui/core/TextField";
import debounce from "lodash/debounce";
import Grid from "@material-ui/core/Grid";
import Button from "@material-ui/core/Button";

const styles = theme => ({
  form: {
    padding: theme.spacing.unit * 2,
  },
  btn: {
    marginTop: theme.spacing.unit * 2,
  },
  ville: {
    textTransform: "uppercase",
  },
});

class RechercheForm extends React.Component {
  static propTypes = {
    idField: PropTypes.string.isRequired,
    moduleRoute: PropTypes.string.isRequired,
  };

  constructor(props) {
    super(props);
    this.state = {
      [props.idField]: null,
      code_postal: null,
      ville: null,
      adresse: null,
    };
    this.delayedCallback = debounce(
      e =>
        this.setState({
          [e.target.name]: e.target.name === "ville" ? e.target.value.toUpperCase() : e.target.value,
        }),
      250,
    );
  }

  handleChange = e => {
    e.persist();
    this.delayedCallback(e);
  };

  handleSubmit = e => {
    e.preventDefault();
    const { idField, history, moduleRoute } = this.props;
    const s = [idField, "code_postal", "ville", "adresse"].reduce(
      (m, k) => (this.state[k] && this.state[k] !== "" ? `${m}${k}=${this.state[k]}&` : m),
      "?",
    );
    if (s !== "?") {
      history.push(encodeURI(`/${moduleRoute}${s ? s.slice(0, -1) : s}`));
    }
  };

  render() {
    const { idField, idFieldName } = this.props;
    return (
      <Grid container direction="column" justify="center" alignItems="center">
        <form onSubmit={this.handleSubmit} className={this.props.classes.form}>
          <Grid item>
            <TextField
              id={idField}
              name={idField}
              label={idFieldName}
              type="text"
              margin="dense"
              fullWidth
              onChange={this.handleChange}
            />
          </Grid>
          <Grid item>
            <TextField
              id="code_postal"
              name="code_postal"
              label="Code postal"
              type="text"
              margin="dense"
              fullWidth
              onChange={this.handleChange}
            />
          </Grid>
          <Grid item>
            <TextField
              id="ville"
              name="ville"
              label="Ville"
              type="text"
              margin="dense"
              fullWidth
              inputProps={{ className: this.props.classes.ville }}
              onChange={this.handleChange}
            />
          </Grid>
          <Grid item>
            <TextField
              id="adresse"
              name="adresse"
              label="Adresse"
              type="text"
              margin="dense"
              fullWidth
              onChange={this.handleChange}
            />
          </Grid>
          <Grid item>
            <Button type="submit" variant="raised" color="primary" className={this.props.classes.btn}>
              Rechercher
            </Button>
          </Grid>
        </form>
      </Grid>
    );
  }
}

export default withRouter(withStyles(styles)(RechercheForm));
