/* eslint no-extend-native: "off" */
// Polyfill taken from: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/find?v=control#Polyfill

// https://tc39.github.io/ecma262/#sec-array.prototype.find
if (!Number.isNaN) {
  // eslint-disable-next-line
  Number.isNaN = v => v !== v;
}
