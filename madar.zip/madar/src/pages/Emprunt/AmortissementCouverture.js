import React from "react";
import { withStyles } from "@material-ui/core/styles";
import Typography from "@material-ui/core/Typography";
import AppBar from "@material-ui/core/AppBar";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import Amortissements from "./Amortissements";
import Couverture from "./Couverture";
import Dscr from "./Dscr";
import Ltv from "./Ltv";
import Ltc from "./Ltc";

const styles = theme => ({
  tabsRoot: {
    borderBottom: "1px solid #e8e8e8",
    backgroundColor: "#FFF",
  },
  tabsIndicator: {
    backgroundColor: "gray",
  },
  tabSelected: {
    color: "white",
  },
});

function TabContainer(props) {
  return (
    <Typography component="div" style={{ paddingTop: "1em" }}>
      {props.children}
    </Typography>
  );
}

class AmortissementCouverture extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      index: 0,
    };
  }

  static defaultProps = {
    layout: "desktop",
  };

  handleChange = (event, index) => {
    this.setState({ index });
  };

  calculateIdx = idx => (!this.props.couverture || this.props.couverture.length === 0 ? idx - 1 : idx);

  render() {
    const { amortissements, emprunt, couverture, classes, layout } = this.props;
    const { index } = this.state;
    return (
      <div>
        <AppBar position="static">
          <Tabs
            value={index}
            onChange={this.handleChange}
            indicatorColor="primary"
            textColor="primary"
            centered
            classes={{
              root: classes.tabsRoot,
              indicator: classes.tabsIndicator,
            }}
          >
            <Tab
              label="Tableau amortissement"
              classes={{ root: classes.tabRoot, selected: classes.tabSelected }}
            />
            {couverture &&
              couverture.length > 0 && (
                <Tab
                  label="Couverture"
                  classes={{
                    root: classes.tabRoot,
                    selected: classes.tabSelected,
                  }}
                />
              )}
            <Tab label="DSCR" classes={{ root: classes.tabRoot, selected: classes.tabSelected }} />
            <Tab label="LTV" classes={{ root: classes.tabRoot, selected: classes.tabSelected }} />
            <Tab label="LTC" classes={{ root: classes.tabRoot, selected: classes.tabSelected }} />
          </Tabs>
        </AppBar>
        {index === 0 && (
          <TabContainer>
            <Amortissements layout={layout} frequence={emprunt.frequence} amortissements={amortissements} />
          </TabContainer>
        )}
        {this.props.couverture &&
          this.props.couverture.length > 0 &&
          index === 1 && (
            <TabContainer>
              <Couverture couverture={couverture} frequence={emprunt.frequence} />
            </TabContainer>
          )}
        {index === this.calculateIdx(2) && (
          <TabContainer>
            <Dscr
              couverture={couverture && couverture.length > 0}
              idamortissement={emprunt.idamortissement}
              idemprunt={emprunt.idemprunt}
            />
          </TabContainer>
        )}
        {index === this.calculateIdx(3) && (
          <TabContainer>
            <Ltv
              couverture={couverture && couverture.length > 0}
              idamortissement={emprunt.idamortissement}
              idemprunt={emprunt.idemprunt}
            />
          </TabContainer>
        )}
        {index === this.calculateIdx(4) && (
          <TabContainer>
            <Ltc
              couverture={couverture && couverture.length > 0}
              idamortissement={emprunt.idamortissement}
              idemprunt={emprunt.idemprunt}
            />
          </TabContainer>
        )}
      </div>
    );
  }
}

export default withStyles(styles)(AmortissementCouverture);
