import React from "react";
import { withStyles } from "@material-ui/core/styles";
import Grid from "@material-ui/core/Grid";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";

const styles = theme => ({
  selected: {
    padding: theme.spacing.unit,
    textAlign: "center",
    marginTop: theme.spacing.unit,
    marginBottom: theme.spacing.unit,
    border: "solid 1px gray",
    backgroundColor: "silver",
  },
  notSelected: {
    marginBottom: theme.spacing.unit,
    marginTop: theme.spacing.unit,
    textAlign: "center",
    padding: theme.spacing.unit,
    border: "solid 1px silver",
  },
});

const Tranche = ({ tranche, classes, selected, onClick }) => {
  const { montant_financement, duree_financement, type_amortissement, type_emprunt } = tranche;

  return (
    <ListItem button className={selected ? classes.selected : classes.notSelected} onClick={onClick}>
      <Grid container direction="row" justify="space-between">
        <Grid item>
          <ListItemText
            inset
            primary={` Emprunt ${type_emprunt} / ${type_amortissement} de ${montant_financement} € sur ${duree_financement} mois`}
          />
        </Grid>
      </Grid>
    </ListItem>
  );
};

export default withStyles(styles)(Tranche);
