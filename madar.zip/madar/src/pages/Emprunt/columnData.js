// capital: 0
// ​​​
// date_depart: "2018-03-01T00:00:00+0000"
// ​​​
// date_echeance: "2018-01-01T00:00:00+0000"
// ​​​
// echeances_numero: 1
// ​​​
// idemprunt: 23
// ​​​
// mois: 0
// ​​​
// montant_echeance: 0
// ​​​
// montant_interets: 0
// ​​​
// type_amortissement: "taux_fixe"
// ​​​
// valeur_residuelle: 100000

const columnData = [
  { id: "echeances_numero", numeric: true, disablePadding: false, label: "N° échéance" },
  {
    id: "capital",
    numeric: true,
    disablePadding: false,
    label: "Capital début période",
  },
  { id: "montant_echeance", numeric: false, disablePadding: false, label: "Mensualité" },
  { id: "montant_interets", numeric: false, disablePadding: false, label: "Intérets" },
  { id: "valeur_residuelle", numeric: true, disablePadding: false, label: "Capital fin de période" },
];

export default columnData;
