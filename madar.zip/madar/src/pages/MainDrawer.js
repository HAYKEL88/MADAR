import React, { Component } from "react";
import PropTypes from "prop-types";
import { withRouter } from "react-router-dom";
import Hidden from "@material-ui/core/Hidden";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import Drawer from "@material-ui/core/Drawer";
import Collapse from "@material-ui/core/Collapse";
import ExpandLess from "@material-ui/icons/ExpandLess";
import ExpandMore from "@material-ui/icons/ExpandMore";
import PersonIcon from "@material-ui/icons/Person";
import InputIcon from "@material-ui/icons/Input";
import DomainIcon from "@material-ui/icons/Domain";
import DescriptionIcon from "@material-ui/icons/Description";
import EuroIcon from "@material-ui/icons/EuroSymbol";
import { withStyles } from "@material-ui/core/styles";

const styles = theme => ({
  list: {
    width: 250,
  },
  subItem: {
    paddingLeft: theme.spacing.unit * 8,
  },
});

class MainDrawer extends Component {
  state = {
    patrimoineOpen: true,
    gestfinOpen: true,
  };
  handleClick = url => {
    const { onClose, history } = this.props;
    history.push(url);
    onClose();
  };

  handleClosePatrimoine = () => this.setState({ patrimoineOpen: !this.state.patrimoineOpen });
  handleCloseGestFin = () => this.setState({ gestfinOpen: !this.state.gestfinOpen });

  goToActifs = () => {
    const { history } = this.props;
    history.push("/actifs");
  };

  render() {
    const { user, onClose, classes, open, history } = this.props;
    return (
      <Drawer open={open} onClose={onClose}>
        <List component="nav" className={classes.list} onChange={value => history.push(value)}>
          {user &&
            user.superviseur && (
              <Hidden mdDown>
                <ListItem button onClick={() => this.handleClick("/users")}>
                  <ListItemIcon>
                    <PersonIcon />
                  </ListItemIcon>
                  <ListItemText primary="Utilisateurs" />
                </ListItem>
              </Hidden>
            )}
          {user && (
            <ListItem button onClick={this.handleClosePatrimoine}>
              <ListItemIcon>
                <DomainIcon />
              </ListItemIcon>
              <ListItemText inset primary="Patrimoine" />
              {this.state.patrimoineOpen ? <ExpandLess /> : <ExpandMore />}
            </ListItem>
          )}
          {user && (
            <Collapse in={this.state.patrimoineOpen} timeout="auto" unmountOnExit>
              <List component="div" disablePadding>
                <Hidden mdDown>
                  <ListItem button onClick={() => this.handleClick("/actifs")} className={classes.subItem}>
                    <ListItemText primary="Actifs" />
                  </ListItem>
                  <ListItem button onClick={() => this.handleClick("/locaux")} className={classes.subItem}>
                    <ListItemText primary="Locaux" />
                  </ListItem>
                  <ListItem button onClick={() => this.handleClick("/baux")} className={classes.subItem}>
                    <ListItemText primary="Baux" />
                  </ListItem>
                </Hidden>
                <Hidden only={["md", "lg", "xl"]}>
                  <ListItem
                    button
                    onClick={() => this.handleClick("/actifs_mobile")}
                    className={classes.subItem}
                  >
                    <ListItemText primary="Actifs" />
                  </ListItem>
                  <ListItem
                    button
                    onClick={() => this.handleClick("/locaux_mobile")}
                    className={classes.subItem}
                  >
                    <ListItemText primary="Locaux" />
                  </ListItem>
                  <ListItem
                    button
                    onClick={() => this.handleClick("/baux_mobile")}
                    className={classes.subItem}
                  >
                    <ListItemText primary="Baux" />
                  </ListItem>
                </Hidden>
              </List>
            </Collapse>
          )}
          <Hidden mdDown>
            {user && (
              <ListItem button onClick={() => this.handleClick("/emprunts")}>
                <ListItemIcon>
                  <EuroIcon />
                </ListItemIcon>
                <ListItemText primary="Gestion financière" />
              </ListItem>
            )}
          </Hidden>
          <Hidden only={["md", "lg", "xl"]}>
            {user && (
              <ListItem button onClick={() => this.handleClick("/emprunts_mobile")}>
                <ListItemIcon>
                  <EuroIcon />
                </ListItemIcon>
                <ListItemText primary="Gestion financière" />
              </ListItem>
            )}
          </Hidden>
          {user && (
            <Hidden mdDown>
              <ListItem button onClick={() => this.handleClick("/rapports")}>
                <ListItemIcon>
                  <DescriptionIcon />
                </ListItemIcon>
                <ListItemText primary="Rapports" />
              </ListItem>
            </Hidden>
          )}
          {!user && (
            <ListItem button onClick={() => this.handleClick("/login")}>
              <ListItemIcon>
                <InputIcon />
              </ListItemIcon>
              <ListItemText primary="Connexion" />
            </ListItem>
          )}
        </List>
      </Drawer>
    );
  }
}

MainDrawer.propTypes = {
  onClose: PropTypes.func.isRequired,
  classes: PropTypes.object.isRequired,
  user: PropTypes.object,
};

export default withRouter(withStyles(styles)(MainDrawer));
