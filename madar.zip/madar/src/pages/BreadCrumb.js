import React from "react";
import { withRouter } from "react-router-dom";
import Grid from "@material-ui/core/Grid";
import Typography from "@material-ui/core/Typography";

// eslint-disable
const pathList = [
  {
    regexp: "/profil",
    paths: "Espace Utilisateur > Paramètres du profil ",
  },
  {
    regexp: "/locaux/nouveau",
    paths: "Patrimoine > Locaux > Nouveau local ",
  },
  {
    regexp: "/locaux",
    paths: "Patrimoine > Locaux",
  },
  {
    regexp: "/users",
    paths: "Utilisateurs > Gestion des comptes",
  },
  {
    regexp: "/actifs/nouveau",
    paths: "Patrimoine > Actifs > Nouvel actif",
  },
  {
    regexp: "/actifs",
    paths: "Patrimoine > Actifs",
  },
  {
    regexp: "/baux/nouveau",
    paths: "Patrimoine > Baux > Nouveau bail",
  },
  {
    regexp: "/baux",
    paths: "Patrimoine > Baux",
  },
  {
    regexp: "/emprunts/nouveau",
    paths: "Patrimoine > Emprunts > Nouvel emprunt ",
  },
  {
    regexp: "/emprunts",
    paths: "Patrimoine > Emprunts",
  },
];
// eslint-enable

const BreadCrumb = ({ location: { pathname, search } }) => {
  const found = pathList.find(p => {
    const test = `/${pathname}${search ? `?${search}` : ""}/`.search(new RegExp(p.regexp, "g")) !== -1;
    return test;
  });
  if (!found) return null;
  return (
    <Grid container alignItems="center" justify="flex-start" direction="row">
      {
        <Grid item>
          <div style={{ padding: "8px 10px" }}>
            <Typography variant="body1" gutterBottom color="primary">{` ${found.paths} `}</Typography>
          </div>
        </Grid>
      }
    </Grid>
  );
};

export default withRouter(BreadCrumb);
