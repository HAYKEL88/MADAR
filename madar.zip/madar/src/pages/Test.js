import React from "react";
import Grid from "@material-ui/core/Grid";
import Centered from "../layout/Centered";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import { Link } from "react-router-dom";

const Test = () => (
  <Centered spacing={16}>
    <Grid item>
      <Typography variant="display1" gutterBottom>
        Material-UI
      </Typography>
      <Typography variant="subheading" gutterBottom>
        example project
      </Typography>
      <Button variant="contained" color="secondary" onClick={this.handleClick}>
        Super Secret Password
      </Button>
      <Link to="/test">Test</Link>
    </Grid>
  </Centered>
);

export default Test;
