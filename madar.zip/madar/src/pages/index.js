import React from "react";
import PropTypes from "prop-types";
import { BrowserRouter as Router, Route } from "react-router-dom";
import { HotKeys } from "react-hotkeys";
import Toolbar from "@material-ui/core/Toolbar";
import Hidden from "@material-ui/core/Hidden";
import IconButton from "@material-ui/core/IconButton";
import MenuIcon from "@material-ui/icons/Menu";
import PersonIcon from "@material-ui/icons/Person";
import Avatar from "@material-ui/core/Avatar";
import MenuItem from "@material-ui/core/MenuItem";
import Menu from "@material-ui/core/Menu";
import LinkButton from "../common/LinkButton";
import Grid from "@material-ui/core/Grid";
import { withStyles } from "@material-ui/core/styles";
import withRoot from "../withRoot";
import MainDrawer from "./MainDrawer";
import CustomAppBar from "../common/CustomAppBar";
import TitreApp from "./TitreApp";
import Login from "./Login";
import Baux from "./Bail/Baux";
import BauxMobile from "./BailMobile/Baux";
import Actifs from "./Actif/Actifs";
import ActifsMobile from "./ActifMobile/Actifs";
import EmpruntsMobile from "./EmpruntMobile/Emprunts";
import Locaux from "./Local/Locaux";
import LocauxMobile from "./LocauxMobile/Locaux";
import Profil from "./User/Profil";
import UserList from "./User/List";
import Emprunts from "./Emprunt/Emprunts";
import Rapports from "./Rapport/Rapports";
import MadarSnackbarContent from "./Notifications";
import Register from "./Register";
import ListeNotificationsMadar from "./ListeNotificationsMadar";
import ListeNotificationsMobileMadar from "./ListeNotificationsMobileMadar";
import Logo from "./Logo";
import BreadCrumb from "./BreadCrumb";
import HotkeyManager from "./HotkeyManager";
import GlobalContext from "./GlobalContext";
import './globalStylesheet.css';

const styles = theme => ({
  root: {
    textAlign: "center",
    paddingTop: "34px",
    flexGrow: 1
  },
  flex: {
    flex: 1
  },
  menuButton: {
    marginLeft: -12,
    marginRight: 20
  }
});

class Index extends React.Component {
  constructor(props) {
    super(props);
    const user = window && window.sessionStorage.getItem("madar");
    this.state = {
      open: false,
      user: user ? JSON.parse(user) : null,
      notificationOpen: false,
      typeNotification: "success",
      msgNotification: null,
      redirect: null, // redirect action dans notification
      duration: 1500
    };
  }

  handleClose = () => {
    this.setState({
      open: false
    });
  };

  handleClick = () => {
    this.setState({
      open: true
    });
  };

  handleLoginSuccess = user => {
    if (window && window.sessionStorage) {
      window.sessionStorage.setItem("madar", JSON.stringify(user));
    }
    console.log("logged !", user);
    return this.setState({ user });
  };

  handleFetch = ({ url, method, body, silent }) => {
    const headers = {
      Accept: "application/json",
      "Content-Type": "application/json"
    };
    if (this.state.user) {
      headers["X-Api-Key"] = this.state.user.api_key;
    }
    return new Promise((resolve, reject) => {
      const prefix = url.indexOf('pdfs') == -1 ? '/public/index.php' : '';
      console.log('fetch', `${prefix}${url}`);
      return fetch(`${prefix}${url}`, {
        method: method || "GET",
        headers,
        body: body ? JSON.stringify(body) : null
      })
        .then(res => {
          if (res.status > 204 && !silent) {
            this.handleOpenNotification(
              "error",
              `Erreur backend ${res.status}`,
              undefined,
              4000
            );
            return reject(`Erreur backend ${res.status}`);
          }
          return res.json();
        })
        .then(
          res =>
            res && res.data
              ? resolve(res.data)
              : reject('Pas de propriété "data" dans la réponse')
        );
    });
  };

  handleLogout = () => {
    if (window && window.sessionStorage) {
      window.sessionStorage.removeItem("madar");
    }
    window.location = "/";
    this.setState({ user: null });
  };

  handleOpenNotification = (
    typeNotification,
    msgNotification,
    redirect = null,
    duration = 1500
  ) =>
    this.setState({
      notificationOpen: true,
      typeNotification,
      msgNotification,
      redirect,
      duration
    });

  handleCloseNotification = () =>
    this.setState({
      notificationOpen: false,
      typeNotification: "success",
      msgNotification: null,
      redirect: null,
      duration: 1500,
      menuOpen: false,
      anchorEl: null,
      shortCutPressed: null
    });

  handleMenu = event => {
    this.setState({ anchorEl: event.currentTarget });
  };

  handleCloseMenu = () => {
    this.setState({ anchorEl: null });
  };

  clearShortcut = () => this.setState({ shortCutPressed: null });

  goToActifs = () => {
    this.setState({ shortCutPressed: "actifs" });
  };

  goToEmprunts = () => {
    this.setState({ shortCutPressed: "emprunts" });
  };

  goToLocaux = () => {
    this.setState({ shortCutPressed: "locaux" });
  };

  gotToBaux = () => {
    this.setState({ shortCutPressed: "baux" });
  };

  gotToRapport = () => {
    this.setState({ shortCutPressed: "rapports" });
  };

  gotToHome = () => {
    this.setState({ shortCutPressed: "" });
  };

  render() {
    const { classes } = this.props;
    const {
      open,
      user,
      notificationOpen,
      typeNotification,
      msgNotification,
      redirect,
      duration,
      anchorEl
    } = this.state;
    const handlers = {
      showActifs: this.goToActifs,
      showEmprunts: this.goToEmprunts,
      showLocaux: this.goToLocaux,
      showBaux: this.gotToBaux,
      showRapport: this.gotToRapport,
      showHome: this.gotToHome
    };
    const keyMap = {
      showActifs: "ctrl+alt+a",
      showEmprunts: "ctrl+alt+e",
      showLocaux: "ctrl+alt+l",
      showBaux: "ctrl+alt+b",
      showRapport: "ctrl+alt+r",
      showHome: "ctrl+alt+h"
    };

    const menuOpen = Boolean(anchorEl);
    return (
      <HotKeys keyMap={keyMap} handlers={handlers} focused>
        <Router>
          <GlobalContext.Provider value={{ user, fetch: this.handleFetch }}>
            <div className={classes.root}>
              <HotkeyManager
                shortCutPressed={this.state.shortCutPressed}
                clearShortcut={this.clearShortcut}
              />
              <MadarSnackbarContent
                message={msgNotification}
                open={notificationOpen}
                onClose={this.handleCloseNotification}
                variant={typeNotification}
                redirect={redirect}
                duration={duration}
              />
              <MainDrawer user={user} onClose={this.handleClose} open={open} />
              <CustomAppBar>
                <Toolbar>
                  <IconButton
                    className={classes.menuButton}
                    color="inherit"
                    aria-label="Menu"
                    onClick={this.handleClick}
                  >
                    <MenuIcon />
                  </IconButton>
                  <TitreApp user={user} />
                  {user && (
                    <Hidden smDown>
                      <IconButton
                        aria-owns={menuOpen ? "menu-appbar" : null}
                        aria-haspopup="true"
                        onClick={this.handleMenu}
                        color="inherit"
                      >
                        {user.image64 && (
                          <Avatar alt="Remy Sharp" src={user.image64} />
                        )}
                        {!user.image64 && <PersonIcon />}
                      </IconButton>
                      <Menu
                        id="menu-appbar"
                        anchorEl={anchorEl}
                        anchorOrigin={{
                          vertical: "top",
                          horizontal: "right"
                        }}
                        transformOrigin={{
                          vertical: "top",
                          horizontal: "right"
                        }}
                        open={menuOpen}
                        onClose={this.handleCloseMenu}
                      >
                        <MenuItem onClick={() => (window.location = "/profil")}>
                          Profil
                        </MenuItem>
                        <MenuItem onClick={this.handleLogout}>
                          Déconnexion
                        </MenuItem>
                      </Menu>
                    </Hidden>
                  )}
                  <Hidden smDown>
                    {!user && (
                      <LinkButton color="inherit" to="/login">
                        Connexion
                      </LinkButton>
                    )}
                  </Hidden>
                </Toolbar>
              </CustomAppBar>
              <Grid container className={classes.root}>
                <Hidden smDown>
                  <BreadCrumb />
                </Hidden>
                <Grid item xs={12}>
                  {!user && <Route path="/" exact render={() => <Logo />} />}
                  {user && (
                    <Hidden smDown>
                      <Route
                        path="/"
                        exact
                        render={() => <ListeNotificationsMadar />}
                      />
                    </Hidden>
                  )}
                  {user && (
                    <Hidden smUp>
                      <Route
                        path="/"
                        exact
                        render={() => <ListeNotificationsMobileMadar />}
                      />
                    </Hidden>
                  )}
                  {user && (
                    <Route
                      path="/profil"
                      render={() => (
                        <Profil
                          user={user}
                          onSave={this.handleLoginSuccess}
                          openNotification={this.handleOpenNotification}
                        />
                      )}
                    />
                  )}
                  {user &&
                    user.superviseur && (
                      <Route
                        path="/register"
                        render={() => (
                          <Register
                            openNotification={this.handleOpenNotification}
                          />
                        )}
                      />
                    )}
                  {<Route path="/users" render={() => <UserList />} />}
                  <Route
                    path="/actifs"
                    render={() => (
                      <Actifs
                        user={user}
                        openNotification={this.handleOpenNotification}
                      />
                    )}
                  />
                  <Route
                    path="/emprunts/:empruntId?"
                    render={() => (
                      <Emprunts
                        user={user}
                        openNotification={this.handleOpenNotification}
                      />
                    )}
                  />
                  <Route
                    path="/emprunts_mobile/:empruntId?"
                    render={() => (
                      <EmpruntsMobile
                        user={user}
                        openNotification={this.handleOpenNotification}
                      />
                    )}
                  />
                  <Route
                    path="/rapports"
                    render={() => (
                      <Rapports
                        user={user}
                        openNotification={this.handleOpenNotification}
                      />
                    )}
                  />
                  <Route
                    path="/baux"
                    render={() => (
                      <Baux
                        user={user}
                        openNotification={this.handleOpenNotification}
                      />
                    )}
                  />
                  <Route
                    path="/locaux"
                    render={() => (
                      <Locaux
                        user={user}
                        openNotification={this.handleOpenNotification}
                      />
                    )}
                  />
                  <Route
                    path="/login"
                    render={() => (
                      <Login onLoginSuccess={this.handleLoginSuccess} />
                    )}
                  />
                  <Route
                    path="/actifs_mobile/:actifId?"
                    render={() => <ActifsMobile user={user} />}
                  />
                  <Route
                    path="/locaux_mobile/:localId?"
                    render={() => <LocauxMobile user={user} />}
                  />
                  <Route
                    path="/baux_mobile/:bailId?"
                    render={() => <BauxMobile user={user} />}
                  />
                </Grid>
              </Grid>
            </div>
          </GlobalContext.Provider>
        </Router>
      </HotKeys>
    );
  }
}

Index.propTypes = {
  classes: PropTypes.object.isRequired
};

export default withRoot(withStyles(styles)(Index));
