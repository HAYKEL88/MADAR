import React from "react";
import { withStyles } from "@material-ui/core/styles";
import moment from "moment";
import Grid from "@material-ui/core/Grid";
import CircularProgress from "@material-ui/core/CircularProgress";
import Typography from "@material-ui/core/Typography";
import withGlobals from "./withGlobals";
import Logo from "./logo.jpg";

const styles = theme => ({
  title: {
    marginTop: theme.spacing.unit * 4,
    marginBottom: theme.spacing.unit * 4,
  },
  container: {
    height: "calc(100vh)",
  },
});

class ListeNotificationsMobileMadar extends React.Component {
  state = {
    rapports: [],
    loaded: false,
  };

  componentDidMount() {
    this.props.fetch({ url: "/rapports/excel" }).then(rapports => {
      this.setState({
        loaded: true,
        rapports: rapports.sort((r1, r2) => {
          if (r1.file > r2.file) return -1;
          if (r1.file < r2.file) return 1;
          return 0;
        }),
      });
    });
  }

  buildRapportLink = rapport => {

    const rapportsUrl = process.env.REACT_APP_DOMAIN + "/files/export/";
    const split = rapport.file
      .replace(".xlsx", "")
      .replace("_", " ")
      .replace("_", " ")
      .split(" ");
    return (
      <a
        className={this.props.classes.excelLink}
        // config
        href={`${rapportsUrl}${rapport.file}`}
      >
        {split[0]} {split[1]} du {moment(split[2]).format("DD/MM/YYYY")}
      </a>
    );
  };

  openDrawer = () => this.setState({ historiqueOpen: true });

  closeDrawer = () => this.setState({ historiqueOpen: false });

  render() {
    const { classes } = this.props;
    const { rapports, loaded } = this.state;

    return (
      <Grid
        container
        direction="column"
        alignItems="center"
        justify="center"
        spacing={0}
        className={classes.container}
      >
        <Grid item>
          <img src={Logo} alt="logo madar" width="150px" />
        </Grid>
        <Grid item className={classes.title}>
          {!loaded && <CircularProgress size={50} />}
          <Typography variant="body1">
            {loaded && rapports.length > 0 && this.buildRapportLink(rapports[0])}
          </Typography>
        </Grid>
      </Grid>
    );
  }
}

export default withStyles(styles)(withGlobals(ListeNotificationsMobileMadar));
