import React from "react";
import Grid from "@material-ui/core/Grid";
import Select from "@material-ui/core/Select";
import { withStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";
import MenuItem from "@material-ui/core/MenuItem";
import CircularProgress from "@material-ui/core/CircularProgress";
import InputLabel from "@material-ui/core/InputLabel";
import FormControl from "@material-ui/core/FormControl";
import DownloadIcon from "@material-ui/icons/GetApp";
import withGlobals from "../withGlobals";

const styles = theme => ({
  root: {
    display: "flex",
    flexWrap: "wrap",
  },
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 220,
    // maxWidth: 300,
  },
  chips: {
    display: "flex",
    flexWrap: "wrap",
  },
  chip: {
    margin: theme.spacing.unit / 4,
  },
  progress: {
    margin: theme.spacing.unit * 2,
  },
  progressMsg: {
    fontSize: "1.3em",
    fontWeight: "bold",
  },
});

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

class Remboursement extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      societes: [],
      selectionSociete: "",
      globale: false,
      societe: false,
      generating: false,
      generated: false,
    };
  }

  handleReset = () => {
    this.setState({ generating: false, generated: false, selectionSociete: "", globale: false });
  };

  handleSubmit = () => {
    this.setState({ generating: true });
    const societeSelected = this.state.societes.find(b => b.nom_societe === this.state.selectionSociete);
    let societeQuery = '';
    if (societeSelected) {
        societeQuery = '&idsociete=' + societeSelected.idsociete;
    }
    this.props.fetch({ url: "/rapports/", method: "POST" }).then(() => {
        this.props.fetch({url: `${this.props.rendererHost}/profil_remboursement.pdf?action=dnld${societeQuery}`})
            .then(() => {
                     this.setState({ generating: true, generated: true }); 
            });
    });
  };

  componentDidMount = () => {
    this.props.fetch({ url: `/societes/` }).then(societes => this.setState({ societes }));
  };

  handleChangeCB = name => event => {
    this.setState({ [name]: event.target.checked, generating: false, generated: false });
  };

  handleChange = e => this.setState({ [e.target.name]: e.target.value, generating: false, generated: false });

  render() {
    const { classes, theme } = this.props;
    const { societes, generating, generated, selectionSociete } = this.state;
    const rapportsUrl = "https://prex.madar-patrimoine.2m-advisory.fr/files/export";
    return [
      (
        !generated &&
        !generating && (
          <Grid container alignItems="flex-start" justify="flex-start" direction="column">
            <Grid item>
              <FormControl fullWidth className={classes.formControl}>
                <InputLabel htmlFor="select-multiple-banques">Société</InputLabel>
                <Select
                  value={selectionSociete}
                  name="selectionSociete"
                  onChange={this.handleChange}
                  MenuProps={MenuProps}
                >
                  {societes.map(societe => (
                    <MenuItem
                      key={societe.idsociete}
                      value={societe.nom_societe}
                      style={{
                        fontWeight:
                          this.state.societes.indexOf(societe) === -1
                            ? theme.typography.fontWeightRegular
                            : theme.typography.fontWeightMedium,
                      }}
                    >
                      {societe.nom_societe}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
          </Grid>
        ): null),
      generating &&
        !generated && (
          <Grid item>
            <Grid container alignItems="center" justify="center" direction="row">
              <Grid item className={classes.progressMsg}>
                Generation du rapport...
              </Grid>
              <Grid item>
                <CircularProgress className={classes.progress} size={50} />
              </Grid>
            </Grid>
          </Grid>
        ),
      generated ? <Grid item>
        <Button color="default" variant="raised" href={`${rapportsUrl}/profil_remboursement.pdf`} target="__blank">
          <DownloadIcon />Télécharger le rapport
        </Button>
      </Grid> : null,
      !generated &&
        !generating && (
          <Grid item style={{ marginTop: "4em" }}>
            <Button fullWidth color="primary" variant="raised" onClick={this.handleSubmit}>
              Générer le rapport
            </Button>
          </Grid>
        ),
      generated && !generating ? (
        <Grid item style={{ marginTop: "4em" }}>
          <Button fullWidth color="primary" variant="raised" onClick={this.handleReset}>
            Nouveau rapport
          </Button>
        </Grid>
      ) : null,
    ];
  }
}

export default withStyles(styles, { withTheme: true })(withGlobals(Remboursement));
