import React from "react";
import Grid from "@material-ui/core/Grid";
import Select from "@material-ui/core/Select";
import { withStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";
import MenuItem from "@material-ui/core/MenuItem";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import CircularProgress from "@material-ui/core/CircularProgress";
import InputLabel from "@material-ui/core/InputLabel";
import FormControl from "@material-ui/core/FormControl";
import DownloadIcon from "@material-ui/icons/GetApp";
import withGlobals from "../withGlobals";

const styles = theme => ({
  root: {
    display: "flex",
    flexWrap: "wrap",
  },
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 220,
    // maxWidth: 300,
  },
  chips: {
    display: "flex",
    flexWrap: "wrap",
  },
  chip: {
    margin: theme.spacing.unit / 4,
  },
  progress: {
    margin: theme.spacing.unit * 2,
  },
  progressMsg: {
    fontSize: "1.3em",
    fontWeight: "bold",
  },
});

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

class Crd extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      banques: [],
      globale: false,
      generating: false,
      generated: false,
      selectionBanque: "",
    };
  }

  handleSubmit = () => {
      console.log('ici');
    this.setState({ generating: true });
    const banqueSelected = this.state.banques.find(b => b.nom_banque === this.state.selectionBanque);
    this.props.fetch({ url: "/rapports/", method: "POST" }).then(() => {
        this.setState({ generating: false, generated: true }); 
    }).catch(() => {
        this.setState({ generating: false, generated: true }); 
    });
  };

  handleReset = () => {
    this.setState({
      globale: false,
      generating: false,
      generated: false,
      selectionBanque: "",
    });
  };

  componentDidMount = () => {
    this.props.fetch({ url: `/banques/` }).then(banques => this.setState({ banques }));
  };

  handleChangeCB = name => event => {
    this.setState({ [name]: event.target.checked, generating: false, generated: false });
  };

  handleChange = e => this.setState({ [e.target.name]: e.target.value, generating: false, generated: false });

  generateRapporUrl = () => {
    const banqueSelected = this.state.banques.find(b => b.nom_banque === this.state.selectionBanque);
    return `${this.props.rendererHost}/crd_banque.pdf?action=dwnld${
      this.state.selectionBanque ? `&idbanque=${banqueSelected.idbanque}` : ""
    }`;
  };

  render() {
    const { classes, theme } = this.props;
    const { banques, generating, generated, globale, selectionBanque } = this.state;
    const rapportsUrl = "https://prex.madar-patrimoine.2m-advisory.fr/files/export";
    return [
      <Grid container alignItems="flex-start" justify="flex-start" direction="column">
        {!generating &&
          !generated && (
            <Grid item>
              <FormControlLabel
                control={
                  <Checkbox
                    checked={globale}
                    onChange={this.handleChangeCB("globale")}
                    value="globale"
                    color="primary"
                  />
                }
                label="Globale"
              />
            </Grid>
          )}
        {!globale &&
          !generating &&
          !generated && (
            <Grid item>
              <FormControl className={classes.formControl} fullWidth>
                <InputLabel htmlFor="select-multiple-banques">Données de la banque</InputLabel>
                <Select
                  fullWidth
                  value={selectionBanque}
                  name="selectionBanque"
                  onChange={this.handleChange}
                  MenuProps={MenuProps}
                >
                  {banques.map(banque => (
                    <MenuItem
                      key={banque.idbanque}
                      value={banque.nom_banque}
                      style={{
                        fontWeight:
                          this.state.banques.indexOf(banque) === -1
                            ? theme.typography.fontWeightRegular
                            : theme.typography.fontWeightMedium,
                      }}
                    >
                      <img src={require('../../banques/' + banque.idbanque+'.png')} style={{height: 25, paddingTop: 5}}/> {banque.nom_banque} {banque.nom_banque}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
          )}
      </Grid>,
      generating ? <Grid item style={{ visibility: generating ? "visible" : "hidden" }}>
        <Grid container alignItems="center" justify="center" direction="row">
          <Grid item className={classes.progressMsg}>
            Generation du rapport...
          </Grid>
          <Grid item>
            <CircularProgress className={classes.progress} size={50} />
          </Grid>
        </Grid>
      </Grid> : null,
      generated ? (
        <Grid item>
          <Button color="default" variant="raised" href={`${rapportsUrl}/crd_banque${selectionBanque ? '_bnp' : ''}.pdf`} target="__blank">
            <DownloadIcon />Télécharger le rapport
          </Button>
        </Grid>
      ) : null,
      !generated && !generating ? (
        <Grid item style={{ marginTop: "4em" }}>
          <Button fullWidth color="primary" variant="raised" onClick={this.handleSubmit}>
            Générer le rapport
          </Button>
        </Grid>
      ) : null,
      generated && !generating ? (
        <Grid item style={{ marginTop: "4em" }}>
          <Button fullWidth color="primary" variant="raised" onClick={this.handleReset}>
            Nouveau rapport
          </Button>
        </Grid>
      ) : null,
    ];
  }
}

export default withStyles(styles, { withTheme: true })(withGlobals(Crd));
