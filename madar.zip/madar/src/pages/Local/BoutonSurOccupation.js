import React, { Component } from "react";
import { withRouter, Link } from "react-router-dom";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogTitle from "@material-ui/core/DialogTitle";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";

class BoutonSurOccupation extends Component {
  state = {
    open: false,
  };

  componentWillReceiveProps = nextProps => {
    if (this.props.location.pathname !== nextProps.location.pathname) {
      this.setState({ open: false });
    }
  };

  handleOpenDialog = () => this.setState({ open: true });

  handleCloseDialog = () => this.setState({ open: false });

  render() {
    const { surOccupation, locaux } = this.props;
    return [
      <Dialog open={this.state.open} onClose={this.handleCloseDialog} aria-labelledby="list-actif-title">
        <DialogTitle id="list-actif-title">Liste des locaux</DialogTitle>
        <DialogContent>
          <List component="nav">
            {locaux.map((l, idx) => (
              <ListItem key={`${l.idloca}${idx}`} button component={Link} to={`/locaux/${l.idlocal}`}>
                {l.idlocal} -{" "}
                {l.surface_totale
                  ? l.surface_totale
                  : parseInt(l.surface_rdc, 10) +
                    parseInt(l.surface_sous_sol, 10) +
                    parseInt(l.surface_etage, 10)}{" "}
                m²
              </ListItem>
            ))}
          </List>
        </DialogContent>
        <DialogActions>
          <Button onClick={this.handleCloseDialog} color="primary">
            Fermer
          </Button>
        </DialogActions>
      </Dialog>,
      <Button onClick={this.handleOpenDialog}>{`Sur occupation de ${surOccupation} m² !!`}</Button>,
    ];
  }
}

export default withRouter(BoutonSurOccupation);
