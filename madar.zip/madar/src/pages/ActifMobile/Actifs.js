import React, { Component } from "react";
import PropTypes from "prop-types";
import { withRouter } from "react-router-dom";
import Grid from "@material-ui/core/Grid";
import Actif from "./Actif";
import Centered from "../../layout/Centered";
import RechercheForm from "../../common/RechercheForm";
import ListItemsMobile from "../../common/ListItemsMobile";
import SwipeableViews from "react-swipeable-views";

class Actifs extends Component {
  static propTypes = {
    history: PropTypes.object.isRequired
  };

  constructor(props) {
    super(props);
    this.state = {
      index: this.findSwipeableViewsIndex(props)
    };
  }

  componentWillReceiveProps = nextProps => {
    const {
      match: {
        params: { actifId }
      },
      location: { search }
    } = this.props;
    if (
      search !== nextProps.location.search ||
      actifId !== nextProps.match.params.actifId
    ) {
      this.setState({ index: this.findSwipeableViewsIndex(nextProps) });
    }
  };

  findSwipeableViewsIndex = props => {
    if (props.location.search === "" && props.match.params.actifId) {
      return 2;
    }
    if (props.location.search !== "" && !props.match.params.actifId) {
      return 1;
    }
    if (props.location.search === "" && !props.match.params.actifId) {
      return 0;
    }
  };

  render() {
    const {
      match: {
        params: { actifId }
      },
      user
    } = this.props;
    if (!user || !user.login) return <h1>Acces denied</h1>;

    const { index } = this.state;

    return (
      <Centered alignItems="center" justify="center">
        <Grid item xs={12}>
          <SwipeableViews index={index} animateHeight>
            <RechercheForm
              idField="idactifpatrimonial"
              idFieldName="Id de l'actif"
              moduleRoute="actifs_mobile"
            />
            <ListItemsMobile
              idField="idactifpatrimonial"
              buildPrimaryText={a => `${a.idactifpatrimonial} - ${a.adresse}`}
              buildSecondaryText={a =>
                `${a.code_postal} ${a.ville} - ${a.surface_totale_actif} m²`
              }
              moduleRoute="actifs_mobile"
              queryPathname="/actifs/"
            />
            <div style={{ padding: "0 8px" }}>
              <Actif actifId={actifId} />
            </div>
          </SwipeableViews>
        </Grid>
      </Centered>
    );
  }
}

export default withRouter(Actifs);
