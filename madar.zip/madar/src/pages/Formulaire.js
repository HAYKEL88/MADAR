import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router-dom';
import Grid from '@material-ui/core/Grid';
import Centered from '../layout/Centered';
import Button from '@material-ui/core/Button';
import green from '@material-ui/core/colors/green';
import Typography from '@material-ui/core/Typography';
import Paper from '@material-ui/core/Paper';
import TextField from '@material-ui/core/TextField';
import DoneIcon from '@material-ui/icons/Done';
import CircularProgress from '@material-ui/core/CircularProgress';
import { withStyles } from '@material-ui/core/styles';

const styles = theme => ({
  root: {
    ...theme.mixins.gutters(),
    paddingTop: theme.spacing.unit * 2,
    paddingBottom: theme.spacing.unit * 2,
    width: '500px',
  },
  container: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 200,
  },
  button: {
    marginTop: theme.spacing.unit * 4,
  },
  buttonHidden: {
    marginTop: theme.spacing.unit * 4,
    visibility: 'hidden',
  },
  icon: {
    height: '3em',
    width: '3em',
    fill: theme.palette.primary.dark,
  },
  title: {
    marginBottom: 0,
    fontSize: 14,
    lineHeight: '36px',
    fontWeight: 'bold',
  },
  error: {
    backgroundColor: theme.palette.error.dark,
  },
  info: {
    backgroundColor: theme.palette.primary.dark,
  },
});

class Formulaire extends Component {
  static propTypes = {
    classes: PropTypes.object.isRequired,
    history: PropTypes.object.isRequired,
    openNotification: PropTypes.func.isRequired,
  };

  state = {
    error: null,
    submiting: false,
    justSaved: false,
    showMessage: false,
  };

  handleChange = e => {
    this.setState({ [e.target.name]: e.target.value, justSaved: false });
  };

  send = () => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        resolve();
      }, 500);
    });
  };

  handleSubmit = e => {
    e.preventDefault();
    const { history, onLoginSuccess, openNotification } = this.props;
    this.setState({ submiting: true });
    this.send()
      .then(() => {
        openNotification('success', 'Bail ajouté');
        history.push('/');
        this.setState({ submiting: false, justSaved: true });
      })
      .catch(e => {
        openNotification('error');
        this.setState({ submiting: false, justSaved: true, error: 'GRAHHHHH!' });
      });
  };

  handleCloseSnackbar = () => {
    console.log('close !');
    // this.setState({ showMessage: false });
  };

  render() {
    const { classes } = this.props;
    const { error, username, password, submiting, justSaved, showMessage } = this.state;
    return (
      <Centered spacing={16}>
        <Grid item>
          <Paper elevation={3} className={classes.root}>
            <Grid container alignItems="center" direction="row" justify="space-between">
              <Grid item>
                <Typography className={classes.title} color="textSecondary">
                  Ajouter un XXXXX
                </Typography>
              </Grid>
              <Grid item>
                {submiting && <CircularProgress size={25} />}
                {justSaved &&
                  !error && (
                    <span>
                      <DoneIcon color="primary" />
                    </span>
                  )}
                {justSaved &&
                  error && (
                    <span>
                      <DoneIcon color={green[600]} />
                    </span>
                  )}
              </Grid>
            </Grid>
            <form className={classes.container} onSubmit={this.handleSubmit}>
              <Grid container justify="center" alignItems="center" direction="row">
                <Grid item>
                  <TextField
                    label="Identifiant"
                    className={classes.textField}
                    value={username}
                    onChange={this.handleChange}
                    autoFocus
                    margin="normal"
                  />
                </Grid>
                <Grid item>
                  <TextField
                    label="Mot de passe"
                    className={classes.textField}
                    value={password}
                    onChange={this.handleChange}
                    margin="normal"
                  />
                </Grid>
                <Grid item>
                  <TextField
                    label="Identifiant"
                    className={classes.textField}
                    value={username}
                    onChange={this.handleChange}
                    margin="normal"
                  />
                </Grid>
                <Grid item>
                  <TextField
                    label="Mot de passe"
                    className={classes.textField}
                    value={password}
                    onChange={this.handleChange}
                    margin="normal"
                  />
                </Grid>{' '}
                <Grid item>
                  <TextField
                    label="Identifiant"
                    className={classes.textField}
                    value={username}
                    onChange={this.handleChange}
                    margin="normal"
                  />
                </Grid>
                <Grid item>
                  <TextField
                    label="Mot de passe"
                    className={classes.textField}
                    value={password}
                    onChange={this.handleChange}
                    margin="normal"
                  />
                </Grid>{' '}
                <Grid item>
                  <TextField
                    label="Identifiant"
                    className={classes.textField}
                    value={username}
                    onChange={this.handleChange}
                    margin="normal"
                  />
                </Grid>
                <Grid item>
                  <TextField
                    label="Mot de passe"
                    className={classes.textField}
                    value={password}
                    onChange={this.handleChange}
                    margin="normal"
                  />
                </Grid>{' '}
                <Grid item>
                  <TextField
                    label="Identifiant"
                    className={classes.textField}
                    value={username}
                    onChange={this.handleChange}
                    margin="normal"
                  />
                </Grid>
                <Grid item>
                  <TextField
                    label="Mot de passe"
                    className={classes.textField}
                    value={password}
                    onChange={this.handleChange}
                    margin="normal"
                  />
                </Grid>
              </Grid>

              <Button
                disabled={justSaved}
                variant="contained"
                color="primary"
                fullWidth
                className={justSaved ? classes.buttonHidden : classes.button}
                type="submit"
              >
                Se connecter
              </Button>
            </form>
          </Paper>
        </Grid>
      </Centered>
    );
  }
}

export default withRouter(withStyles(styles)(Formulaire));
