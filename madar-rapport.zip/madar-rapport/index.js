const pdf = require("html-pdf");
const express = require("express");
const axios = require("axios");
const fs = require("fs");
const app = express();
const uuidv4 = require('uuid/v4');
var cors = require("cors");
var exec = require("child_process").exec;

const viewEngine = require("express-react-views");
const render = viewEngine.createEngine({ presets: ["react", "es2015"] });

// c'est le backend qui génère le rapport
// protéger ce dossier avec une authentification apache2 basic
const destRapportFolder = "/var/www/prex.madar-patrimoine.2m-advisory.fr/public_html/files/export";

const urlAssets = "https://prex.rapports.madar-patrimoine.2m-advisory.fr/";
const cssUrl = "https://prex.madar-patrimoine.2m-advisory.fr/";
const rapportsUrl = cssUrl + 'public/index.php/rapports';

// protection par api-key
// mettre ici l'apiKey/token de l'user admin
axios.defaults.headers.common['x-api-key'] = "dkflsdkflsdmk";

app.use(cors({ origin: "*" }));

app.set("views", __dirname + "/views");
app.set("view engine", "jsx");

app.engine("jsx", render);

app.get("/synthese.:ext", (req, res) => {
  // suppression des pdfs générés précédemment
  exec("rm ./pdfs/*.pdf", function callback(errorF, stdout, stderr) {
    if (errorF) {
      console.log(errorF);
    }
    console.log(req.get('x-api-key'));
    const idsociete = req.query.idsociete || false;
    const banque = req.query.banque || false;
    let url = rapportsUrl + "/synthese";
    axios.get(url).then(response => {
    if (idsociete) {
      url += `?idsociete=${idsociete}`;
      if (banque) {
        url + `&idbanque=${banque}`;
      }
    } else {
      url += `?idbanque=${banque}`;
    }

    const datas = {
      settings: { env: "development", views: `${__dirname}/views` },
      sansDonneesFinancement: req.query.sansDonneesFinancement === "1",
      sansCouvertureDeTaux: req.query.sansCouvertureDeTaux === "1",
      idsociete,
      banque: banque,
      urlAssets,
      cssUrl
    };

    return render(`${__dirname}/views/synthese.jsx`, { ...datas, synthese: response.data.data }, (err, html) => {
      if (req.params.ext !== "pdf") {
        return res.send(html);
      }
      const options = {
        format: "A4",
        timeout: 60000,
        footer: {
          height: "10mm",
          contents: {
            first: "",
            default: `<div style="text-align: center;color: #444;font-size: 10px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Synthèse patrimoniale (total des actifs) ${
              idsociete === "1" ? " PARDES" : idsociete === "2" ? " FORUM" : ""
            }&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span>{{page}} / {{pages}}</span></div>`, // fallback value
          },
        },
      };
      if (err) {
        console.log(err);
        res.status(500).send(err);
        return;
      }
      pdf.create(html, options).toFile("./pdfs/synthese.pdf", function(err, result) {
        if (err) {
          console.log(err);
          res.status(500).send(err);
          return;
        }

        res.send({ data: "ok" });
      });
    });
    });
  });
});

app.get("/rapport_ca.:ext", (req, res) => {
  Promise.all([
    axios.get(rapportsUrl + "/activites"),
    axios.get(rapportsUrl + "/regions"),
    axios.get(rapportsUrl + "/arrondissements"),
  ]).then(([activites, regions, arrondissements]) => {
    return render(
      `${__dirname}/views/ca.jsx`,
      {
        settings: { env: "development", views: `${__dirname}/views` },
        activites: activites.data.data,
        regions: regions.data.data,
        arrondissements: arrondissements.data.data,
        urlAssets,
        cssUrl
      },
      (err, html) => {
        if (req.params.ext !== "pdf") {
          return res.send(html);
        }

        const options = {
          format: "A4",
          timeout: 320000,
        };

        if (err) {
          console.log(err);
          res.status(500).send(err);
          return;
        }

        pdf.create(html, options).toFile("./pdfs/rapport_ca.pdf", function(err, result) {
          // res.set("Content-Type", "application/pdf");
          // res.write(buffer, "binary");
          // res.end(null, "binary");
          if (err) {
            console.log(err);
            res.status(500).send(err);
            return;
          }

          res.send({ data: "ok" });
        });
      },
    );
  });
});

app.get("/rapport_vacants.:ext", (req, res) => {
  const idsociete = req.query.idsociete ? `&idsociete=${req.query.idsociete}` : "";
  const url = `${rapportsUrl}/synthese?type_de_bail=VACANT${idsociete}`;
  console.log("vacants", url);
  axios.get(url).then(vacants => {
    console.log("res", vacants);
    return render(
      `${__dirname}/views/vacants.jsx`,
      {
        settings: { env: "development", views: `${__dirname}/views` },
        vacants: vacants.data.data,
        idsociete,
        urlAssets,
        cssUrl
      },
      (err, html) => {
        if (req.params.ext !== "pdf") {
          return res.send(html);
        }
        const options = {
          format: "A4",
          timeout: 120000,
          footer: {
            height: "10mm",
            contents: {
              first: "",
              default: `<div style="text-align: center;color: #444;font-size: 10px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Etat des locaux prochainement disponibles ${
                idsociete === "1" ? " PARDES" : idsociete === "2" ? " FORUM" : ""
              }&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span>{{page}} / {{pages}}</span></div>`, // fallback value
            },
          },
        };
        if (err) {
          console.log(err);
          res.status(500).send(err);
          return;
        }
        pdf.create(html, options).toFile("./pdfs/rapport_vacants.pdf", function(err, result) {
          // pdf.create(html, options).toBuffer((err2, buffer) => {
          // res.set("Content-Type", "application/pdf");
          // res.write(buffer, "binary");
          // res.end(null, "binary");
          if (err) {
            console.log(err);
            res.status(500).send(err);
            return;
          }

          res.send({ data: "ok" });
        });
      },
    );
  });
});

app.get("/rapport_dscr.:ext", (req, res) => {
  const url1 = `${rapportsUrl}/totaldscr/1`;
  const url2 = `${rapportsUrl}/totaldscr/2`;
  
  axios.get(url1).then(response1 => {
      axios.get(url2).then(response2 => {
        return render(
        `${__dirname}/views/dscr.jsx`,
        {
            settings: { env: "development", views: `${__dirname}/views` },
            dscr1: response1.data.data,
            dscr2: response2.data.data,
            idsociete: req.query.idsociete ? parseInt(req.query.idsociete, 10) : "",
            urlAssets,
            cssUrl
        },
        (err, html) => {
            if (req.params.ext !== "pdf") {
            return res.send(html);
            }
            const options = { format: "A4", timeout: 120000 };

            if (err) {
            console.log(err);
            res.status(500).send(err);
            return;
            }

            /*pdf.create(html, options).toBuffer((err, buffer) => {
                if (err) {
                console.log(err);
                res.status(500).send(err);
                return;
                }
                res.set("Content-Type", "application/pdf");
                res.write(buffer, "binary");
                res.end(null, "binary");
            });*/
            pdf.create(html, options).toFile("./pdfs/rapport_dscr.pdf", function(err, result) {
                if (err) {
                    console.log(err);
                    res.status(500).send(err);
                    return;
                }

                if (req.query.action) { // téléchargement direct, on sert par apache
                    const commande = `cp ./pdfs/rapport_dscr.pdf ${destRapportFolder}/rapport_dscr.pdf`;
                    console.log(commande);
                    exec(commande, function callback(error, stdout, stderr) {
                        if (error) {
                        console.log(error);
                        res.status(500).send(error);
                        }
                        return res.send({ data: "ok" });
                    }); 
                } else {
                    return res.send({ data: "ok" });
                }
            });
        },
        );    
    })
  }).catch(function (error) {
    // handle error
    console.log(error);
    return res.status(500).send(error);
  });
});

app.get("/crd_banque.:ext", (req, res) => {
  axios
    .get(
      `${rapportsUrl}/crd${
        req.query.idbanque ? `?idbanque=${req.query.idbanque}` : ""
      }`,
    )
    .then(response => {
      return render(
        `${__dirname}/views/crd.jsx`,
        {
          settings: { env: "development", views: `${__dirname}/views` },
          crd: response.data.data,
          avecGraphique: req.query.idbanque ? false : true,
          urlAssets,
          cssUrl,
          idbanque: req.query.idbanque
        },
        (err, html) => {
          if (req.params.ext !== "pdf") {
            return res.send(html);
          }
          const options = { format: "A4", timeout: 120000 };
          if (err) {
            console.log(err);
            res.status(500).send(err);
            return;
          }
            pdf.create(html, options).toFile("./pdfs/crd_banque.pdf", function(err, result) {
              if (err) {
                console.log(err);
                res.status(500).send(err);
                return;
              }

              if (req.query.action) { // téléchargement direct, on sert par apache
                const commande = `cp ./pdfs/crd_banque.pdf ${destRapportFolder}/crd_banque.pdf`;
                console.log(commande);
                exec(commande, function callback(error, stdout, stderr) {
                    if (error) {
                    console.log(error);
                    res.status(500).send(error);
                    }
                    return res.send({ data: "ok" });
                });   
              } else {
                  return res.send({ data: "ok" });
              }
            });
        },
      );
    });
});

app.get("/synthese_generale.:ext", (req, res) => {
  axios.get(rapportsUrl + "/total").then(response => {
    return render(
      `${__dirname}/views/synthese_generale.jsx`,
      {
        settings: { env: "development", views: `${__dirname}/views` },
        datas: response.data.data,
        idsociete: req.query.idsociete,
        urlAssets,
        cssUrl
      },
      (err, html) => {
        if (req.params.ext !== "pdf") {
          return res.send(html);
        }
        const options = { format: "A4", timeout: 120000 };
        if (err) {
          console.log(err);
          res.status(500).send(err);
          return;
        }
        pdf.create(html, options).toFile("./pdfs/synthese_generale.pdf", function(err, result) {
          // res.set("Content-Type", "application/pdf");
          // res.write(buffer, "binary");
          // res.end(null, "binary");
          if (err) {
            console.log(err);
            res.status(500).send(err);
            return;
          }

          res.send({ data: "ok" });
        });
      },
    );
  });
});

app.get("/profil_remboursement.:ext", (req, res) => {
  let querysociete = '';
  if (req.query.idsociete) {
      querysociete =  `?idsociete=${req.query.idsociete}`;
  }
  console.log('url', rapportsUrl + "/total" + querysociete);
  axios.get(rapportsUrl + "/total" + querysociete).then(response => {
    return render(
      `${__dirname}/views/profil_remboursement.jsx`,
      {
        settings: { env: "development", views: `${__dirname}/views` },
        datas: response.data.data.echeancier[0],
        idsociete: req.query.idsociete,
        urlAssets,
        cssUrl
      },
      (err, html) => {
        if (req.params.ext !== "pdf") {
          return res.send(html);
        }
        const options = { format: "A4", timeout: 120000 };
        if (err) {
          console.log(err);
          res.status(500).send(err);
          return;
        }
        pdf.create(html, options).toFile("./pdfs/profil_remboursement.pdf", function(err, result) {
            const commande = `cp ./pdfs/profil_remboursement.pdf ${destRapportFolder}/profil_remboursement.pdf`;
            console.log(commande);
            exec(commande, function callback(error, stdout, stderr) {
                if (error) {
                  console.log(error);
                  res.status(500).send(error);
                }
                return res.send({ data: "ok" });
            });
        });
      },
    );
  }).catch(function(error) {
      console.log(error);
      if (error.response) {
      // The request was made and the server responded with a status code
      // that falls out of the range of 2xx
        console.log(error.response.data);
        console.log(error.response.status);
        console.log(error.response.headers);
        res.status(500).send(error.response.data);
    }
  });
});

app.get("/generate", (req, res, next) => {
  const code_secret = uuidv4();
  const synthese = __dirname + "/pdfs/synthese.pdf";
  const vacants = __dirname + "/pdfs/rapport_vacants.pdf";
  const synthese_generale = __dirname + "/pdfs/synthese_generale.pdf";
  const dscr = __dirname + "/pdfs/rapport_dscr.pdf";
  const rapport_ca = req.query.avecCrd ? __dirname + "/pdfs/crd_banque.pdf" : "";
  const rapport_crd = req.query.avecCa ? __dirname + "/pdfs/rapport_ca.pdf" : "";
  const destination =  destRapportFolder + `/synthese_complete.pdf`;
  const commande = `pdfunite ${synthese} ${vacants} ${synthese_generale} ${dscr} ${rapport_crd} ${rapport_ca} ${destination}`;
  console.log(commande);
  exec(commande, function callback(error, stdout, stderr) {
    if (error) {
      console.log(error);
      res.status(500).send(error);
    }
    res.send({ data: "ok" });
  });
});

app.listen(8083, () => console.log("Pdf renderer lancé sur le  port 8083!"));
