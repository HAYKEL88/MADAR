const React = require("react");
import NumberFormat from "react-number-format";

const nF = value => (
  <NumberFormat value={parseInt(value, 10)} displayType={"text"} thousandSeparator=" " suffix={" €"} />
);

class Vacants extends React.Component {
  getContent() {
    let noPage = 0;
    const vacants = this.props.vacants.map((item, idx) => {
      noPage++;
      return (
        <div key={item.idactifpatrimonial} style={noPage % 4 === 0 ? { pageBreakAfter: "always" } : {}}>
          <div className="row">
            <div className="col-xs-22">
              <div className="row">
                <div className="col-xs-6 titre-idactif">{item.idactifpatrimonial}</div>
                <div className="col-xs-18 titre-adresse">{item.adresse}</div>
              </div>
              <div className="row">
                <div className="col-xs-8 mT mB">
                  <div className="row bb">
                    <div className="col-xs-16">
                      <strong>Date d'acquisition</strong>
                    </div>
                    <div className="col-xs-8 txtR">{item.date_acquisition}</div>
                  </div>
                  <div className="row bb">
                    <div className="col-xs-16">
                      <strong>Surface de l'actif</strong>
                    </div>
                    <div className="col-xs-8 txtR">{item.surface} m²</div>
                  </div>
                  <div className="row bb">
                    <div className="col-xs-16">
                      <strong>Surface vacante</strong>
                    </div>
                    <div className="col-xs-8 txtR">
                      {item.info_bail
                        ? item.info_bail.reduce((m, b) => m + parseInt(b.surface_loue, 10), 0)
                        : "??"}{" "}
                      m²
                    </div>
                  </div>
                </div>
                <div className="col-xs-7 col-xs-offset-1 mT mB">
                  <div className="row bb" style={{ backgroundColor: "#fae2d4" }}>
                    <div className="col-xs-16">
                      <strong>Prix de revient</strong>
                    </div>
                    <div className="col-xs-8 txtR">{item.prix_de_revient} €</div>
                  </div>
                  <div className="row bb">
                    <div className="col-xs-16">
                      <strong>Travaux</strong>
                    </div>
                    <div className="col-xs-8 txtR">{item.travaux || 0} €</div>
                  </div>
                  {item.CRD && (
                    <div className="row bb">
                      <div className="col-xs-16">
                        <strong>CRD</strong>
                      </div>
                      <div className="col-xs-8 txtR">{item.CRD} €</div>
                    </div>
                  )}
                </div>
                <div className="col-xs-7 col-xs-offset-1 mBB">
                  <p style={{ padding: "0 1em" }}>
                    Commentaire : {item.commentaire ? item.commentaire : "aucun"}
                  </p>
                </div>
              </div>
            </div>
            <div className="col-xs-2">
              <img src="https://mjcdamville.fr/madar.png" alt="logo madar" height="auto" width="100%" />
            </div>
          </div>
          {item.info_bail &&
            item.info_bail.map(local => (
              <div className="row mB">
                <div className="col-xs-1 titre-ligne titre-lF">
                  <div>
                    {item.info_bail.length > 1 ? "LOCAUX" : "LOCAL"}&nbsp;VACANT{item.info_bail.length > 1
                      ? "S"
                      : ""}
                  </div>
                </div>
                <div className="col-xs-22 col-xs-offset-1 mBB">
                  <div className="row">
                    <div className="col-xs-18 col-xs-offset-4 titre-etat-locatif">
                      Local - {local.idlocal}
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-xs-7">
                      <div className="row bb">
                        <div className="col-xs-16">
                          <strong>Type de bail</strong>
                        </div>
                        <div className="col-xs-8 txtR">Commercial</div>
                      </div>
                      <div className="row bb">
                        <div className="col-xs-17">
                          <strong>Date effective de départ</strong>
                        </div>
                        <div className="col-xs-5 txtR">10/12/2018</div>
                      </div>
                    </div>
                    <div className="col-xs-4 col-xs-offset-1">
                      <div className="row bb">
                        <div className="col-xs-16">
                          <strong>Dernier loyer</strong>
                        </div>
                        <div className="col-xs-8 txtR">{nF(local.dernier_loyer)}</div>
                      </div>
                      <div className="row bb">
                        <div className="col-xs-16">
                          <strong>Valeur locative</strong>
                        </div>
                        <div className="col-xs-8 txtR">{nF(local.valeur_locative)}</div>
                      </div>
                    </div>
                    <div className="col-xs-5 col-xs-offset-1">
                      <div className="row bb">
                        <div className="col-xs-16">
                          <strong>Surface du local</strong>
                        </div>
                        <div className="col-xs-8 txtR">{local.surface_loue} m²</div>
                      </div>
                      <div className="row bb">
                        <div className="col-xs-16">
                          <strong>Etage</strong>
                        </div>
                        <div className="col-xs-8 txtR">{local.etage}</div>
                      </div>
                    </div>
                    <div className="col-xs-5 col-xs-offset-1">
                      <div className="row bb">
                        <div className="col-xs-16">
                          <strong>Extraction</strong>
                        </div>
                        <div className="col-xs-8 txtR">{local.etage === "" ? "non" : "oui"}</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
        </div>
      );
    });

    return vacants;
  }

  render() {
    return (
      <html lang="en" style={{ zoom: "0.55" }}>
        <head>
          <meta charSet="UTF-8" />
          <title>Facture</title>
          <link rel="stylesheet" href={`${this.props.cssUrl}rapport.css`} />
        </head>

        <body style={{ padding: "1em", fontSize: "1.4em" }}>{this.getContent()}</body>
      </html>
    );
  }
}

module.exports = Vacants;
