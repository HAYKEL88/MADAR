const React = require("react");
const NumberFormat = require("react-number-format");
const moment = require("moment");
const truncate = require("lodash/truncate");
moment.locale("fr");

const nF = value => (
  <NumberFormat
    value={parseInt(value, 10)}
    displayType={"text"}
    thousandSeparator=" "
    suffix={" €"}
  />
);

const typesCaution = [
  "caution_garantie_premiere_demande",
  "caution_garantie_solvabilite",
  "caution_societe",
  "caution_perso",
  "caution_bancaire"
];

const x = v => v && parseInt(v, 10) !== 0;

// const queries = document.location.search.replace("?", "").split("&");
// const sansDonneesFinancement = queries[0] && queries[0].split("=")[1] === "1";
// const sansCouverture = queries[1] && queries[1].split("=")[1] === "1";
class Local extends React.Component {
  ajouteInsert(titre) {
    return (
      <div style={{ paddingTop: "1em" }}>
        <div
          className="row pageDeGarde txtC"
          style={{
            border: "solid 2px #840216",
            minHeight: "1795px"
          }}
        >
          <img
            src={`${this.props.urlAssets}madar_big.png`}
            alt="logo"
            width="60%"
          />
          <h1 style={{fontSize: '2em'}}>{titre}</h1>
        </div>
      </div>
    );
  }

  getContent() {
    const { sansDonneesFinancement, sansCouvertureDeTaux } = this.props;
    const actuel = 1000;
    const facial = 1200;
    const potentiel = 800;
    const ltv = 92;
    const ltc = 72;
    const datas = this.props.synthese;
    let noPage = 0;
    let i = 0;
    let nbre = 0;

    console.log('sansDonneesFinancement ' + sansDonneesFinancement + ' ' + sansCouvertureDeTaux);

    if (!sansDonneesFinancement) {
      do {
        //console.log(" actif " + (datas[i] ? datas[i].idactifpatrimonial : "null"));
        if (datas[i] && datas[i].info_bail) {
          datas[i].marge = true;
          //console.log("---" + datas[i].info_bail.length);
          if (datas[i].info_bail.length > 4) {
            datas[i].info_bail[datas[i].info_bail.length - 1].saut = true;
            //console.log("saut de page ---------------------------------");
          }
        }
        // si bien suivant à + de 4 biens
        if (datas[i].info_bail && datas[i + 1] && datas[i + 1].info_bail && datas[i + 1].info_bail[datas[i].info_bail.length - 1] && datas[i + 1].info_bail.length > 4) {
          datas[i + 1].info_bail[datas[i].info_bail.length - 1].saut = true;
          //console.log("saut de page ---------------------------------");
        }
        i++;
        //console.log(" actif " + (datas[i] ? datas[i].idactifpatrimonial : "null"));
        if (datas[i] && datas[i].info_bail) {
          //console.log("---" + datas[i].info_bail.length);
          if ( datas[i].info_bail[datas[i].info_bail.length - 1] && datas[i].info_bail.length > 4) {
            datas[i].info_bail[datas[i].info_bail.length - 1].saut = true;
            //console.log("saut de page ---------------------------------");
          }
        }

        // essayer d'ajouter un troisième actif si les deux précédent ont un seul local
        // et si le suivant à aussi un seul local
        if (datas[i + 1]) {
          if (
            !datas[i].info_bail ||
            !datas[i - 1].info_bail ||
            !datas[i + 1].info_bail ||
            (datas[i].info_bail.length === 1 &&
              datas[i - 1].info_bail.length === 1 &&
              datas[i + 1].info_bail.length === 1)
          ) {
            i++;
            //console.log(" actif " + (datas[i] ? datas[i].idactifpatrimonial : "null"));
            if (datas[i] && datas[i].info_bail) {
              //console.log("---" + datas[i].info_bail.length);
            }
          }
        }
        if (datas[i] && datas[i].info_bail && datas[i].info_bail[datas[i].info_bail.length - 1] && datas[i].info_bail[datas[i].info_bail.length - 1]) {
          datas[i].info_bail[datas[i].info_bail.length - 1].saut = true;
        }
        //console.log("saut de page ---------------------------------");
        i++;
      } while (i < datas.length);
    } else {
        do {
            datas[i].marge = true;
            do {
                console.log(" actif " + (datas[i] ? datas[i].idactifpatrimonial : "null"));
                nbre += datas[i].info_bail ? datas[i].info_bail.length : 1;
                i++;
            } while (datas[i] && nbre < 4);
            if (datas[i] && datas[i].info_bail) {
                datas[i].info_bail[datas[i].info_bail.length - 1].saut = true;
                console.log("saut de page ---------------------------------");
            }
            nbre = 0;
        } while (i < datas.length);
    }
    
    
    const report = datas.map((item, index) => {
      noPage++;
      const prctCrd = parseInt(
        (parseInt(item.crd, 10) * 100) / parseInt(item.montant_financement, 10),
        10
      );
      const prctDuree =
        x(item.duree_initiale) && x(item.duree_residuelle_financement)
          ? parseInt(
              (parseInt(item.duree_residuelle_financement, 10) * 100) /
                parseInt(item.duree_initiale, 10),
              10
            )
          : 0;

      const finArr =
        item.code_postal &&
        datas[index + 1] &&
        datas[index + 1].code_postal &&
        item.code_postal.indexOf("75") !== -1 &&
        datas[index + 1].code_postal.indexOf("75") !== -1 &&
        item.code_postal !== datas[index + 1].code_postal;

      const finParis = item.setorder === 1 && datas[index + 1] === 2;

      const finIdf =
        item.setorder === 2 && datas[index + 1] && datas[index + 1] === 3;

      let { dscr_actuel, dscr_facial, dscr_potentiel, ltv, ltc } = item;

      // à retirer après l'importation des données
      if (dscr_actuel > 250) dscr_actuel = 250;
      if (dscr_facial > 250) dscr_facial = 250;
      if (dscr_potentiel > 250) dscr_potentiel = 250;
      if (ltv > 250) ltv = 250;
      if (ltc > 250) ltc = 250;
                         
      const pasDeGraph = dscr_actuel === '0' && dscr_facial === '0' && dscr_potentiel === '0' && ltv === '0' && ltc === '0';

      return [
        index === 0 ? this.ajouteInsert("Paris") : null,
        item.setorder === 2 && datas[index - 1].setorder === 1
          ? this.ajouteInsert("Ile de France (hors Paris)")
          : null,
        item.setorder === 3 && datas[index - 1].setorder === 2
          ? this.ajouteInsert("Province")
          : null,
        <div
          key={item.idactifpatrimonial}
        >
          <div
            className="row titre">
            <div className="col-xs-22"             style={
              //noPage % 2 === 0 && item.info_bail && item.info_bail.length === 1
              item.marge || index === 0 ? { paddingTop: "0.5em" }
                : {}
            }>
              <div className="row">
                <div className="col-xs-3 titre-idactif">
                  {item.idactifpatrimonial}
                </div>
                <div className="col-xs-21 titre-adresse">
                  {truncate(
                    `${item.adresse} ${item.code_postal} ${item.ville}`,
                    { length: 45 }
                  )}
                </div>
                <div className="col-xs-8 mT mBb">
                  <div className="row bb">
                    <div className="col-xs-16">
                      <strong>Date d'acquisition</strong>
                    </div>
                    <div className="col-xs-8 txtR">{item.date_acquisition}</div>
                  </div>
                  {x(item.surface) && (
                    <div className="row bb">
                      <div className="col-xs-16">
                        <strong>Surface</strong>
                      </div>
                      <div className="col-xs-8 txtR">{item.surface} m²</div>
                    </div>
                  )}
                </div>
                <div className="col-xs-7 col-xs-offset-1 mT mBb">
                  {x(item.prix_de_revient) && (
                    <div
                      className="row bb"
                      style={{ backgroundColor: "#fae2d4" }}
                    >
                      <div className="col-xs-16">
                        <strong>Prix de revient</strong>
                      </div>
                      <div className="col-xs-8 txtR">
                        {nF(item.prix_de_revient)}
                      </div>
                    </div>
                  )}
                  {x(item.taux_capitalisation) && (
                    <div className="row bb">
                      <div className="col-xs-16">
                        <strong>
                          Taux de capitalisation{item.taux_capitalisation ==
                            "0"}
                        </strong>
                      </div>
                      <div className="col-xs-8 txtR">
                        {item.taux_capitalisation} %
                      </div>
                    </div>
                  )}
                </div>
                <div
                  className="col-xs-7 col-xs-offset-1 mT mBb"
                  style={{ paddingRight: "1em" }}
                >
                  <div className="row bb">
                    <div className="col-xs-12">
                      <strong>Nom expert</strong>
                    </div>
                    <div className="col-xs-12 txtR">{item.nom_expert}</div>
                  </div>
                  {x(item.valeur_expertise) && (
                    <div className="row bb">
                      <div className="col-xs-16">
                        <strong>Valeur d'expertise</strong>
                      </div>
                      <div className="col-xs-8 txtR">
                        {nF(item.valeur_expertise)}
                      </div>
                    </div>
                  )}
                  {x(item.valeur_venale) && (
                    <div className="row bb">
                      <div className="col-xs-12">
                        <strong>Valeur vénale</strong>
                      </div>
                      <div className="col-xs-12 txtR">
                        {nF(item.valeur_venale)}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
            <div className="col-xs-2 txtC">
              <img
                src={`${this.props.urlAssets}madar.png`}
                alt="logo madar"
                height="auto"
                width="60%"
              />
            </div>
          </div>
          {!sansDonneesFinancement && (
            <div className="row mB">
              <div className="col-xs-1 titre-ligne titre-lF">
                <div>FINANCEMENT</div>
              </div>
              {item.crd &&
                x(item.crd) &&
                x(item.duree_initiale) && (
                  <div className="col-xs-8">
                    <div className="row">
                      <div className="col-xs-24 txtC">
                        <img src={`${this.props.urlAssets}/banques/${item.banque}.png`} height="25" />
                      </div>
                      <div
                        className="col-xs-23 col-xs-offset-1 roundedBox"
                        style={{ fontSize: "0.9em" }}
                      >
                        <div className="row">
                          {item.crd &&
                            x(item.crd) && (
                              <div className="col-xs-8 montantInitial">
                                Montant initial
                              </div>
                            )}
                          {item.crd &&
                            x(item.crd) && (
                              <div className="col-xs-16 txtC">
                                <div className="row">
                                  <div className="col-xs-18 col-xs-offset-3">
                                    CRD {nF(item.crd)}
                                  </div>
                                  <div className="col-xs-18 col-xs-offset-3">
                                    <div className="progressOuter">
                                      <div
                                        className="progressInner blue"
                                        style={{ width: `${prctCrd}%` }}
                                      >
                                        {" "}
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                <div className="col-xs-12 montantMin">0 €</div>
                                <div className="col-xs-12 txtR">
                                  {nF(item.montant_financement)}
                                </div>
                              </div>
                            )}
                          {x(item.duree_initiale) &&
                            x(item.duree_residuelle_financement) && (
                              <div className="row">
                                <div className="col-xs-8 dureeInit">
                                  Durée initiale
                                </div>
                                <div className="col-xs-16 txtC">
                                  <div className="row">
                                    <div className="col-xs-18 col-xs-offset-3">
                                      Durée résiduelle{" "}
                                      {item.duree_residuelle_financement} mois
                                    </div>
                                    <div className="col-xs-18 col-xs-offset-3">
                                      <div className="progressOuter">
                                        <div
                                          className="progressInner blue"
                                          style={{ width: `${prctDuree}%` }}
                                        >
                                          {" "}
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="col-xs-12 anneeMin">
                                    0 mois
                                  </div>
                                  <div
                                    className="col-xs-12 txtR"
                                    style={{ paddingRight: 15 }}
                                  >
                                    {item.duree_initiale} mois
                                  </div>
                                </div>
                              </div>
                            )}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              {x(item.marge_taux_variable) && (
                <div className="col-xs-6 col-xs-offset-1">
                  <div className="row mB">
                    {x(item.marge_taux_variable) && (
                      <div className="col-xs-16 bb bl bp bt">
                        <strong>Marge sur taux variable</strong>
                      </div>
                    )}
                    {x(item.marge_taux_variable) && (
                      <div className="col-xs-8 bb bl br bt txtR">
                        {item.marge_taux_variable} %
                      </div>
                    )}
                    {x(item.charge_emprunt) && (
                      <div className="col-xs-16 bl bb br">
                        <strong>Charge d'emprunt</strong>
                      </div>
                    )}
                    {x(item.charge_emprunt) && (
                      <div className="col-xs-8 br bb txtR">
                        {nF(item.charge_emprunt)} / ans
                      </div>
                    )}
                  </div>
                  {x(item.strike_cap) &&
                    !sansCouvertureDeTaux && (
                      <div className="row">
                        <div className="col-xs-24">
                          <div className="col-xs-24 titreCouv txtC">
                            Couverture de taux
                          </div>
                          {x(item.notionnel_cap) && (
                            <div className="col-xs-12 bl br bb">
                              <strong>Notionnel de CAP</strong>
                            </div>
                          )}
                          {x(item.notionnel_cap) && (
                            <div className="col-xs-12 bl br bb txtR">
                              {nF(item.notionnel_cap)}
                            </div>
                          )}
                          {x(item.strike_cap) && (
                            <div className="col-xs-12 bl br bb">
                              <strong>Strike de CAP</strong>
                            </div>
                          )}
                          {x(item.strike_cap) && (
                            <div className="col-xs-12 bl br bb txtR">
                              {item.strike_cap} %
                            </div>
                          )}
                          {item.date_debut_cap && (
                            <div className="col-xs-12 bl br bb">
                              <strong>Date de début</strong>
                            </div>
                          )}
                          {item.date_debut_cap && (
                            <div className="col-xs-12 bl br bb txtR">
                              {item.date_debut_cap}
                            </div>
                          )}
                          {x(item.duree_cap) && (
                            <div className="col-xs-12 bl br bb">
                              <strong>Durée CAP</strong>
                            </div>
                          )}
                          {x(item.duree_cap) && (
                            <div className="col-xs-12 bl br bb txtR">
                              {item.duree_cap} ans
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                </div>
              )}
              {!pasDeGraph && (<div
                className="col-xs-8 txtC"
                id="graphique"
                style={{ position: "relative", height: "150px" }}
              >
                <div
                  style={{
                    position: "absolute",
                    bottom: 0,
                    left: 40,
                    width: 10,
                    height: 10,
                    backgroundColor: "cyan"
                  }}
                />
                <div style={{ position: "absolute", left: 52, bottom: -5 }}>
                  Actuel
                </div>
                <div
                  style={{
                    position: "absolute",
                    bottom: 0,
                    left: 95,
                    width: 10,
                    height: 10,
                    backgroundColor: "blue"
                  }}
                />
                <div style={{ position: "absolute", left: 107, bottom: -5 }}>
                  Facial
                </div>
                <div
                  style={{
                    position: "absolute",
                    bottom: 0,
                    left: 150,
                    width: 10,
                    height: 10,
                    backgroundColor: "orange"
                  }}
                />
                <div style={{ position: "absolute", left: 163, bottom: -5 }}>
                  Potentiel
                </div>
                <div
                  style={{
                    position: "absolute",
                    bottom: 0,
                    left: 250,
                    width: 10,
                    height: 10,
                    backgroundColor: "blue"
                  }}
                />
                <div style={{ position: "absolute", left: 265, bottom: -5 }}>
                  LTV
                </div>
                <div
                  style={{
                    position: "absolute",
                    bottom: 0,
                    left: 295,
                    width: 10,
                    height: 10,
                    border: "solid 1px black",
                    backgroundColor: "orange"
                  }}
                />
                <div style={{ position: "absolute", left: 310, bottom: -5 }}>
                  LTC
                </div>
                <div
                  id="actuel_bar"
                  style={{
                    position: "absolute",
                    width: "30px",
                    bottom: 15,
                    left: 70,
                    height: parseInt(dscr_actuel / 3, 10),
                    backgroundColor: "cyan"
                  }}
                />
                {dscr_actuel !== "0" && (
                  <div
                    style={{
                      position: "absolute",
                      bottom: parseInt(dscr_actuel / 3, 10) + 15,
                      left: 70,
                      fontSize: "9px"
                    }}
                  >
                    {parseInt(dscr_actuel, 10)} %
                  </div>
                )}
                <div
                  id="facial_bar"
                  style={{
                    position: "absolute",
                    width: "30px",
                    bottom: 15,
                    left: 105,
                    height: parseInt(dscr_facial / 3, 10),
                    backgroundColor: "blue"
                  }}
                />
                {dscr_facial !== "0" && (
                  <div
                    style={{
                      position: "absolute",
                      bottom: parseInt(dscr_facial / 3, 10) + 15,
                      left: 105,
                      fontSize: "9px"
                    }}
                  >
                    {parseInt(dscr_facial, 10)} %
                  </div>
                )}
                <div
                  id="potentiel_bar"
                  style={{
                    position: "absolute",
                    width: "30px",
                    bottom: 15,
                    left: 140,
                    height: parseInt(dscr_potentiel / 3, 10),
                    backgroundColor: "orange"
                  }}
                />
                {dscr_potentiel !== "0" && (
                  <div
                    style={{
                      position: "absolute",
                      bottom: parseInt(dscr_potentiel / 3, 10) + 15,
                      left: 140,
                      fontSize: "9px"
                    }}
                  >
                    {parseInt(dscr_potentiel, 10)} %
                  </div>
                )}
                <div
                  id="LTV_bar"
                  style={{
                    position: "absolute",
                    width: "30px",
                    bottom: 15,
                    left: 255,
                    height: parseInt(ltv / 3, 10),
                    backgroundColor: "blue"
                  }}
                />
                {ltv !== "0" && (
                  <div
                    style={{
                      position: "absolute",
                      bottom: parseInt(ltv / 3, 10) + 15,
                      left: 255,
                      fontSize: "9px"
                    }}
                  >
                    {parseInt(ltv, 10)} %
                  </div>
                )}
                <div
                  id="LTC_bar"
                  style={{
                    position: "absolute",
                    width: "30px",
                    bottom: 15,
                    left: 290,
                    height: parseInt(ltc / 3, 10),
                    backgroundColor: "orange"
                  }}
                />
                {ltv !== "0" && (
                  <div
                    style={{
                      position: "absolute",
                      bottom: parseInt(ltc / 3, 10) + 15,
                      left: 295,
                      fontSize: "9px"
                    }}
                  >
                    {parseInt(ltc, 10)} %
                  </div>
                )}
                <div
                  id="titre_dscr"
                  style={{
                    position: "absolute",
                    top: 20,
                    left: 45,
                    fontSize: 16,
                    width: 150
                  }}
                >
                  DSCR
                </div>
              </div>)}
            </div>
          )}
          {item.info_bail &&
            item.info_bail.map(bail => (
              <div className="row"  style={bail.saut || finArr ? { pageBreakAfter: "always" } : {}}>
                <div className="col-xs-1 titre-ligne titre-lEl">
                  <div>&nbsp;&nbsp;ETAT&nbsp;LOCATIF</div>
                </div>
                <div className="col-xs-23">
                  <div className="row">
                    <div className="col-xs-5">
                      <div className="row padHoriz">
                        {x(bail.loyer_actuel) && (
                          <div className="col-xs-12 bb">
                            <strong>Loyer actuel</strong>
                          </div>
                        )}
                        {x(bail.loyer_actuel) && (
                          <div className="col-xs-12 bb txtR">
                            {nF(bail.loyer_actuel)}
                          </div>
                        )}
                        {x(bail.revenu_facial) && (
                          <div className="col-xs-13 bb">
                            <strong>Revenu facial</strong>
                          </div>
                        )}
                        {x(bail.revenu_facial) && (
                          <div className="col-xs-11 bb txtR">
                            {nF(bail.revenu_facial)}
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="col-xs-6">
                      <div className="row padHoriz">
                        {x(bail.complement_loyer) && (
                          <div className="col-xs-16 bb">
                            <strong>Compl. de loyer</strong>
                          </div>
                        )}
                        {x(bail.complement_loyer) && (
                          <div className="col-xs-8 bb txtR">
                            {nF(bail.complement_loyer)}
                          </div>
                        )}
                        {x(bail.valeur_locative) && (
                          <div className="col-xs-14 bb">
                            <strong>Valeur locative</strong>
                          </div>
                        )}
                        {x(bail.valeur_locative) && (
                          <div className="col-xs-10 txtR bb">
                            {nF(bail.valeur_locative)}
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="col-xs-6">
                      <div className="row padHoriz">
                        {x(bail.potentiel_reversion) && (
                          <div className="col-xs-18 bb">
                            <strong>Potentiel de reversion</strong>
                          </div>
                        )}
                        {x(bail.potentiel_reversion) && (
                          <div className="col-xs-6 bb txtR">
                            {bail.potentiel_reversion}
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="col-xs-7">
                      <div className="row">
                        {x(bail.revenus_facial_CRD) && (
                          <div className="col-xs-16 bb">
                            <strong>Revenu facial / CRD</strong>
                          </div>
                        )}
                        {x(bail.revenus_facial_CRD) && (
                          <div className="col-xs-8 bb txtR">
                            {bail.revenus_facial_CRD}%
                          </div>
                        )}
                        {x(bail.revenus_facial_investissement) && (
                          <div className="col-xs-18 bb">
                            <strong>Revenu facial / Invest. initial</strong>
                          </div>
                        )}
                        {x(bail.revenus_facial_investissement) && (
                          <div className="col-xs-6 bb txtR">
                            {bail.revenus_facial_investissement}%
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-xs-22 col-xs-offset-1">
                      <div className="row etat-locatif">
                        <div className="col-xs-18 col-xs-offset-4 titre-etat-locatif">
                          Local - {bail.idlocal}
                        </div>
                        <div className="col-xs-7 panel">
                          <div className="row">
                            <div className="col-xs-12 bb">
                              <strong>Nom du locataire</strong>
                            </div>
                            <div className="col-xs-12 bb txtR">
                              {truncate(bail.nom_locataire, { length: 13 })}
                            </div>
                            {x(bail.surface_loue) && (
                              <div className="col-xs-12 bb">
                                <strong>Surface louée</strong>
                              </div>
                            )}
                            {x(bail.surface_loue) && (
                              <div className="col-xs-12 bb txtR">
                                {bail.surface_loue} m²
                              </div>
                            )}
                            {x(bail.etage) && (
                              <div className="col-xs-12 bb">
                                <strong>Étage(s)</strong>
                              </div>
                            )}
                            {x(bail.etage) && (
                              <div className="col-xs-12 bb txtR">
                                {bail.etage}
                              </div>
                            )}
                            <div className="col-xs-12 bb">
                              <strong>Nombre parking</strong>
                            </div>
                            <div className="col-xs-12 bb txtR">
                              {bail.nombre_parking}
                            </div>
                            <div className="col-xs-12 bb">
                              <strong>Extraction</strong>
                            </div>
                            <div className="col-xs-12 bb txtR">
                              {bail.extraction ? bail.extraction : "non"}
                            </div>
                          </div>
                        </div>
                        <div className="col-xs-7 col-xs-offset-1 panel">
                          <div className="row">
                            <div className="col-xs-8 bb">
                              <strong>Bail</strong>
                            </div>
                            <div className="col-xs-16 bb txtR">
                              {bail.bail_en_cours.toLowerCase()}
                            </div>
                            {bail.date_entree_locataire && (
                              <div className="col-xs-16 bb">
                                <strong>Date d'entrée</strong>
                              </div>
                            )}
                            {bail.date_entree_locataire && (
                              <div className="col-xs-8 bb txtR">
                                {bail.date_entree_locataire}
                              </div>
                            )}
                            {bail.date_effet_bail && (
                              <div className="col-xs-16 bb">
                                <strong>Date d'effet</strong>
                              </div>
                            )}
                            {bail.date_effet_bail && (
                              <div className="col-xs-8 bb txtR">
                                {bail.date_effet_bail}
                              </div>
                            )}
                            {bail.date_prochain_break && (
                              <div className="col-xs-16 bb">
                                <strong>Date du prochain break</strong>
                              </div>
                            )}
                            {bail.date_prochain_break && (
                              <div className="col-xs-8 bb txtR">
                                {bail.date_prochain_break}
                              </div>
                            )}
                            {bail.date_fin_bail && (
                              <div className="col-xs-16 bb">
                                <strong>Date de fin</strong>
                              </div>
                            )}
                            {bail.date_fin_bail && (
                              <div className="col-xs-8 bb txtR">
                                {bail.date_fin_bail}
                              </div>
                            )}
                            {bail.duree_preavis && (
                              <div className="col-xs-16 bb">
                                <strong>Durée du préavis</strong>
                              </div>
                            )}
                            {bail.duree_preavis && (
                              <div className="col-xs-8 bb txtR">
                                {bail.duree_preavis} ans
                              </div>
                            )}
                            {bail.depot_de_garantie && (
                              <div className="col-xs-16 bb">
                                <strong>Dépot de garantie</strong>
                              </div>
                            )}
                            {bail.depot_de_garantie && (
                              <div className="col-xs-8 bb txtR">
                                {nF(bail.depot_de_garantie)}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="col-xs-8 col-xs-offset-1 panel">
                          <div className="row">
                            {bail.bail_en_cours === "VACANT" &&
                              x(bail.loyer_sur_vacant) && (
                                <div className="col-xs-16 bb">
                                  <strong>Loyer sur vacant</strong>
                                </div>
                              )}
                            {bail.bail_en_cours === "VACANT" &&
                              x(bail.loyer_sur_vacant) && (
                                <div className="col-xs-8 bb txtR">
                                  {nF(bail.loyer_sur_vacant)}
                                </div>
                              )}
                            {bail.bail_en_cours !== "VACANT" &&
                              x(bail.loyer_actuel) && (
                                <div className="col-xs-16 bb">
                                  <strong>Loyer actuel</strong>
                                </div>
                              )}
                            {bail.bail_en_cours !== "VACANT" &&
                              x(bail.loyer_actuel) && (
                                <div className="col-xs-8 bb txtR">
                                  {nF(bail.loyer_actuel)}
                                </div>
                              )}
                            {bail.bail_en_cours !== "VACANT" &&
                              x(bail.complement_loyer) && (
                                <div className="col-xs-16 bb">
                                  <strong>Complément loyer</strong>
                                </div>
                              )}
                            {bail.bail_en_cours !== "VACANT" &&
                              x(bail.complement_loyer) && (
                                <div className="col-xs-8 bb txtR">
                                  {nF(bail.complement_loyer)}
                                </div>
                              )}
                            {x(bail.loyer_facial_acte) && (
                              <div className="col-xs-16 bb">
                                <strong>Loyer facial</strong>
                              </div>
                            )}
                            {x(bail.loyer_facial_acte) && (
                              <div className="col-xs-8 bb txtR">
                                {nF(bail.loyer_facial_acte)}
                              </div>
                            )}
                            {x(bail.valeur_locative) && (
                              <div className="col-xs-16 bb">
                                <strong>Valeur locative</strong>
                              </div>
                            )}
                            {x(bail.valeur_locative) && (
                              <div className="col-xs-8 bb txtR">
                                {nF(bail.valeur_locative)}
                              </div>
                            )}
                            {typesCaution.map(field => {
                              if (!bail[field] || !x(bail.caution_perso)) {
                                return null;
                              }
                              return [
                                <div className="col-xs-16 bb">
                                  <strong>{field.replace("_", " ")}</strong>
                                </div>,
                                <div className="col-xs-8 bb txtR">
                                  {nF(bail[field])}
                                </div>
                              ];
                            })}
                            {bail.charges_refacturees && (
                              <div className="col-xs-16 bb">
                                <strong>Charges refacturées</strong>
                              </div>
                            )}
                            {bail.charges_refacturees && (
                              <div className="col-xs-8 bb txtR">
                                {bail.charges_refacturees}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
        </div>
      ];
      noPage++;
    });

    return report;
  }

  render() {
    const titre1 = "SYNTHESE PATRIMONIALE ";
    let titre2 = "(Total des actifs)";
    if (this.props.idsociete === "1") titre2 = "PARDES Patrimoine";
    if (this.props.idsociete === "2") titre2 = "FORUM Patrimoine";
    const titre3 = this.props.banque ? this.props.banque : "";
    return (
      <html lang="en" style={{ zoom: "0.45" }}>
        <head>
          <meta charSet="UTF-8" />
          <title>Facture</title>
          <link rel="stylesheet" href={`${this.props.cssUrl}rapport.css`} />
        </head>

        <body style={{ padding: "1em", fontSize: "1.3em" }}>
          <div
            className="row pageDeGarde txtC"
            style={{
              border: "solid 2px #840216",
              minHeight: "1795px",
              paddingTop: "8em"
            }}
          >
            <img
              src={`${this.props.urlAssets}madar_big.png`}
              alt="logo"
              width="60%"
              height="auto"
            />
            {titre1 && <h1 style={{fontSize: '2em'}}>{titre1}</h1>}
            {titre2 && <h2>{titre2}</h2>}
            {titre3 !== "" && <h3>{titre3}</h3>}
            <div style={{ paddingTop: "600px" }}>
              <h2>MAJ du {moment().format("DD MMMM YYYY")}</h2>
            </div>
          </div>
          {this.getContent()}
        </body>
      </html>
    );
  }
}

module.exports = Local;
