const React = require("react");
import NumberFormat from "react-number-format";
var round = require("lodash/round");
const nF = value => (
  <NumberFormat
    value={parseInt(value, 10)}
    displayType={"text"}
    thousandSeparator=" "
    suffix={" €"}
  />
);

// const queries = document.location.search.replace("?", "").split("&");
// const sansDonneesFinancement = queries[0] && queries[0].split("=")[1] === "1";
// const sansCouverture = queries[1] && queries[1].split("=")[1] === "1";
class Local extends React.Component {
  render() {
    const { datas, idsociete } = this.props;
    const [dscr_actuel, dscr_facial, dscr_potentiel, ltv, ltc] = [
      26,
      72,
      250,
      145,
      36
    ];
    
    let societe = 'PARDES & FORUM';
    if (idsociete) {
        societe = idsociete === '1' ? 'PARDES' : 'FORUM';  
    }
    //idsociete === 1 ? 'PARDES' : 'FORUM";
    console.log(idsociete);
    
    return (
      <html lang="en" style={{ zoom: "0.55" }}>
        <head>
          <meta charSet="UTF-8" />
          <title>CA Activités</title>
          <link rel="stylesheet" href={`${this.props.cssUrl}rapport.css`} />
        </head>
        <body style={{ padding: "1em", fontSize: "1.3em" }}>
          <div className="row">
            <div className="col-xs-22">
              <div className="row">
                <div className="col-xs-24 titre-adresse">
                  Profil Remboursement {societe}
                </div>
              </div>
            </div>
            <div className="col-xs-2" style={{ position: "relative" }}>
              <div style={{ position: "absolute" }}>
                <img src={`${this.props.urlAssets}madar.png`} alt="logo madar" height="auto" width="60%" />
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-xs-24 txtC">
              <img src={`http://localhost:8084/synthese_generale_echeancier.png?idsociete=${idsociete}`} />
            </div>
            <div className="col-xs-20 col-xs-offset-2">
              <table className="tableDscr">
                <thead>
                  <tr>
                    <th className="thDscr">Année</th>
                    <th className="thDscr">Échéance</th>
                    <th className="thDscr">Capital restant</th>
                  </tr>
                </thead>
                <tbody>
                  {Object.keys(datas)
                    .filter(k => datas[k].echeance !== null)
                    .map(k => (
                      <tr>
                        <td className="tdDscr">{k}</td>
                        <td className="tdDscr">{nF(datas[k].echeance)}</td>
                        <td className="tdDscr">{nF(datas[k].capital_restant)}</td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </body>
      </html>
    );
  }
}

module.exports = Local;
