const React = require("react");
import NumberFormat from "react-number-format";
import truncate from "lodash/truncate";

// const queries = document.location.search.replace("?", "").split("&");
// const sansDonneesFinancement = queries[0] && queries[0].split("=")[1] === "1";
// const sansCouverture = queries[1] && queries[1].split("=")[1] === "1";
class Local extends React.Component {
  render() {
    return (
      <html lang="en" style={{ zoom: "0.55" }}>
        <head>
          <meta charSet="UTF-8" />
          <title>CA Activités</title>
          <link rel="stylesheet" href={`${this.props.cssUrl}rapport.css`} />
        </head>
        <body style={{ padding: "1em", fontSize: "1.4em" }}>
          <div className="row" className="titre">
            <div className="col-xs-22 titre-adresse txtC">CA Région, Arrondissement, Activité</div>
            <div className="col-xs-2">
              <img src={`${this.props.urlAssets}madar.png`} alt="logo madar" height="auto" width="100%" />
            </div>
          </div>
          <div className="row">
            <div className="col-xs-8" style={{ fontSize: "1.4em", padding: 10 }}>
              CA par activité
            </div>
            <div className="col-xs-16 mT">
              <div style={{ width: "100%", height: "20px", backgroundColor: "#efe4b0" }} />
            </div>
          </div>
          <div className="row">
            <div className="col-xs-8" style={{ fontSize: "0.8em" }}>
              <div className="row" style={{ marginTop: "50px" }}>
                <div className="col-xs-18 bb titreCouv">Type activité</div>
                <div className="col-xs-6 txtR bb titreCouv">Loyer</div>
              </div>
              {this.props.activites.map(a => (
                <div className="row">
                  <div className="col-xs-18 bb">
                    {a.activite !== null ? truncate(a.activite, { length: 35 }) : "Divers"}
                  </div>
                  <div className="col-xs-6 txtR bb">
                    <NumberFormat
                      value={a.loyer_total}
                      displayType={"text"}
                      thousandSeparator={" "}
                      suffix={" €"}
                      decimalScale={0}
                    />
                  </div>
                </div>
              ))}
            </div>
            <div className="col-xs-16 txtC">
              <img src="http://localhost:8080/ebdcf383-63a6-4bc4-8dea-bf93e9f7c17b/ca_activites.png" width="80%" height="auto" />
            </div>
          </div>
          <div className="row">
            <div className="col-xs-16 mT">
              <div style={{ width: "100%", height: "20px", backgroundColor: "#efe4b0" }} />
            </div>
            <div className="col-xs-8" style={{ fontSize: "1.4em", padding: 8 }}>
              CA par région
            </div>
          </div>
          <div className="row">
            <div className="col-xs-16 txtC">
              <img src="http://localhost:8080/ebdcf383-63a6-4bc4-8dea-bf93e9f7c17b/ca_regions.png" width="75%" height="auto" />
            </div>
            <div className="col-xs-8" style={{ fontSize: "0.8em" }}>
              <div className="row" style={{ marginTop: "50px" }}>
                <div className="col-xs-16 bb titreCouv">Région</div>
                <div className="col-xs-8 txtR bb titreCouv">Loyer</div>
              </div>
              <div className="row">
                <div className="col-xs-16 bb">Paris</div>
                <div className="col-xs-8 txtR bb">
                  <NumberFormat
                    value={this.props.regions.Paris}
                    displayType={"text"}
                    thousandSeparator={" "}
                    suffix={" €"}
                    decimalScale={0}
                  />
                </div>
              </div>
              <div className="row">
                <div className="col-xs-16 bb">Ile de france (hors Paris)</div>
                <div className="col-xs-8 txtR bb">
                  <NumberFormat
                    value={this.props.regions.Banlieue}
                    displayType={"text"}
                    thousandSeparator={" "}
                    suffix={" €"}
                    decimalScale={0}
                  />
                </div>
              </div>
              <div className="row">
                <div className="col-xs-18 bb">Province</div>
                <div className="col-xs-6 txtR bb">
                  <NumberFormat
                    value={this.props.regions.Province}
                    displayType={"text"}
                    thousandSeparator={" "}
                    suffix={" €"}
                    decimalScale={0}
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-xs-8" style={{ fontSize: "1.4em", padding: 8 }}>
              CA par arrondissement
            </div>
            <div className="col-xs-16 mT">
              <div style={{ width: "100%", height: "20px", backgroundColor: "#efe4b0" }} />
            </div>
          </div>
          <div className="row">
            <div className="col-xs-8" style={{ fontSize: "0.8em" }}>
              <div className="row" style={{ marginTop: "20px" }}>
                <div className="col-xs-18 bb titreCouv">Arrondissemment</div>
                <div className="col-xs-6 txtR bb titreCouv">Loyer</div>
              </div>
              {this.props.arrondissements.filter(d => d.Arrondismment !== "Total").map(a => (
                <div className="row">
                  <div className="col-xs-18 bb">{a.Arrondismment}</div>
                  <div className="col-xs-6 txtR bb">
                    <NumberFormat
                      value={a.loyer_total}
                      displayType={"text"}
                      thousandSeparator={" "}
                      suffix={" €"}
                      decimalScale={0}
                    />
                  </div>
                </div>
              ))}
            </div>
            <div className="col-xs-16 txtC" style={{ marginTop: "1em" }}>
              <img src="http://localhost:8080/ebdcf383-63a6-4bc4-8dea-bf93e9f7c17b/ca_arrondissements.png" width="90%" height="auto" />
            </div>
          </div>
        </body>
      </html>
    );
  }
}

module.exports = Local;
