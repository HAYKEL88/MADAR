const React = require("react");
import NumberFormat from "react-number-format";

// const queries = document.location.search.replace("?", "").split("&");
// const sansDonneesFinancement = queries[0] && queries[0].split("=")[1] === "1";
// const sansCouverture = queries[1] && queries[1].split("=")[1] === "1";
class Local extends React.Component {
  render() {
    const { dscr1, dscr2, idsociete } = this.props;
    return (
      <html lang="en" style={{ zoom: "0.55" }}>
        <head>
          <meta charSet="UTF-8" />
          <title>CA Activités</title>
          <link rel="stylesheet" href={`${this.props.cssUrl}rapport.css`} />
        </head>
        <body style={{ padding: "1em", fontSize: "1.4em" }}>
          <div className="row" className="titre"> 
            <div className="col-xs-22 titre-adresse txtC">DSCR Projeté sur 15 ans</div>
            <div className="col-xs-2">
              <img src={`${this.props.urlAssets}madar.png`} alt="logo madar" height="auto" width="100%" />
            </div>
          </div>
          {(idsociete === "" || idsociete === 1) && (<div className="row">
            <div className="col-xs-4" style={{ marginTop: "1em", fontSize: "1.5em" }}>
              PARDES Patrimoine
            </div>
            <div className="col-xs-20" style={{ marginTop: "2em" }}>
              <div style={{ width: "100%", height: "20px", backgroundColor: "#eae0ad" }} />
            </div>
          </div>)}
          {(idsociete === "" || idsociete === 1) && (<div className="row">
            <div className="col-xs-16 col-xs-offset-4 txtC">
              <img src="http://localhost:8080/ebdcf383-63a6-4bc4-8dea-bf93e9f7c17b/dscr_forum_1.png" width="90%" height="auto" />
            </div>
            <div className="col-xs-24">
              <table className="tableDscr">
                <thead>
                  <tr>
                    <td />
                    {dscr1.map(data => <th className="tdDscr">{data.annee_emprunt}</th>)}
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th className="thDscr">DSCR Actuel</th>
                    {dscr1.map(data => <td className="tdDscr">{parseInt(data.dscr_actuel, 10)} %</td>)}
                  </tr>
                  <tr>
                    <th className="thDscr">DSCR Facial</th>
                    {dscr1.map(data => <td className="tdDscr">{parseInt(data.dscr_facial_acte, 10)} %</td>)}
                  </tr>
                  <tr>
                    <th className="thDscr">DSCR Potentiel</th>
                    {dscr1.map(data => <td className="tdDscr">{parseInt(data.dscr_potentiel, 10)} %</td>)}
                  </tr>
                </tbody>
              </table>
            </div>
          </div>)}
          {(!idsociete || idsociete === 2) && (<div className="row">
            <div className="col-xs-4" style={{ marginTop: "1em", fontSize: "1.5em" }}>
              PARDES Forum
            </div>
            <div className="col-xs-20" style={{ marginTop: "2em" }}>
              <div style={{ width: "100%", height: "20px", backgroundColor: "#eae0ad" }} />
            </div>
          </div>)}
          {(!idsociete || idsociete === 2) && (<div className="row">
            <div className="col-xs-16 col-xs-offset-4 txtC">
              <img src="http://localhost:8080/ebdcf383-63a6-4bc4-8dea-bf93e9f7c17b/dscr_forum_2.png" width="90%" height="auto" />
            </div>
            <div className="col-xs-24">
              <table className="tableDscr">
                <thead>
                  <tr>
                    <td />
                    {dscr2.map(data => <th className="tdDscr">{data.annee_emprunt}</th>)}
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th className="thDscr">DSCR Actuel</th>
                    {dscr2.map(data => <td className="tdDscr">{parseInt(data.dscr_actuel, 10)} %</td>)}
                  </tr>
                  <tr>
                    <th className="thDscr">DSCR Facial</th>
                    {dscr2.map(data => <td className="tdDscr">{parseInt(data.dscr_facial_acte, 10)} %</td>)}
                  </tr>
                  <tr>
                    <th className="thDscr">DSCR Potentiel</th>
                    {dscr2.map(data => <td className="tdDscr">{parseInt(data.dscr_potentiel, 10)} %</td>)}
                  </tr>
                </tbody>
              </table>
            </div>
          </div>)}
        </body>
      </html>
    );
  }
}

module.exports = Local;
