<?php
/**
 * Copyright (c)  2018. L’ensemble du contenu (codes, textes, photographies, infographies, icônes, etc.) du site www.you-fleet.fr est la propriété exclusive de  sas ODEA, éditeur du site you-fleet.fr enregistrés à l'agence pour la protection des programmes sous le N°IDDN.FR.001.43005.000.R.P.2016.000.20100 Tous droits de reproduction ou de représentation de ceux-ci sont réservés.
 */


namespace App\Controllers;


//require_once __DIR__ . '../../../vendor/autoload.php';
use RuntimeException;
use Psr\Http\Message\RequestInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\StreamInterface;
use \Psr\Http\Message;
use Psr\Log\LoggerInterface;
use Slim\Http\UploadedFile;





class UploadController
{
    /**
     * @var \Psr\Log\LoggerInterface
     */
    protected $logger;
    public $path;
    public $file;
    public $name;
    public $type;
    public $size;
    public $connexion;
    public $router;

    public function __construct($dossier, LoggerInterface $logger)
    {
        # path destination upload dossier
        $this->path = $dossier;

        # connexion a postgres
        $this->connexion = $this->connecte();
        # router
        # acces logger
        $this->logger = $logger;

    }


    public function UploadFileBase64(Request $request,Response $response, $args){
        $code       = (int) 200;
        $message    = (string) null;
        $filename   = (string) null;
        $data       = $data = $request->getParam('data');


        $datetime = date("Y-m-d h:i:s");
        $timestamp = strtotime($datetime);
        $image = json_decode($data);
        $user = ["id" => $image->id];

        $imgdata = base64_decode($image->image);
        $f = finfo_open();
        $mime_type = finfo_buffer($f, $imgdata, FILEINFO_MIME_TYPE);
        $temp=explode('/',$mime_type);
        # extension
        $extension = substr($image->image,strpos($image->image,"/",0)+1,3);

        # file name with extension
        $filename = $this->path."/$timestamp.$extension";
        # open the output file for writing
        $ifp = fopen( $filename, 'wb' );

        # split the string on commas
        # $data[ 0 ] == "data:image/png;base64"
        # $data[ 1 ] == <actual base64 string>
        $file = explode( ',', $image->image );

        # we could add validation here with ensuring count( $data ) > 1
        $handle = fwrite( $ifp, base64_decode( $file[1] ) );

        # clean up the file resource
        fclose( $ifp );

        if($handle){
            $message = $this->UpdateField($user, $filename);
            if($message === false){
                $code = 404;
                $message = ["error"=> "Echec de la mise à jour de la table users"];
            }
        }

        return $this->getResponseData($code,$request, $response,$message, $filename);
    }

    /**
     * @param Request $request
     * @param Response $response
     * @param $args
     * @return UploadController|ResponseInterface
     * @throws \Exception
     */
    public function uploadFileRequest(Request $request,Response $response, $args)
    {
        $code     = (int) null;
        $error    = (array) null;
        $filename =(string) null;
        $message  = (string) null;
        $data     = (array)null;


        $uploadedFile = new UploadedFile(
            'C:/Users/dahan/Pictures/dahan_gerald.JPG',
            'dahan_gerald.JPG',
            'text/plain',
            filesize( 'C:/Users/dahan/Pictures/dahan_gerald.JPG'),
            0
        );

        $uploadedFiles = array();
        $uploadedFiles["file"] = $uploadedFile;


        # recuperation JSON data
        $data = $request->getParam('data');
        $data = $this->getData($data);

        $request->withUploadedFiles($uploadedFiles);

        # initialisation de l'upload
        $uploadedFiles = $request->getUploadedFiles();

        # initialisation de la clé du tableau
        $keys = array_keys($uploadedFiles);

        # initialisation du tableau protégé
        $uploadedFile    = $uploadedFiles[$keys[0]];

        # lecture du array GLOBAL $_FILES
        foreach($_FILES[$keys[0]] as $key => $value){
            if($key === 'type')    {$this->type  =  $value;}
            if($key === 'name')    {$this->name  = $value;}
            if($key === 'tmp_name'){$this->file  = $value;}
            if($key === 'size')    {$this->size  = $value;}
        }

        # initialisation de l'upload
        if ($uploadedFile->getError() === UPLOAD_ERR_OK) {
            $filename = $this->moveUploadedFile($uploadedFile);
            if ($filename === null){
                $code = 400;
                $message = ["error"=> "Echec de l'upload"];
            }else{
                $code = 200;
                $message = $this->UpdateField($data, $filename);
                if($message === false){
                    $code = 404;
                    $message = ["error"=> "Echec de la mise à jour de la table upload"];
                }
            }
        }else{
            $code = 400;
            $message = $uploadedFile->getError();
        }
        $response = $response->withStatus($code); //->write('after');
        return $this->getResponseData($code,$request, $response,$message, $filename);
    }

    public function downloadFile(Request $request,Response $response, $args)
    {
         # faire un select from societe
         # recupérer le codefichier
        # le downloader avec cette procedure
            $file = 'D:/site/patrimonial/files/pictures/0c22c6e3669ada3c.JPG';
            $response = $request->withHeader('Content-Description', 'File Transfer')
                ->withHeader('Content-Type', 'application/octet-stream')
                ->withHeader('Content-Disposition', 'attachment;filename="'.basename($file).'"')
                ->withHeader('Expires', '0')
                ->withHeader('Cache-Control', 'must-revalidate')
                ->withHeader('Pragma', 'public')
                ->withHeader('Content-Length', filesize($file));

            readfile($file);
            return $response;

    }

    /**
     * @param $data
     * @param $filename
     */
    public function UpdateField($data, $filename)
    {
        $code   = (integer)null;
        $table  = (string) null;
        $result = (bool) false;
        $key    = (string) null;
        $key    = array_keys($data);
        $array  = (array) null;

        switch($key[0]){
            case "idsociete": $table = "societe";
                $id = $data["idsociete"];
                $key = "idsociete";
                $logo = pg_escape_string($this->connexion, $this->name);
                $filename = pg_escape_string($this->connexion, $filename);
                $array  = ["attach_file" => $filename,"logo_societe" => $logo];
                break;
            case "id": $table = "users";
                $id = $data["id"];
                $key = "id";
                $filename = str_replace("\\","/",$filename);
                $logo = pg_escape_string($this->connexion, $this->name);
                $filename = pg_escape_string($this->connexion, $filename);
                $array  = ["attach_file" => $filename,"photo_user" => null];
                break;
            default :
                break;
        }

        # update $data
        if ($array !== null) {
            $result = pg_update($this->connexion, $table, $array, [$key => "$id"], PGSQL_DML_EXEC);
            if(!$result){
                $code = 500;
                $this->logger->error(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).'Erreur update:'.$filename.' '.__FUNCTION__);
            }
        }else{
            $result=false;
        }
        if ($result) {
            $q = pg_query($this->connexion, "SELECT * FROM $table WHERE $key ={$id}");
            # fetch result
            $res = pg_fetch_all($q);
            # For booleans and numeric convert
            $res =$this->FormaData($res, $q, true);
            $code = 200;
        } else {
            $code = 500;
            $res = false;
        }

        return $res;

    }


    /**
     * @param $directory
     * @param UploadedFile $uploadedFile
     * @return string
     * @throws \Exception
     */
    public function moveUploadedFile(UploadedFile $uploadedFile)
    {
        $extension = pathinfo($uploadedFile->getClientFilename(), PATHINFO_EXTENSION);
        $basename = bin2hex(random_bytes(8)); // see http://php.net/manual/en/function.random-bytes.php
        $filename = sprintf('%s.%0.8s', $basename, $extension);

       $uploadedFile->moveTo($this->path . DIRECTORY_SEPARATOR . $filename);
        if ($uploadedFile->getError() !== UPLOAD_ERR_OK) {
            $filename = null;
        }
        return $filename;
    }

    /**
     * @param $code
     * @param RequestInterface $request
     * @param ResponseInterface $response
     * @param $message
     * @return ResponseInterface|static
     */
    public function getResponseData($code,Request $request,Response $response,$message, $filename ){
        $response = $response->withStatus($code); //->write('after');
        $body = $response->getBody()->__toString();
        if ($code === 200) {
            $body = $response->withStatus(200)
                ->getBody($message);
            $response = $response->withJson(array('status' => 'success',
                'data' => $message,
                'message' => "Upload: ".$filename,
                "code"=> $code));

        }else{
            $body = $response->withStatus(404)
                ->getBody($message);
            $response = $response->withJson($message);
        }



        return $response;
    }

    /**
     * @return bool|mixed|string
     */
    public function getData($data)
    {
        $contents = utf8_encode($data);

        if (empty($contents)) {
            $contents = file_get_contents('php://input');
        }
        // search and remove comments like /* */ and //
        $json = str_replace(array("\n","\r"),"",$contents);
        $json = preg_replace('/([{,]+)(\s*)([^"]+?)\s*:/','$1"$3":',$json);
        $json = preg_replace('/(,)\s*}$/','}',$json);

        $res = json_decode($json, true);

        return $res;
    }


    /**
     * @param $data
     * @param $conn
     * @return array
     */
    public function FormaData($data = array(), $conn = null, $reduce = false)
    {
        $array = array();
        if ($data) {
            foreach ($data as $value) {
                foreach ($value as $key2 => $value2) {
                    $type = pg_field_type($conn, pg_field_num($conn, $key2));

                    # For booleans, convert 't' and 'f' back to true and false.
                    if ($type == 'bool') {
                        $value[$key2] = ($value2 == 't');
                    }

                    # For numeric, convert '10' back to 10
                    if ($type == 'int4' || $type == 'int2') {
                        $value[$key2] = (intval($value2));
                    }
                    # For numeric, convert '00.00000' back to 00.000000
                    if ($type == 'numeric' || $type == 'float4') {
                        $value[$key2] = (floatval($value2));
                    }

                }

                array_push($array, $value);

            }

            if($reduce){
                $array = $array[0];
            }
        }


        return $array;

    }

    /**
     * @return object
     */
    public function connecte()
    {

        $this->connexion = pg_connect('host=' . SETTING_HOST .
            ' port=' . SETTING_PORT .
            ' dbname=' . SETTING_DBNAME .
            ' user=' . SETTING_USER .
            ' password=' . SETTING_PSWD) or die('connection failed');

        return $this->connexion;

    }

}
