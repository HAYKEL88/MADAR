<?php
/**
 * Copyright (c)  2018. L’ensemble du contenu (codes, textes, photographies, infographies, icônes, etc.) du site www.you-fleet.fr est la propriété exclusive de  sas ODEA, éditeur du site you-fleet.fr enregistrés à l'agence pour la protection des programmes sous le N°IDDN.FR.001.43005.000.R.P.2016.000.20100 Tous droits de reproduction ou de représentation de ceux-ci sont réservés.
 */



/**
 * Created by PhpStorm.
 * User: dahan
 * Date: 08/07/2018
 * Time: 10:37
 */

namespace  App\Models {
    require_once __DIR__ . '/Tools.php';
//    use RuntimeException;
    use Psr\Log\LoggerInterface;
    use \Psr\Http\Message\ServerRequestInterface as Request;
    use \Psr\Http\Message\ResponseInterface as Response;
    use App\Models\Tools;
    use PDO;

    class Locaux extends Tools
    {

        /**
         * @var $connexion
         */
        public $connexion;

        /**
        /**
         * @var \Psr\Log\LoggerInterface
         */
        private $logger;

        /**
         * @var \PDO
         */
        private $pdo;

        /**
         * @var $maintable
         */
        private $maintable;

        private $tables_liees;

        /**
         * Locaux constructor.
         */
        public function __construct(LoggerInterface $logger, PDO $pdo, $table,$c)
        {
            parent::__construct($c, $logger);

            # connexion to php_pgsql
            $this->connecte();

            # name of the data table
            $this->maintable = $table;

            # log this access data
            $this->logger    = $logger;

            # if you need PDO
            //$this->pdo       = $pdo;

            $this->tables_liees = ["actif_patrimonial","locaux","societe"];

            # renumber the sequences when config is true
            if (SETTING_NEW_SEQUENCE)
            {

            }

        }


        /**
         *  destruct a curently connexion
         * Locaux destruct.
         */
        public function __destruct()
        {
            pg_close($this->connexion);
        }



        /**
         * @url GET /locaux/$id
         * @url GET /locaux=current
         */
        public function getLocal(Request $request,Response $response, $arg)
        {
            $code = (integer) null;
            $result = (bool) null;
            $result_error =(string) null;
            $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);
            $table = $this->maintable != '' ? $this->maintable : $this->path;
            $id = $arg['id'];
            if ($id) {
                # query locaux idlocal = id
                $query = "SELECT A.idactifpatrimonial,B.bailactif, A.adresse, A.code_postal, A.ville, A.surface_totale_actif,
                             L.idlocal, L.idactifpatrimonial, L.surface_rdc, L.surface_etage, L.surface_sous_sol, L.surface_totale, L.devanture, 
                             L.nombre_parking_ext, L.nombre_parking_int, L.etage, L.idsociete, L.licence4, L.extraction, L.restauration, L.activite_interdite, 
                             L.idactifpatrimonial 
                      FROM locaux as L
                      left join bail as B on B.idlocal = L.idlocal
                      join actif_patrimonial as A on L.idactifpatrimonial = A.idactifpatrimonial WHERE L.idlocal ={$id}";

                # recherche d'une erreur
                $result = pg_send_query($this->connexion, $query);
                $res1 = pg_get_result($this->connexion);
                $result_error = pg_result_error($res1);
                if(Empty($result_error)) {
                    # query
                    $result = pg_query($this->connexion, $query);
                    # fetch result
                    $res = pg_fetch_all($result);
                    # For booleans and numeric convert
                    $res =$this->FormaData($res, $result, true);
                    $code = 200;
                } else {
                    $code = 500;
                    $state = pg_last_error();
                    // some error happened
                    $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                    $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                    return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
                }
            } else {
                $code = 400;
            }
            return $this->getResponseData($code, $request, $response,$res);
        }


        /**
         * @url GET /locals
         */
        public function getListLocal(Request $request,Response $response, $arg)
        {
            $code           = (integer) null;
            $result         = (bool) null;
            $result_error   =(string) null;
            $query          = (string) null;
            # traitement de la query
            $querie         = $this->getUrlQuery($request,$this->tables_liees,$this->connexion);

            $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);
            $table = $this->maintable != '' ? $this->maintable : $this->path;
            $query = "SELECT A.idactifpatrimonial,B.bailactif, A.adresse, A.code_postal, A.ville, A.surface_totale_actif,
                             L.idlocal, L.idactifpatrimonial, L.surface_rdc, L.surface_etage, L.surface_sous_sol, L.surface_totale, L.devanture, 
                             L.nombre_parking_ext, L.nombre_parking_int, L.etage, L.idsociete, L.licence4, L.extraction, L.restauration, L.activite_interdite, 
                             L.idactifpatrimonial 
                      FROM locaux as L
                      left join bail as B on B.idlocal = L.idlocal
                      join actif_patrimonial as A on L.idactifpatrimonial = A.idactifpatrimonial";
            $query = $query."\r\n".$querie;

            # test de la valitdité de la requete
            $result = pg_send_query($this->connexion, $query);
            $res1 = pg_get_result($this->connexion);
            $result_error = pg_result_error($res1);
            if(Empty($result_error)) {
                $result = pg_query($this->connexion, $query);
                $res = pg_fetch_all($result);
                # For booleans and numeric convert
                $res =$this->FormaData($res, $result, false);
                $code = 200;
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
            }
            return $this->getResponseData($code, $request, $response,$res);
        }



        /**
         * @url GET /locals/$id
         * @url GET /locals=current
         */
        public function getLocalByIdActif(Request $request,Response $response, $arg)
        {
            $code = (integer) null;
            $result = (bool) null;
            $result_error =(string) null;
            $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);
            $table = $this->maintable != '' ? $this->maintable : $this->path;
            $id = $arg['id'];
            if ($id) {
                $query = "SELECT A.idactifpatrimonial,B.bailactif, A.adresse, A.code_postal, A.ville, A.surface_totale_actif,
                                 L.idlocal, L.idactifpatrimonial, L.surface_rdc, L.surface_etage, L.surface_sous_sol, L.surface_totale, L.devanture, 
                                 L.nombre_parking_ext, L.nombre_parking_int, L.etage, L.idsociete, L.licence4, L.extraction, L.restauration, L.activite_interdite, 
                                 L.idactifpatrimonial 
                          FROM locaux as L
                          left join bail as B on B.idlocal = L.idlocal
                          join actif_patrimonial as A on L.idactifpatrimonial = A.idactifpatrimonial
                          WHERE L.idactifpatrimonial ={$id}";
                $result = pg_send_query($this->connexion, $query);
                $res1 = pg_get_result($this->connexion);
                $result_error = pg_result_error($res1);
                if(Empty($result_error)) {
                    # query locaux idlocal = id
                    $result = pg_query($this->connexion, $query);
                    # fetch result
                    $res = pg_fetch_all($result);
                    # For booleans and numeric convert
                    $res =$this->FormaData($res, $result, false);
                    $code = 200;
                } else {
                    $code = 500;
                    $state = pg_last_error();
                    // some error happened
                    $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                    $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                    return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
                }
            } else {
                $code = 404;
            }
            return $this->getResponseData($code, $request, $response,$res);
        }


        /**
         * @url GET /locals/$id/bailactif/$bool
         * @url GET /locals/$id/bailactif/$bool
         */
        public function getIDByLocalBailActif(Request $request,Response $response, $arg)
        {
            $code = (integer) null;
            $id = $arg['id'];
            $bool = $arg['bool'];
            $result = (bool) null;
            $result_error =(string) null;
            if ($id) {
                # locaux/id/bailactif/bool
                $query = "SELECT L.idlocal, L.idactifpatrimonial, L.surface_rdc, L.surface_etage, L.surface_sous_sol, L.surface_totale, L.devanture, 
                                  L.nombre_parking_ext, L.nombre_parking_int, L.etage, L.idsociete, L.licence4, L.extraction, L.restauration, L.activite_interdite, 
                                  A.adresse, A.code_postal, A.ville, L.surface_totale as surface_totale_actif, L.idactifpatrimonial 
                           FROM $this->maintable AS L 
                            join bail AS B on  B.idlocal = L.idlocal  
                            join actif_patrimonial A on A.idactifpatrimonial = L.idactifpatrimonial
                          WHERE B.idlocal ={$id}
                          AND B.bailactif = {$bool}";

                # recherche d'une erreur
                $result = pg_send_query($this->connexion, $query);
                $res1 = pg_get_result($this->connexion);
                $result_error = pg_result_error($res1);
                if(Empty($result_error)) {
                    # query
                    $result = pg_query($this->connexion, $query);
                    # fetch result
                    $res = pg_fetch_all($result);
                    # For booleans and numeric convert
                    $res =$this->FormaData($res, $result, true);
                    $code = 200;
                } else {
                    $code = 500;
                    $state = pg_last_error();
                    // some error happened
                    $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                    $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                    return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
                }
            } else {
                $code = 400;
            }

            return $this->getResponseData($code, $request, $response,$res);
        }


        /**
         * @url GET /locals/bailactif
         * @url GET /locals/bailactif=$bool
         */
        public function getLocalBailActif(Request $request,Response $response, $arg)
        {
            $code = (integer) null;
            $bool = $arg['bool'];
            $result = (bool) null;
            $result_error =(string) null;
            # query bail / local bailactif = $bool
            $query = "SELECT L.idlocal, L.idactifpatrimonial, L.surface_rdc, L.surface_etage, L.surface_sous_sol, L.surface_totale, L.devanture, 
                              L.nombre_parking_ext, L.nombre_parking_int, L.etage, L.idsociete, L.licence4, L.extraction, L.restauration, L.activite_interdite, 
                              A.adresse, A.code_postal, A.ville, L.surface_totale_actif, L.idactifpatrimonial 
                       FROM $this->maintable AS L 
                      join bail AS B on  B.idlocal = L.idlocal  
                      left join actif_patrimonial A on A.idactifpatrimonial = L.idactifpatrimonial 
                      WHERE B.bailactif = {$bool}";

            # recherche d'une erreur
            $result = pg_send_query($this->connexion, $query);
            $res1 = pg_get_result($this->connexion);
            $result_error = pg_result_error($res1);
            if(Empty($result_error)) {
                # query
                $result = pg_query($this->connexion, $query);
                # fetch result
                $res = pg_fetch_all($result);
                # For booleans and numeric convert
                $res =$this->FormaData($res, $result, false);
                $code = 200;
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
            }
            return $this->getResponseData($code, $request, $response,$res);
        }


        /**
         * @url PUT /locals/$id
         * @url PUT /locals/$id/$data
         */
        public function UpdateLocal(Request $request,Response $response, $arg)
        {
            $code = (integer) null;
            $id = $arg['id'];
            $data = $request->getParam('data');
            $data = $this->getData($data);
            # if method PUT or POSt getValidateFields
            $error = $this->getValidateFields($this->maintable,$data);
            if($error){
                $code = 400;
                return $this->getResponseData($code, $request, $response,$error);
            }

            # format $data with escape string
            $array =$this->InsertFormaData($data,$this->connexion);
            # update $data
            $result = pg_update($this->connexion, $this->maintable , $array, ["idlocal" => "$id"], PGSQL_DML_EXEC);
            if ($result) {
                $q = pg_query($this->connexion, "SELECT * FROM $this->maintable WHERE idlocal ={$id}");
                # fetch result
                $res = pg_fetch_all($q);
                $res =$this->FormaData($res, $q,true);
                $code = 200;
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
            }
            $this->SetRenumKeyLocal();
            return $this->getResponseData($code, $request, $response,$res);
        }


        /**
         * @url POST /locals
         * @url POST /locals/$data
         */
        public function AddLocal(Request $request,Response $response, $arg)
        {
            $code = (integer) null;
            $data = $request->getParam('data');
            $data = $this->getData($data);
            # if method PUT or POSt getValidateFields
            $error = $this->getValidateFields($this->maintable,$data);
            if($error){
                $code = 400;
                return $this->getResponseData($code, $request, $response,$error);
            }
            # format $data with escape string
            $array =$this->InsertFormaData($data,$this->connexion);

            # insert $data
            $array['idlocal'] = $this->NewSequence( $this->maintable,'idlocal',$this->connexion);
            $result = pg_insert($this->connexion, $this->maintable , $array, PGSQL_DML_EXEC);
            if ($result) {
                $id = $array['idlocal'];
                # recherche de l'id
                $q = pg_query($this->connexion, "SELECT * FROM $this->maintable WHERE idlocal ={$id}");
                # fetch result
                $res = pg_fetch_all($q);
                $res =$this->FormaData($res, $q,true);
                $code = 200;
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
            }
            $this->SetRenumKeyLocal();
            return $this->getResponseData($code, $request, $response,$res);
        }


        /**
         * @param $table
         * @return array
         */
        public function getValidateFields($table,$data) {
            $validfields = $this->ValidateField($table, $this->connexion);
            $res         = $this->verifyRequiredParams($data,$validfields);
            return $res;
        }


        /**
         * @url DELETE /locals/$id
         */
        public function DeleteLocal(Request $request,Response $response, $arg)
        {
            $code = (integer) null;
            $id = $arg['id'];
            # delete
            $res = pg_delete($this->connexion, $this->maintable , ["idlocal" => "$id"], PGSQL_DML_EXEC);
            if ($res) {
                # For booleans and numeric convert
                $res = ["message" => "L'Enregistrement a été éffacé", "Enregistrement supprimé ID :" => $id];
                $code = 200;
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
            }

            $this->SetRenumKeyLocal();

            return $this->getResponseData($code, $request, $response,$res);

        }

        /**
         *
         */
        public function SetRenumKeyLocal()
        {
            $compt  = (int) 1;
            $data   = (array) ['keylocal' => 1];
            $idbail = (int) 0;
            # query locaux idbail = id
            $q = pg_query($this->connexion, "SELECT L.idlocal, L.idactifpatrimonial, L.keylocal FROM locaux as L
                                                     join actif_patrimonial A on A.idactifpatrimonial = L.idactifpatrimonial
                                                    ORDER by L.idactifpatrimonial,L.idlocal");
            # fetch result
            $local = pg_fetch_all($q);
            $valkey = (int) $local[0]['idactifpatrimonial'];
            foreach($local as $keys => $value)
            {
                # si on change d'actif, le compteur est mis à 1
                if($local[$keys]['idactifpatrimonial'] !== $valkey ){
                    $compt = 1;
                }
                # changer la keybail
                $idlocal = intval($local[$keys]['idlocal']);
                $data['keylocal'] = $compt;
                if($idlocal > 0 && $compt > 0){
                    $result = pg_update($this->connexion, $this->maintable, $data, ["idlocal" => $idlocal], PGSQL_DML_EXEC);
                }
                $compt ++;
                $valkey = $local[$keys]['idactifpatrimonial'];
            }
        }
    }
}
