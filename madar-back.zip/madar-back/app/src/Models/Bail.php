<?php
/**
 * Copyright (c)  2018. L’ensemble du contenu (codes, textes, photographies, infographies, icônes, etc.) du site www.you-fleet.fr est la propriété exclusive de  sas ODEA, éditeur du site you-fleet.fr enregistrés à l'agence pour la protection des programmes sous le N°IDDN.FR.001.43005.000.R.P.2016.000.20100 Tous droits de reproduction ou de représentation de ceux-ci sont réservés.
 */


/**
 * Created by PhpStorm.
 * User: dahan
 * Date: 08/07/2018
 * Time: 10:37
 */

namespace  App\Models {
    require_once __DIR__ . '/Tools.php';
    use \Slim\Exception;
    use Psr\Log\LoggerInterface;
    use \Psr\Http\Message\ServerRequestInterface as Request;
    use \Psr\Http\Message\ResponseInterface as Response;
    use App\Models\Tools;
    use PDO;
    use DateTime;
    use DateInterval;

    class Bail extends Tools
    {

        /**
         * @var $connexion
         */
        public $connexion;

        /**
        /**
         * @var \Psr\Log\LoggerInterface
         */
        private $logger;

        /**
         * @var \PDO
         */
        private $pdo;

        /**
         * @var $maintable
         */
        private $maintable;


        /**
         *
         */
        private $params;



        /**
         * Bail constructor.
         */
        public function __construct(LoggerInterface $logger = null, PDO $pdo = null, $table, $c)
        {

            parent::__construct($c, $logger);

            # Exception reporté à la fonction
   //         set_error_handler(array($this, 'exception_error_handler'));

            # connexion to php_pgsql
            $this->connecte();

            # name of the data table
            $this->maintable = $table;

            # log this access data
            $this->logger    = $logger;

            # if you need PDO
            //$this->pdo       = $pdo;

            $this->tables_liees = ["actif_patrimonial","locaux","societe"];

            # renumber the sequences when config is true
            if (SETTING_NEW_SEQUENCE)
            {

            }

        }


        /**
         *  destruct a curently connexion
         * Bail destruct.
         */
        public function __destruct()
        {
            pg_close($this->connexion);
        }




        /**
         * @url GET /bail
         */
        public function getListBail(Request $request,Response $response, $arg)
        {
            $code           = (integer) null;
            $result         = (bool) null;
            $result_error   =(string) null;
            $query          = (string) null;
            $querie         = $this->getUrlQuery($request,$this->tables_liees,$this->connexion);
            $table          = $this->maintable != '' ? $this->maintable : $this->path;

            $query = "SELECT  B.idbail, B.keybail, B.idlocal, B.nom_du_locataire, B.nom_commercial, B.idtype_bail, 
                              B.type_de_bail, B.date_dentree_du_locataire, B.date_effet_du_bail, B.loyer_annuel, B.frais_gestion, 
                              B.complement_loyer, B.charges_refacturees, B.provision_ur_charges, B.depot_de_garantie, B.actif_bail, 
                              B.bailactif, B.activite, B.image_bail, B.commentaires, B.date_fin_bail, B.deplaf_fin_bail, B.caution, 
                              B.type_activite, B.date_liberation, B.proche_liberation, B.loyer_attendu, B.etage, B.affectation_commerce, 
                              B.affectation_reserve, B.affectation_bureau, B.affectation_stockage, B.affectation_res_sous_sol, 
                              B.affectation_comm_sous_sol, B.affectation_habitation, B.valeur_locative, B.type_caution, B.trimestre, 
                              B.annee, B.variation_indice, B.indice_reference, B.destination_bail, B.date_signature_bail, B.duree_preavis, 
							  B.idactivite, B.idsociete, B.loyer_contractuel, B.loyer_actuel, A.adresse, A.code_postal, A.ville, 
                              A.surface_totale_actif, L.idactifpatrimonial, B.paliers,B.caution_bancaire,B.caution_societe,B.caution_perso,B.caution_garantie_premiere_demande,			
                              B.caution_garantie_solvabilite,B.duree_speciale,B.date_effective_depart,B.tunnel_indexation,B.duree_bail
                       FROM  bail as B 
                       join locaux AS L on  B.idlocal = L.idlocal  
                       join actif_patrimonial A on A.idactifpatrimonial = L.idactifpatrimonial";
            $query = $query."\r\n".$querie;

            # test de la valitdité de la requete
            $result = pg_send_query($this->connexion, $query);
            $res1 = pg_get_result($this->connexion);
            $result_error = pg_result_error($res1);
            if(Empty($result_error)) {
                # query locaux idlocal = id
                $result = pg_query($this->connexion, $query);
                # fetch result
                $res = pg_fetch_all($result);
                # For booleans and numeric convert
                $res =$this->FormaData($res, $result, false);
                $code = 200;
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
            }
            return $this->getResponseData($code, $request, $response,$res);
        }



        /**
         * @url GET /bail/$id
         * @url GET /bail=current
         */
        public function getBail(Request $request,Response $response, $arg)
        {
            $code         = (int) null;
            $result       = (bool) null;
            $result_error =(string) null;
            $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);
            $table = $this->maintable != '' ? $this->maintable : $this->path;
            $id = $arg['id'];
            if ($id) {
                # query locaux idbail = id
                $query =  "SELECT  B.idbail, B.keybail, B.idlocal, B.nom_du_locataire, B.nom_commercial, B.idtype_bail, 
                                  B.type_de_bail, B.date_dentree_du_locataire, B.date_effet_du_bail, B.loyer_annuel, B.frais_gestion, 
                                  B.complement_loyer, B.charges_refacturees, B.provision_ur_charges, B.depot_de_garantie, B.actif_bail, 
                                  B.bailactif, B.activite, B.image_bail, B.commentaires, B.date_fin_bail, B.deplaf_fin_bail, B.caution, 
                                  B.type_activite, B.date_liberation, B.proche_liberation, B.loyer_attendu, B.etage, B.affectation_commerce, 
                                  B.affectation_reserve, B.affectation_bureau, B.affectation_stockage, B.affectation_res_sous_sol, 
                                  B.affectation_comm_sous_sol, B.affectation_habitation, B.valeur_locative, B.type_caution, B.trimestre, 
                                  B.annee, B.variation_indice, B.indice_reference, B.destination_bail, B.date_signature_bail, B.duree_preavis, 
                                  B.idactivite, B.idsociete, B.loyer_contractuel, B.loyer_actuel, A.adresse, A.code_postal, A.ville, 
                                  A.surface_totale_actif, L.idactifpatrimonial, B.paliers,B.caution_bancaire,B.caution_societe,B.caution_perso,B.caution_garantie_premiere_demande,			
                                  B.caution_garantie_solvabilite,B.duree_speciale,B.date_effective_depart,B.tunnel_indexation,B.duree_bail  
                          FROM bail AS B 
                            join locaux AS L on  B.idlocal = L.idlocal  
                            left join actif_patrimonial A on A.idactifpatrimonial = L.idactifpatrimonial 
                            WHERE B.idbail ={$id}";
                # fetch result
                $result = pg_send_query($this->connexion, $query);
                $res1 = pg_get_result($this->connexion);
                $result_error = pg_result_error($res1);
                if(Empty($result_error)) {
                    # query locaux idlocal = id
                    $result = pg_query($this->connexion, $query);
                    # fetch result
                    $res = pg_fetch_all($result);
                    # For booleans and numeric convert
                    $res =$this->FormaData($res, $result, true);
                    $code = 200;
                } else {
                    $code = 500;
                    $state = pg_last_error();
                    // some error happened
                    $result_error = "erreur d'execution de la requete : ".__FUNCTION__." Detail de l'erreur :".$state;
                    $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                    return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
                }
            } else {
                $code = 400;
            }

            return $this->getResponseData($code, $request, $response,$res);
        }


        /**
         * @url GET /bail/$id/bailactif/$bool
         * @url GET /bail/$id/bailactif/$bool
         */
        public function getIDByBailBailActif(Request $request,Response $response, $arg)
        {
            $code         = (int) null;
            $result       = (bool) null;
            $result_error =(string) null;
            $id = $arg['id'];
            $bool = $arg['bool'];
            if ($id) {
                # Bail/id/bailactif/bool
                $query = "SELECT  B.idbail, B.keybail, B.idlocal, B.nom_du_locataire, B.nom_commercial, B.idtype_bail, 
                                  B.type_de_bail, B.date_dentree_du_locataire, B.date_effet_du_bail, B.loyer_annuel, B.frais_gestion, 
                                  B.complement_loyer, B.charges_refacturees, B.provision_ur_charges, B.depot_de_garantie, B.actif_bail, 
                                  B.bailactif, B.activite, B.image_bail, B.commentaires, B.date_fin_bail, B.deplaf_fin_bail, B.caution, 
                                  B.type_activite, B.date_liberation, B.proche_liberation, B.loyer_attendu, B.etage, B.affectation_commerce, 
                                  B.affectation_reserve, B.affectation_bureau, B.affectation_stockage, B.affectation_res_sous_sol, 
                                  B.affectation_comm_sous_sol, B.affectation_habitation, B.valeur_locative, B.type_caution, B.trimestre, 
                                  B.annee, B.variation_indice, B.indice_reference, B.destination_bail, B.date_signature_bail, B.duree_preavis, 
                                  B.idactivite, B.idsociete, B.loyer_contractuel, B.loyer_actuel, A.adresse, A.code_postal, A.ville, 
                                  A.surface_totale_actif, L.idactifpatrimonial, B.paliers  
                          FROM bail AS B 
                            join locaux AS L on  B.idlocal = L.idlocal  
                            left join actif_patrimonial A on A.idactifpatrimonial = L.idactifpatrimonial
                          WHERE B.idbail ={$id}
                          AND B.bailactif = {$bool}";
                # fetch result
                $result = pg_send_query($this->connexion, $query);
                $res1 = pg_get_result($this->connexion);
                $result_error = pg_result_error($res1);
                if(Empty($result_error)) {
                    # query locaux idlocal = id
                    $result = pg_query($this->connexion, $query);
                    # fetch result
                    $res = pg_fetch_all($result);
                    # For booleans and numeric convert
                    $res =$this->FormaData($res, $result, false);
                    $code = 200;
                } else {
                    $code = 500;
                    $state = pg_last_error();
                    // some error happened
                    $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                    $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                    return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
                }
            } else {
                $code = 400;
            }

            return $this->getResponseData($code, $request, $response,$res);
        }

        /**
         * @url GET /bail/locaux/$id
         * @url GET /bail/locaux/$id
         */
        public function getByIdLocal(Request $request,Response $response, $arg)
        {
            $code         = (int) null;
            $result       = (bool) null;
            $result_error =(string) null;
            $id = $arg['id'];
            if ($id) {
                # Bail/id/bailactif/bool
                $query = "SELECT  B.idbail, B.keybail, B.idlocal, B.nom_du_locataire, B.nom_commercial, B.idtype_bail, 
                                  B.type_de_bail, B.date_dentree_du_locataire, B.date_effet_du_bail, B.loyer_annuel, B.frais_gestion, 
                                  B.complement_loyer, B.charges_refacturees, B.provision_ur_charges, B.depot_de_garantie, B.actif_bail, 
                                  B.bailactif, B.activite, B.image_bail, B.commentaires, B.date_fin_bail, B.deplaf_fin_bail, B.caution, 
                                  B.type_activite, B.date_liberation, B.proche_liberation, B.loyer_attendu, B.etage, B.affectation_commerce, 
                                  B.affectation_reserve, B.affectation_bureau, B.affectation_stockage, B.affectation_res_sous_sol, 
                                  B.affectation_comm_sous_sol, B.affectation_habitation, B.valeur_locative, B.type_caution, B.trimestre, 
                                  B.annee, B.variation_indice, B.indice_reference, B.destination_bail, B.date_signature_bail, B.duree_preavis, 
                                  B.idactivite, B.idsociete, B.loyer_contractuel, B.loyer_actuel, A.adresse, A.code_postal, A.ville, 
                                  A.surface_totale_actif, L.idactifpatrimonial, B.paliers,B.caution_bancaire,B.caution_societe,B.caution_perso,B.caution_garantie_premiere_demande,
                                  B.caution_garantie_solvabilite,B.duree_speciale,B.date_effective_depart,B.tunnel_indexation,B.duree_bail
                                  FROM bail AS B 
                            join locaux AS L on  B.idlocal = L.idlocal  
                            join actif_patrimonial A on A.idactifpatrimonial = L.idactifpatrimonial
                          WHERE B.idlocal ={$id}";
                # test si error de la requête
                $result = pg_send_query($this->connexion, $query);
                $res1 = pg_get_result($this->connexion);
                $result_error = pg_result_error($res1);
                if(Empty($result_error)) {
                    # query locaux idlocal = id
                    $result = pg_query($this->connexion, $query);
                    # fetch result
                    $res = pg_fetch_all($result);
                    # For booleans and numeric convert
                    $res =$this->FormaData($res, $result, false);
                    $code = 200;
                } else {
                    $code = 500;
                    $state = pg_last_error();
                    // some error happened
                    $result_error = "erreur d'execution de la requete :".__FUNCTION__." Detail de l'erreur :".$state;
                    $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                    return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
                }
            } else {
                $code = 400;
            }

            return $this->getResponseData($code, $request, $response,$res);
        }

        /**
         * @url GET /bail/locaux/bailactif
         * @url GET /bail/locauxbailactif=$bool
         */
        public function getBailBailActif(Request $request,Response $response, $arg)
        {
            $code         = (int) null;
            $result       = (bool) null;
            $result_error =(string) null;
            $bool = $arg['bool'];
            # query bail /locaux/bailactif = $bool
            $query = "SELECT  B.idbail, B.keybail, B.idlocal, B.nom_du_locataire, B.nom_commercial, B.idtype_bail, 
                                  B.type_de_bail, B.date_dentree_du_locataire, B.date_effet_du_bail, B.loyer_annuel, B.frais_gestion, 
                                  B.complement_loyer, B.charges_refacturees, B.provision_ur_charges, B.depot_de_garantie, B.actif_bail, 
                                  B.bailactif, B.activite, B.image_bail, B.commentaires, B.date_fin_bail, B.deplaf_fin_bail, B.caution, 
                                  B.type_activite, B.date_liberation, B.proche_liberation, B.loyer_attendu, B.etage, B.affectation_commerce, 
                                  B.affectation_reserve, B.affectation_bureau, B.affectation_stockage, B.affectation_res_sous_sol, 
                                  B.affectation_comm_sous_sol, B.affectation_habitation, B.valeur_locative, B.type_caution, B.trimestre, 
                                  B.annee, B.variation_indice, B.indice_reference, B.destination_bail, B.date_signature_bail, B.duree_preavis, 
                                  B.idactivite, B.idsociete, B.loyer_contractuel, B.loyer_actuel, A.adresse, A.code_postal, A.ville, 
                                  A.surface_totale_actif, L.idactifpatrimonial, B.paliers,B.caution_bancaire,B.caution_societe,B.caution_perso,B.caution_garantie_premiere_demande,
                                  B.caution_garantie_solvabilite,B.duree_speciale,B.date_effective_depart,B.tunnel_indexation,B.duree_bail
                      FROM bail AS B 
                      join locaux AS L on  B.idlocal = L.idlocal  
                      left join actif_patrimonial A on A.idactifpatrimonial = L.idactifpatrimonial 
                      WHERE B.bailactif = {$bool}";
            # test si error de la requête
            $result = pg_send_query($this->connexion, $query);
            $res1 = pg_get_result($this->connexion);
            $result_error = pg_result_error($res1);
            if(Empty($result_error)) {
                # query locaux idlocal = id
                $result = pg_query($this->connexion, $query);
                # fetch result
                $res = pg_fetch_all($result);
                # For booleans and numeric convert
                $res =$this->FormaData($res, $result, false);
                $code = 200;
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete".__FUNCTION__." Detail de l'erreur :".$state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
            }
            return $this->getResponseData($code, $request, $response,$res);
        }


        /**
         * @url PUT /bail/$id
         * @url PUT /bail/$id/$data
         */
        public function UpdateBail(Request $request,Response $response, $arg)
        {
            $code         = (int) null;
            $result       = (bool) null;
            $result_error =(string) null;
            $paliers = (array) [];
            $id = $arg['id'];
            $data = $request->getParam('data');
            $data = $this->getData($data);
            # if method PUT or POSt getValidateFields
            if(!Empty($data)){
                $error = $this->getValidateFields($this->maintable,$data);
            }else{
                $error = "Data is empty !";
            }
            if($error){
                $code = 400;
                return $this->getResponseData($code, $request, $response,$error);
            }

            # valeurs par défault si bailactif=false
            if(isset($data['bailactif'])) {
                if ($data['bailactif'] == false) {
                    $data['actif_bail'] = 'Non';
                    $data['type_de_bail'] = 'VACANT';
                }
                # valeurs par défault si bailactif=true
                if ($data['bailactif'] == true) {
                    $data['actif_bail'] = 'Oui';
                }
            }

            # calcul de la date de fin de bail
            if(isset($data['date_effet_du_bail']) && isset($data['idtype_bail'])) {
                if ($data['bailactif'] == true) {
                    $datefin = $this->DateFinBail($data);
                    $data['date_fin_bail'] = $datefin;
                }
            }

            # format $data with escape string
            $array =$this->InsertFormaData($data,$this->connexion);


            # suppression de paliers avant update
            unset($array['paliers']);

            # update $data
            $result = pg_update($this->connexion, $this->maintable , $array, ["idbail" => "$id"], PGSQL_DML_EXEC);
            if ($result) {
                $q = pg_query($this->connexion, "SELECT * FROM $this->maintable WHERE idbail ={$id}");
                # fetch result
                $res = pg_fetch_all($q);
                $res =$this->FormaData($res, $q,true);

                # enregistrement de paliers
                if (isset($data['paliers'])){
                    $datajson = ['paliers' => $data['paliers']];
                    $this->UpdateBailjsonFields($id,$datajson);
                }

                $code = 200;
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete".__FUNCTION__." Detail de l'erreur :".$state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
            }

            return $this->getResponseData($code, $request, $response,$res);
        }


        /**
         * @param $data
         * @return bool|string
         * @throws \Exception
         */
        public function DateFinBail($data)
        {
            $datefin    = null;
            $dureemax   = (float) 0;
            $dureemois  = (float) 0;

            # requete type_bail pour obtenir la duree_max
            $q = pg_query($this->connexion, "SELECT * FROM type_bail WHERE idtype_bail =".$data['idtype_bail']);
            $res = pg_fetch_all($q);
            # For booleans and numeric convert
            $res =$this->FormaData($res, $q,true);
            if ($res){
                $dureemax = floatval($res['duree_max']);
                if($dureemax == 0){
                    return false;
                }
            }
            # calcul partie entière de la durée du bail
            $dureemois = (floor($dureemax)*12);

            # calcul avec ajout de la partie décilmale
            # pour obtenir le nombre de mois total
            $floatNumber=$dureemax;
            $intPart=(int)$floatNumber;
            $decimalPart=(int)str_replace('.','',$floatNumber-(int)$floatNumber);
            $dureemois +=$decimalPart;

            # calcul de la date de fin du bail
            $datefin  = new DateTime($data['date_effet_du_bail']);
            $datefin->add(new DateInterval('P'.$dureemois.'M'));

            return $datefin->format("Y-m-d");
        }

        /**
         * @url POST /bail
         * @url POST /bail/$data
         */
        public function AddBail(Request $request,Response $response, $arg)
        {
            $code       = (integer) null;
            $res        = (array) null;
            $data       = $request->getParam('data');
            $data       = $this->getData($data);
            $error      = $this->getValidateFields($this->maintable,$data);
            $idbail     = (int) 0;
            $idlocal    = (int) 0;
            $datajson   = (array) null;
            if($error){
                $code = 400;
                return $this->getResponseData($code, $request, $response,$error);
            }
            $table = $this->maintable != '' ? $this->maintable : $this->path;
            # recherche du local
            if($data) {
                $idlocal = intval($data["idlocal"]);
                $q = pg_query($this->connexion, "SELECT idactifpatrimonial, B.idlocal,B.idbail FROM bail B
                                                        join locaux L on L.idlocal = B.idlocal
                                                        WHERE B.idlocal={$idlocal}");
                # fetch result
                $res = pg_fetch_all($q);

                $res =$this->FormaData($res, $q,true);

            }
            if($res) {

                $idbail = (int) $res['idbail'];
                $array = $data;

                # suppression des champs json ils sont traités à part
                unset($array['paliers']);
                unset($array['bail_precedent']);

                $array['type_de_bail'] = $this->getTypeBail($data['idtype_bail']);

                # format $data with escape string
                $res = $this->InsertFormaData($array, $this->connexion);

                # update bail, with data entry users
                $result = pg_update($this->connexion, $this->maintable , $res, ["idbail" => "$idbail"], PGSQL_DML_EXEC);
            } else {

                # if method PUT or POSt getValidateFields
                $error = $this->getValidateFields($this->maintable, $data);
                if ($error) {
                    $code = 400;
                    return $this->getResponseData($code, $request, $response, $error);
                }

                # format $data with escape string
                $array = $this->InsertFormaData($data, $this->connexion);

                # suppression des champs json ils sont traités à part
                $array['paliers'] = '[]';
                unset($array['bail_precedent']);

                # insert $data entry users
                $array['idbail'] = $this->NewSequence( $this->maintable,'idbail',$this->connexion);
                $result = pg_insert($this->connexion, $this->maintable, $array, PGSQL_DML_EXEC);

                }
            # return résultat
            if ($result) {
                if ($idbail === 0) {
                    $idbail = $array['idbail'];
                }
                # recherche de l'id
                $q = pg_query($this->connexion, "SELECT * FROM $this->maintable WHERE idbail ={$idbail}");
                # fetch result
                $res = pg_fetch_all($q);
                $res = $this->FormaData($res, $q, true);
                if (isset($data['paliers'])){
                    $datajson = ['paliers' => $data['paliers']];
                    $this->UpdateBailjsonFields($idbail,$datajson);
                }
                $code = 200;
            } else {
                $code = 500;
                $state = pg_last_error();
                // some error happened
                $result_error = "erreur d'execution de la requete".__FUNCTION__." Detail de l'erreur :".$state;
                $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
            }
            # renum keybail
            $this->SetRenumKeybail($this->maintable);
            return $this->getResponseData($code, $request, $response,$res);
        }


        /**
         * @param $table
         * @return array
         */
        public function getValidateFields($table,$data) {
            $validfields = $this->ValidateField($table, $this->connexion);
            $res         = $this->verifyRequiredParams($data,$validfields);
            return $res;
        }

        /**
         *
         */
        public function SetRenumKeybail($table)
        {
            $compt  = (int) 1;
            $data   = (array) ['keybail' => 1];
            $idbail = (int) 0;
            # query locaux idbail = id
            $q = pg_query($this->connexion, "SELECT B.idbail, L.idactifpatrimonial, B.keybail FROM $this->maintable as B 
                                                    join locaux AS L on  B.idlocal = L.idlocal  
                                                    left join actif_patrimonial A on A.idactifpatrimonial = L.idactifpatrimonial AND B.bailactif = true 
                                                    ORDER by L.idactifpatrimonial,B.idbail");
            # fetch result
            $baux = pg_fetch_all($q);
            $valkey = (int) $baux[0]['idactifpatrimonial'];
            foreach($baux as $keys => $value)
            {
                # si on change d'actif, le compteur est mis à 1
                if($baux[$keys]['idactifpatrimonial'] !== $valkey ){
                    $compt = 1;
                }
                # changer la keybail
                $idbail = intval($baux[$keys]['idbail']);
                $data['keybail'] = $compt;
                if($idbail > 0 && $compt > 0){
                    $result = pg_update($this->connexion, $this->maintable, $data, ["idbail" => $idbail], PGSQL_DML_EXEC);
                }
                $compt ++;
                $valkey = $baux[$keys]['idactifpatrimonial'];
            }
        }


        /**
         * @url DELETE /bail/$id
         */
        public function DeleteBail(Request $request,Response $response, $arg)
        {
            $code = (integer) null;
            $id = $arg['id'];
            # recherche de l'id
            $q = pg_query($this->connexion, "SELECT (loyer_annuel+complement_loyer) as valeur FROM $this->maintable WHERE idbail ={$id}");
            # fetch result
            $res = pg_fetch_object($q);
            if($res) {
                $valeurlocative = (float) ($res->valeur);

                $data = (array) [  'valeur_locative'            =>  $valeurlocative,
                    'nom_du_locataire'          => null,
                    'nom_commercial'            => null,
                    'idtype_bail'               => null,
                    'type_de_bail'              => 'VACANT',
                    'date_dentree_du_locataire' => null,
                    'date_effet_du_bail'        => null,
                    'loyer_annuel'              => 0,
                    'frais_gestion'             => 0,
                    'complement_loyer'          => 0,
                    'charges_refacturees'       => null,
                    'provision_ur_charges'      => 0,
                    'depot_de_garantie'         => 0,
                    'actif_bail'                => 'Non',
                    'bailactif'                 => false,
                    'activite'                  => null,
                    'image_bail'                => null,
                    'commentaires'              => null,
                    'deplaf_fin_bail'           => null,
                    'caution'                   => null,
                    'type_activite'             => null,
                    'date_liberation'           => null,
                    'proche_liberation'         => null,
                    'loyer_attendu'             => 0,
                    'etage'                     => null,
                    'affectation_commerce'      => null,
                    'affectation_reserve'       => 0,
                    'affectation_bureau'        => 0,
                    'affectation_stockage'      => 0,
                    'affectation_res_sous_sol'  => 0,
                    'affectation_comm_sous_sol' => 0,
                    'affectation_habitation'    => 0,
                    'type_caution'              => null,
                    'trimestre'                 => null,
                    'annee'                     => null,
                    'variation_indice'          => null,
                    'indice_reference'          => null,
                    'destination_bail'          => null,
                    'date_signature_bail'       => null,
                    'duree_preavis'             => null,
                    'idactivite'                => null,
                    'idsociete'                 => null,
                    'loyer_contractuel'         => 0,
                    'cap_indexation'            => 0,
                    'loyer_actuel'              => 0 ];


                # format $data with escape string
                $array =$this->InsertFormaData($data,$this->connexion);
                # update $data
                $res = pg_update($this->connexion, $this->maintable , $array, ["idbail" => "$id"], PGSQL_DML_EXEC);
                if($res) {
                    # delete est remplacé par un update car le bail n'est jamais supprimé
                    # $res = pg_delete($this->connexion, $this->maintable , ["idbail" => "$id"], PGSQL_DML_EXEC);
                    # For booleans and numeric convert
                    $res = ["message" => "L'Enregistrement a été éffacé", "Enregistrement supprimé ID :" => $id];
                    $code = 200;
                }else{
                    $code = 500;
                    $state = pg_last_error();
                    // some error happened
                    $result_error = "erreur d'execution de la requete".__FUNCTION__." Detail de l'erreur :".$state;
                    $this->logger->notice(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).$result_error.': '.__FUNCTION__);
                    return $this->getResponseData($code, $request, $response,["returncode"=>500,"message"=> "Erreur lors de l'execution de la requete :".__FUNCTION__." Detail :".$result_error, "code" => 500]);
                }
            } else {
                $code = 400;
                $res = array([
                    'error' => "Unknown $this->maintable :",
                    'Arguments' => $arg,
                    'code' => $code
                ]);
            }
            $this->SetRenumKeybail($this->maintable);
            return $this->getResponseData($code, $request, $response,$res);

        }

        /**
         * @param $data
         * @return array
         */
        public function getTypeBail($data){
            $idtypebail =$data;
            $bail = (string) null;
            # requete type_bail pour obtenir la duree_max
            $q = pg_query($this->connexion, "SELECT type_de_bail FROM type_bail WHERE idtype_bail = $idtypebail");
            $res = pg_fetch_all($q);
            if($res){
                # For booleans and numeric convert
                $res =$this->FormaData($res, $q,true);
                $bail = $res['type_de_bail'];
            }

            return $bail;
        }

        /**
         * @param $id
         * @param $data
         * @return array|bool
         */
        public function UpdateBailjsonFields($id, $data)
        {
            $code = (integer) NULL;
            $res  = false;
            $key  = (string) null;
            if (key_exists('paliers',$data)){
                $key = 'paliers';
            }elseif(key_exists('bail_precedent',$data)){
                $key = 'bail_precedent';
            }else{
                return 200;
            }

            $data = json_encode($data[$key]);
            # update $data
            $array = pg_escape_literal($data);
            $result = pg_query($this->connexion,"UPDATE bail SET $key = $array WHERE idbail=$id");
            if ($result) {
                $res = ["message" => "Le bail $id a été saugardé"];
                $code = 200;
            } else {
                $code = 400;
                $res = false;
            }

            return $res;
        }
    }
}
