<?php
/**
 * Copyright (c)  2018. L’ensemble du contenu (codes, textes, photographies, infographies, icônes, etc.) du site www.you-fleet.fr est la propriété exclusive de  sas ODEA, éditeur du site you-fleet.fr enregistrés à l'agence pour la protection des programmes sous le N°IDDN.FR.001.43005.000.R.P.2016.000.20100 Tous droits de reproduction ou de représentation de ceux-ci sont réservés.
 */


/**
 * Created by PhpStorm.
 * User: gerald
 * Date: 03/07/2018
 * Time: 16:31
 */


//$tz = new DateTimeZone('Europe/Paris');

$today = (int)mktime(0, 0, 0, date("m"), date("d"), date("Y"));
//$date = new DateTime($today, $tz);//utilisera le bon fuseau horaire
# mois en cours
$month =  date("m",$today);
# ammee en cours
$year  =  date("Y",$today);

# premier jours du mois en cours
$premier = date("Y-m-d", mktime(0, 0, 0, $month, 1 ,$year));

# dernier jours du mois en cours
$dernier = date("Y-m-d", mktime(0, 0, 0, $month+1, 0 ,$year));

# date du jour
$date =  date("Y-m-d",$today);

# calcul du dernier et premier jour du trimestre en cours
if ($month>=1 && $month<=3){
    $trimlast  = date("Y-m-d", mktime(0, 0, 0, 4, 0 ,$year));
    $trimfirst = date("Y-m-d", mktime(0, 0, 0, 1, 1 ,$year));
}
if ($month>3 && $month<=6){
    $trimlast =date("Y-m-d", mktime(0, 0, 0, 7, 0 ,$year));
    $trimfirst = date("Y-m-d", mktime(0, 0, 0, 4, 1 ,$year));
}
if ($month>6 && $month<=9){
    $trimlast =date("Y-m-d", mktime(0, 0, 0, 10, 0 ,$year));
    $trimfirst = date("Y-m-d", mktime(0, 0, 0, 7, 1 ,$year));
}
if ($month>9 && $month<=12){
    $trimlast =date("Y-m-d", mktime(0, 0, 0, 12, 31 ,$year));
    $trimfirst = date("Y-m-d", mktime(0, 0, 0, 10, 1 ,$year));
}
define('REMOTE_ADDR',$_SERVER["REMOTE_ADDR"]);

/**
 * defini l'année en cours
 */
define('SETTING_YEAR_NOW', $year);

/**
 * trimestre en cours
 */
define("SETTING_MONTH_NOW", $month);

/**
 * défini la date du jours en cours
 */
define('SETTING_DAY_NOW', $date);

/**
 * défini la date du jours en cours
 */
define('SETTING_DAY_FIRST', $premier);
/**
 * défini la date du jours en cours
 */
define('SETTING_DAY_LAST', $dernier);

/**
 * premier jour trimestre en cours
 */
define("SETTING_TRIMESTRE_FIRST_DAY", $trimfirst);

/**
 * dernier jour trimestre en cours
 */
define("SETTING_TRIMESTRE_LAST_DAY", $trimlast);

/**
 * défini le répertoire documentroot
 * ou est installé l'application
 */
//define('SITE_PATH', '/var/www/madar-patrimoine.fr/public_html/');
define('SITE_PATH', 'd:/site/patrimonial');

/**
 * défini le répertoire documentroot
 * ou est installé l'application
 */
define('SETTING_DEBUG', true);

/**
 *  definie environnement DEV ou Prod
 */
define('SETTING_ENVIRONMENT','Dev');

/**
 * refaire les séquences des tables
 * ou est installé l'application
 */
define('SETTING_NEW_SEQUENCE', true);


/**
 * documentroot du server PATRIMONIAL
 * @server export fichiers
 */
define('PATRIMONIAL_PATH_EXP', '../files/pictures');
/**
 * documentroot du server PATRIMONIAL
 * @server Import fichiers
 */
define('PATRIMONIAL_PATH_IMP', '../files/import');

/***
 * @server export fichiers
 */
define('PATRIMONIAL_PATH_EXPORT', '../files/export');

/**
 * @host du server PATRIMONIAL
 */
define('PATRIMONIAL_HOST','127.0.0.1');

/**
 * @charset
 */
define('DB_CHARSET', 'utf8');

/**
 * @persistence BDD
 */
define('DB_PDOPERSISTENT', false);


/**
 * @port BDD PATRIMONIAL
 */
define('SETTING_PORT',"5432");

/**
 * @host BDD PATRIMONIAL
 */
define('SETTING_HOST',"localhost");

/**
 * @Socket BDD PATRIMONIAL
 */
define('SETTING_SOCK','');

/**
 * @name BDD PATRIMONIAL
 */
define('SETTING_DBNAME',"patrimonial");

/**
 * @@Driver null = pg_connect
 */
define('SETTING_DRIVER',null);


/**
 * @@user BDD PATRIMONIAL
 */
define('SETTING_USER',"postgres");

/**
 * @passwd BDD PATRIMONIAL
 */
define('SETTING_PSWD',"rte7i85ti");

/**
 * pour le transfert des fichiers vers le serveur PATRIMONIAL
 * @using SSH
 */
define('SETTING_SFTP',true);


/**
 * Full acces lot of laugth
 * pour copie des fichiers dans le repertoire <files>
 * @user acces SSH PATRIMONIAL
 */
define('SETTING_SFTPUSER','root');

/**
 * pawwsord acces SSH
 * @passwd SSH
 */
define('SETTING_SFTPPSWD','rte7i85ti');
