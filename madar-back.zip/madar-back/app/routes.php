<?php
/**
 * Copyright (c)  2018. L’ensemble du contenu (codes, textes, photographies, infographies, icônes, etc.) du site www.you-fleet.fr est la propriété exclusive de  sas ODEA, éditeur du site you-fleet.fr enregistrés à l'agence pour la protection des programmes sous le N°IDDN.FR.001.43005.000.R.P.2016.000.20100 Tous droits de reproduction ou de représentation de ceux-ci sont réservés.
 */



use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

# App Controller oAuth2
use App\Controllers\_ApiController;
use App\Controllers\_Controller;
use App\Controllers\_Controller_oAuth2;
use App\Controllers\UploadController;
use App\Controllers\_oAuth2TokenController;

# Custom Controllers / Data Custom
use App\Models\ActifPatrimonial;
use App\Models\Amortissements;
use App\Models\Bail;
use App\Models\Banque;
use App\Models\Categorie;
use App\Models\Coeffprog;
use App\Models\DonneesEmprunt;
use App\Models\DonneesExcel;
use App\Models\GestionFin;
use App\Models\Etat;
use App\Models\Euribor;
use App\Models\Portefeuilles;
use App\Models\ImportationEgide;
use App\Models\Indice;
use App\Models\Locaux;
use App\Models\Notifications;
use App\Models\RendezVous;
use App\Models\Societe;
use App\Models\TypeBail;
use App\Models\TypeDeFinancement;
use App\Models\Activites;
use App\Models\Users;


/*$app->options('/{routes:.+}', function ($request, $response, $args) {
    return $response;
});*/


/**
 *  Routes
 */
$app->get('/hello', _ApiController::class.':showHello')
    ->setName('hellopage');

/**
 *  uploads file
 */
$app->group('/uploads', function () {
    $this->post('/base64', UploadController::class.':UploadFileBase64')->add(function ($request, $response, $next) {
        $response = $next($request, $response);
        //      $response->write($response);
        return $response;
   })->setName('uploads');
 /*   $this->post('/', UploadController::class . ':uploadFileRequest')->add(function ($request, $response, $next) {
        $response = $next($request, $response);
  //      $response->write($response);
        return $response;
    })->setName('uploads');*/
    $this->get('/', function (Request $request, Response $response, $args) {
        return $this->view->render($response, 'uploads.html');
    })->setName('uploads'); // added route name
})->add(function ($request, $response, $next) {
    $response = $next($request, $response);
    return $response;
});

# oAuth2
/*$app->group('/oauth', function () {
    $this->post('/token', _oAuth2TokenController::class.':token');
});*/

/*// Books controller
$app->group('/auth_users', function () {
    $this->get   ('',             _Controller_oAuth2::class.':getAll');
    $this->get   ('/{id:[0-9]+}', _Controller_oAuth2::class.':get');
    $this->post  ('',             _Controller_oAuth2::class.':add');
    $this->put   ('/{id:[0-9]+}', _Controller_oAuth2::class.':update');
    $this->delete('/{id:[0-9]+}', _Controller_oAuth2::class.':delete');
})->add(function ($request, $response, $next) {
    $this->settings['localtable'] = "auth_users";
    $response = $next($request, $response);
    return $response;
});*/


# ActifPatrimonial Controller
$app->group('/actifs', function ()  {
    $this->get('/',                     ActifPatrimonial::class.':getListActifPatrimonial');
    $this->get('/{id:[0-9]+}',          ActifPatrimonial::class.':getActifPatrimonial');
    $this->get('/portefeuilles/{id:[0-9]+}',   ActifPatrimonial::class.':getInvestissement');
    $this->post('/',                    ActifPatrimonial::class.':addActifPatrimonial');
    $this->put('/{id:[0-9]+}',          ActifPatrimonial::class.':UpdateActifPatrimonial');
    $this->delete('/{id}',              ActifPatrimonial::class.':deleteActifPatrimonial');
})->add(function ($request, $response, $next) {
    $this->settings['localtable'] = "actif_patrimonial";
    $response = $next($request, $response);
    return $response;
});

# Activites Controller
$app->group('/activites', function () {
    $this->get('/',                     Activites::class.':getListActivites');
    $this->get('/{id:[0-9]+}',          Activites::class.':getActivites');
    $this->post('/',                    Activites::class.':AddActivites');
    $this->put('/{id:[0-9]+}',          Activites::class.':UpdateActivites');
    $this->delete('/{id}',              Activites::class.':DeleteActivites');
})->add(function ($request, $response, $next) {
    $this->settings['localtable'] = "activites";
    $response = $next($request, $response);
    return $response;
});

# Amortissements Controller
$app->group('/amortissements', function () {
    $this->get('/',                     Amortissements::class.':getListAmortissement');
    $this->get('/{id:[0-9]+}',          Amortissements::class.':getAmortissement');
    $this->post('/',                    Amortissements::class.':addAmortissement');
    $this->put('/{id:[0-9]+}',          Amortissements::class.':UpdateAmortissement');
    $this->delete('/{id}',              Amortissements::class.':deleteAmortissement');
})->add(function ($request, $response, $next) {
    $this->settings['localtable'] = "emprunt_amortissement";
    $response = $next($request, $response);
    return $response;
});

# Bail Controller
$app->group('/baux', function () {
    $this->get('/',                      Bail::class.':getListBail');
    $this->get('/{id:[0-9]+}',           Bail::class.':getBail');
    $this->get('/locaux/{id:[0-9]+}',    Bail::class.':getByIdLocal');
    $this->get('/bailactif/{bool}',      Bail::class.':getBailBailActif');
    $this->get('/{id}/bailactif/{bool}', Bail::class.':getIDByBailBailActif');
    $this->post('/',                     Bail::class.':addBail');
    $this->put('/{id:[0-9]+}',           Bail::class.':UpdateBail');
    $this->delete('/{id}',               Bail::class.':deleteBail');
})->add(function ($request, $response, $next) {
    $this->settings['localtable'] = "bail";
    $response = $next($request, $response);
    return $response;
});

# Banque Controller
$app->group('/banques', function () {
    $this->get('/',                      Banque::class.':getListBanque');
    $this->get('/{id:[0-9]+}',           Banque::class.':getBanque');
    $this->post('/',                     Banque::class.':addBanque');
    $this->put('/{id:[0-9]+}',           Banque::class.':UpdateBanque');
    $this->delete('/{id}',               Banque::class.':deleteBanque');
})->add(function ($request, $response, $next) {
    $this->settings['localtable'] = "banque";
    $response = $next($request, $response);
    return $response;
});

# Categorie Controller
$app->group('/categories', function () {
    $this->get('/',                      Categorie::class.':getListCategorie');
    $this->get('/{id:[0-9]+}',           Categorie::class.':getCategorie');
    $this->post('/',                     Categorie::class.':addCategorie');
    $this->put('/{id:[0-9]+}',           Categorie::class.':UpdateCategorie');
    $this->delete('/{id}',               Categorie::class.':deleteCategorie');
})->add(function ($request, $response, $next) {
    $this->settings['localtable'] = "categorie";
    $response = $next($request, $response);
    return $response;
});

# Coeffprog Controller
$app->group('/coeffprogs', function () {
    $this->get('/',                      Coeffprog::class.':getListCoeffprog');
    $this->get('/{id:[0-9]+}',           Coeffprog::class.':getCoeffprog');
    $this->post('/',                     Coeffprog::class.':addCoeffprog');
    $this->put('/{id:[0-9]+}',           Coeffprog::class.':UpdateCoeffprog');
    $this->delete('/{id}',               Coeffprog::class.':deleteCoeffprog');
})->add(function ($request, $response, $next) {
    $this->settings['localtable'] = "coeffprog";
    $response = $next($request, $response);
    return $response;
});

# DonneesEmprunt Controller
$app->group('/emprunts', function () {
    $this->get('/',                             DonneesEmprunt::class.':getListDonneesEmprunt');
    $this->get('/calculateur',                   DonneesEmprunt::class.':getCalculateur');
    $this->get('/{id:[0-9]+}',                  DonneesEmprunt::class.':getDonneesEmprunt');
    $this->get('/portefeuilles/{id:[0-9]+}',    DonneesEmprunt::class.':getInvestissement');
    $this->post('/',                            DonneesEmprunt::class.':addDonneesEmprunt')->setName('emprunts');
    $this->put('/{id:[0-9]+}',                  DonneesEmprunt::class.':UpdateDonneesEmprunt');
    $this->delete('/{id}',                      DonneesEmprunt::class.':deleteDonneesEmprunt');
})->add(function (Request $request,Response $response, $next) {
    $this->settings['localtable'] = "donnees_emprunt";
    $response = $next($request, $response);
    return $response;
});

# GestionFin Controller
$app->group('/rapports', function () {
    $this->get('/synthese',                     GestionFin::class.':AddGestionFin');
    $this->get('/synthese/{id:[0-9]+}',         GestionFin::class.':getDonneesRapports');
    $this->get('/dscr/{id:[0-9]+}',             GestionFin::class.':getGraphiqueDSCR');
    $this->get('/totaldscr/{id:[0-9]+}',        GestionFin::class.':getGraphiqueTotalDSCR');
    $this->get('/regions',                      GestionFin::class.':getCAByRegion');
    $this->get('/activites',                    GestionFin::class.':getCAByActivite');
    $this->get('/arrondissements',              GestionFin::class.':getCAByArrondissements');
    $this->get('/total',                        GestionFin::class.':getCumulGestionFin');
    $this->get('/crd',                          GestionFin::class.':getGraphiqueCRDBanque');
    $this->get('/excel',                        GestionFin::class.':getListFilesExcel');
    $this->get('/excel/{file}',                 GestionFin::class.':downloadFileExcel');
    $this->post('/',                            GestionFin::class.':AddGestionFin');
    $this->put('/{id:[0-9]+}',                  GestionFin::class.':UpdateDonneesRapports');
    $this->delete('/{id}',                      GestionFin::class.':deleteDonneesRapports');
})->add(function ($request, $response, $next) {
    $this->settings['localtable'] = "gestion_fin";
    $response = $next($request, $response);
    return $response;
});

/*# DonneesExcel Controller
$app->group('/excel', function () {
    $this->get('/synthese',              DonneesExcel::class.':getListDonneesExcel');
    $this->post('/',                     DonneesExcel::class.':AddGestionFin');
    $this->put('/{id:[0-9]+}',           DonneesExcel::class.':UpdateDonneesExcel');
    $this->delete('/{id}',               DonneesExcel::class.':deleteDonneesExcel');
})->add(function ($request, $response, $next) {
    $this->settings['localtable'] = "gestion_fin";
    $response = $next($request, $response);
    return $response;
});*/

# Etat  Controller
$app->group('/etats', function () {
    $this->get('/',                      Etat::class.':getListEtat');
    $this->get('/{id:[0-9]+}',           Etat::class.':getEtat');
    $this->post('/',                     Etat::class.':addEtat');
    $this->put('/{id:[0-9]+}',           Etat::class.':UpdateEtat');
    $this->delete('/{id}',               Etat::class.':deleteEtat');
})->add(function ($request, $response, $next) {
    $this->settings['localtable'] = "etat";
    $response = $next($request, $response);
    return $response;
});

# ListEuribor Controller
$app->group('/euribors', function () {
    $this->get('/',                      Euribor::class.':getListEuribor');
    $this->get('/{id:[0-9]+}',           Euribor::class.':getEuribor');
    $this->post('/',                     Euribor::class.':addEuribor');
    $this->put('/{id:[0-9]+}',           Euribor::class.':UpdateEuribor');
    $this->delete('/{id}',               Euribor::class.':deleteEuribor');
})->add(function ($request, $response, $next) {
    $this->settings['localtable'] = "euribor";
    $response = $next($request, $response);
    return $response;
});

# Portefeuilles Controller
$app->group('/portefeuilles', function () {
    $this->get('/',                      Portefeuilles::class.':getListPortefeuilles');
    $this->get('/{id:[0-9]+}',           Portefeuilles::class.':getPortefeuilles');
    $this->post('/',                     Portefeuilles::class.':addPortefeuilles');
    $this->put('/{id:[0-9]+}',           Portefeuilles::class.':UpdatePortefeuilles');
    $this->delete('/{id}',               Portefeuilles::class.':deletePortefeuilles');
})->add(function ($request, $response, $next) {
    $this->settings['localtable'] = "investissements";
    $response = $next($request, $response);
    return $response;
});

# ImportationEgide Controller
$app->group('/importationegides', function () {
    $this->get('/',                      ImportationEgide::class.':getListImportationEgide');
    $this->get('/{id:[0-9]+}',           ImportationEgide::class.':getImportationEgide');
    $this->post('/',                     ImportationEgide::class.':addImportationEgide');
    $this->put('/{id:[0-9]+}',           ImportationEgide::class.':UpdateImportationEgide');
    $this->delete('/{id}',               ImportationEgide::class.':deleteImportationEgide');
})->add(function ($request, $response, $next) {
    $this->settings['localtable'] = "importation_egide";
    $response = $next($request, $response);
    return $response;
});

# indice Controller
$app->group('/indices', function () {
    $this->get('/',                      Indice::class.':getListIndice');
})->add(function ($request, $response, $next) {
    $this->settings['localtable'] = "jourferies";
    $response = $next($request, $response);
    return $response;
});

# locaux Controller
$app->group('/locaux', function ()  {
    $this->get('/',                     Locaux::class.':getListLocal');
    $this->get('/{id:[0-9]+}',          Locaux::class.':getLocal');
    $this->get('/actifs/{id:[0-9]+}',   Locaux::class.':getLocalByIdActif');
    $this->get('/bailactif/{bool}',     Locaux::class.':getLocalBailActif');
    $this->get('/{id:[0-9]+}/bailactif/{bool}',Locaux::class.':getIDByLocalBailActif');
    $this->post('/',                    Locaux::class.':addLocal');
    $this->put('/{id:[0-9]+}',          Locaux::class.':UpdateLocal');
    $this->delete('/{id}',              Locaux::class.':deleteLocal');
})->add(function (Request $request,Response $response, $next) {
    $this->settings['localtable'] = 'locaux';
    $response = $next($request, $response);
    return $response;
});


# Notifications Controller
$app->group('/notifications', function () {
    $this->get('/',                      Notifications::class.':getListNotifications');
    $this->get('/{id:[0-9]+}',           Notifications::class.':getNotifications');
    $this->post('/',                     Notifications::class.':AddNotifications');
    $this->put('/{id:[0-9]+}',           Notifications::class.':UpdateNotifications');
    $this->delete('/{id:[0-9]+}',        Notifications::class.':DeleteNotifications');
})->add(function ($request, $response, $next) {
    $this->settings['localtable'] = "notifications";
    $response = $next($request, $response);
    return $response;
});


# RendezVous Controller
$app->group('/rendezvous', function () {
    $this->get('/',                      RendezVous::class.':getListRendezVous');
    $this->get('/{id:[0-9]+}',           RendezVous::class.':getRendezVous');
    $this->post('/',                     RendezVous::class.':addRendezVous');
    $this->put('/{id:[0-9]+}',           RendezVous::class.':UpdateRendezVous');
    $this->delete('/{id}',               RendezVous::class.':deleteRendezVous');
})->add(function ($request, $response, $next) {
    $this->settings['localtable'] = "rendezvous";
    $response = $next($request, $response);
    return $response;
});




# Societe Controller
$app->group('/societes', function () {
    $this->get('/',                      Societe::class.':getListSociete');
    $this->get('/{id:[0-9]+}',           Societe::class.':getSociete');
    $this->post('/',                     Societe::class.':addSociete');
    $this->put('/{id:[0-9]+}',           Societe::class.':UpdateSociete');
    $this->delete('/{id}',               Societe::class.':deleteSociete');
})->add(function ($request, $response, $next) {
    $this->settings['localtable'] = "societe";
    $response = $next($request, $response);
    return $response;
});

# TypeBail Controller
$app->group('/typesbaux', function () {
    $this->get('/',                      TypeBail::class.':getListTypeBail');
    $this->get('/{id:[0-9]+}',           TypeBail::class.':getTypeBail');
    $this->post('/',                     TypeBail::class.':addTypeBail');
    $this->put('/{id:[0-9]+}',           TypeBail::class.':UpdateTypeBail');
    $this->delete('/{id}',               TypeBail::class.':deleteTypeBail');
})->add(function ($request, $response, $next) {
    $this->settings['localtable'] = "type_bail";
    $response = $next($request, $response);
    return $response;
});

# Activites Controller
$app->group('/typefinancements', function () {
    $this->get('/',                      TypeDeFinancement::class.':getListTypeDeFinancement');
    $this->get('/{id:[0-9]+}',           TypeDeFinancement::class.':getTypeDeFinancement');
    $this->post('/',                     TypeDeFinancement::class.':addTypeDeFinancement');
    $this->put('/{id:[0-9]+}',           TypeDeFinancement::class.':UpdateTypeDeFinancement');
    $this->delete('/{id}',               TypeDeFinancement::class.':deleteTypeDeFinancement');
})->add(function ($request, $response, $next) {
    $this->settings['localtable'] = "type_de_financement";
    $response = $next($request, $response);
    return $response;
});

# Users Controller
$app->group('/users', function () {
    $this->get('/',                      users::class.':getListUsers');
    $this->get('/{id:[0-9]+}',           Users::class.':getUsers');
    $this->post('/',                     Users::class.':AddUsers');
    $this->put('/{id:[0-9]+}',           Users::class.':UpdateUsers');
    $this->delete('/{id}',               Users::class.':DeleteUsers');
})->add(function ($request, $response, $next) {
    $this->settings['localtable'] = "users";
    $response = $next($request, $response);
    return $response;
});

# Users Controller
$app->group('/login', function () {
    $this->post('/',       Users::class.':setUserLogin');
    $this->get('/',       Users::class.':setUserLogout');
})->add(function ($request, $response, $next) {
    $this->settings['localtable'] = "users";
    $response = $next($request, $response);
    return $response;
});

# Users Controller
$app->group('/logout', function () {
    $this->post('/',       Users::class.':setUserLogout');
})->add(function ($request, $response, $next) {
    $this->settings['localtable'] = "users";
    $response = $next($request, $response);
    return $response;
});
// NOTE: make sure this route is defined last
/*$app->map(['GET', 'POST', 'PUT', 'DELETE', 'PATCH'], '/{routes:.+}', function($req, $res) {
    $handler = $this->notFoundHandler; // handle using the default Slim page not found handler
    return $handler($req, $res);
});*/
# & Fin routes
