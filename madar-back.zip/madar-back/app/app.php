<?php
/**
 * Copyright (c)  2018. L’ensemble du contenu (codes, textes, photographies, infographies, icônes, etc.) du site www.you-fleet.fr est la propriété exclusive de  sas ODEA, éditeur du site you-fleet.fr enregistrés à l'agence pour la protection des programmes sous le N°IDDN.FR.001.43005.000.R.P.2016.000.20100 Tous droits de reproduction ou de représentation de ceux-ci sont réservés.
 */



use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;


// To help the built-in PHP dev server, check if the request was actually for
// something which should probably be served as a static file
if (PHP_SAPI === 'cli-server' && $_SERVER['SCRIPT_FILENAME'] !== __FILE__) {
    return false;
}

require __DIR__.'/../vendor/autoload.php';

# open config
require_once __DIR__.'/config.php';

// Instantiate the app
$settings = require __DIR__.'/settings.php';
$app = new \Slim\App($settings);

// Set up dependencies
require __DIR__.'/dependencies.php';

// Register middleware
require __DIR__.'/middleware.php';

// Register routes
require __DIR__.'/routes.php';

// Run!
$app->run();



